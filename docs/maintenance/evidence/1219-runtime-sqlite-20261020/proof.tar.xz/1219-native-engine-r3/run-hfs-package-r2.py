from pathlib import Path
import subprocess,json,tempfile,shutil,plistlib,os,datetime,hashlib
out=Path(__file__).parent;art=out/'packages-mac-hfs-r2';previous=out/'packages-mac-main'
art.mkdir(exist_ok=False)
shutil.copytree(previous/'harness',art/'harness');shutil.copy2(previous/'custody-observer.mjs',art/'custody-observer.mjs')
meta=json.loads((previous/'preparation.json').read_text());meta['scope']='Actual owned HFS+ sparse image; stock Node packaged migration/multiprocess/restart/export/rollback; no models';(art/'preparation.json').write_text(json.dumps(meta,indent=2)+'\n')
(art/'run.py').write_text((previous/'run.py').read_text().replace(str(previous),str(art)).replace("'1219-native-engine-r3/packages-mac-main'","'1219-native-engine-r3/packages-mac-hfs'"))
owned=Path(tempfile.mkdtemp(prefix='meridian-1219-hfs-'));owned.chmod(0o700)
image=owned/'fixture.sparseimage';mount=owned/'mount';mount.mkdir()
record=dict(head=meta['head'],result='RUNNING',models=0,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),ownedRoot=str(owned));device=None
def command(label,args):
 with(art/(label+'.log')).open('wb')as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 record[label+'Exit']=result.returncode
 assert result.returncode==0,label
try:
 command('create',['hdiutil','create','-size','2g','-fs','HFS+','-volname','Meridian1219Fixture','-type','SPARSE',str(image)])
 attach=subprocess.run(['hdiutil','attach','-nobrowse','-owners','on','-mountpoint',str(mount),'-plist',str(image)],capture_output=True,timeout=60)
 (art/'attach.stdout.plist').write_bytes(attach.stdout);(art/'attach.stderr.log').write_bytes(attach.stderr)
 assert attach.returncode==0
 entities=plistlib.loads(attach.stdout)['system-entities'];device=next(e['dev-entry']for e in entities if e.get('dev-entry')and not e.get('content-hint')=='Apple_HFS')
 assert any(Path(e.get('mount-point','/absent')).resolve()==mount.resolve()for e in entities)
 fs=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import{statfsSync}from'node:fs';console.log(JSON.stringify(statfsSync(process.argv[1])))",str(mount)],text=True));record['statfs']=fs;assert fs['type']==17
 env=dict(os.environ,TMPDIR=str(mount))
 with(art/'controller.log').open('w')as log:
  child=subprocess.Popen(['python3',str(art/'run.py')],env=env,stdout=log,stderr=subprocess.STDOUT);record['controllerPID']=child.pid;record['exit']=child.wait(timeout=600)
 proof=json.loads((art/'result.json').read_text());assert record['exit']==0 and proof['result']=='PASS'and proof['allOriginalActorsJoined']
 record['result']='PASS'
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:500])
finally:
 if device:
  result=subprocess.run(['hdiutil','detach',device],capture_output=True,timeout=60);record['detachExit']=result.returncode;(art/'detach.log').write_bytes(result.stdout+result.stderr)
  if result.returncode:record['result']='FAIL'
 if not os.path.ismount(mount):shutil.rmtree(owned);record['imageAndMountRemoved']=True
 record['scriptSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(art/'filesystem-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['result']=='PASS'else 1)
