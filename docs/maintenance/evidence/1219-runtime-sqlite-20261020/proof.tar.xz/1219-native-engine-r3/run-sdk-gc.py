from pathlib import Path
import subprocess, os, json, hashlib, datetime, signal, tempfile, shutil

out = Path(__file__).parent
platform = os.environ['E2E_GC_PLATFORM']
assert platform in ['mac', 'linux']
art = out / ('sdk-gc-' + platform)
art.mkdir(exist_ok=False)
meta = json.loads((out / 'package-identity.json').read_text())
harness = out / 'sdk-gc-close-peer-probe.mjs'
seal = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), harness]}
assert hashlib.sha256(Path(meta['package']).read_bytes()).hexdigest() == meta['packageSHA256']
hold = out.parent / 'LIVE_MODEL_HOLD.json'
hold_sha = hashlib.sha256(hold.read_bytes()).hexdigest()
owned = Path(tempfile.mkdtemp(prefix='meridian-1219-sdk-gc-' + platform + '-'))
owned.chmod(0o700)
env = {k: v for k, v in os.environ.items() if k in ['PATH', 'LANG', 'LC_ALL', 'TERM', 'TMPDIR']}
for key in ['home', 'cache', 'install']:
    (owned / key).mkdir(mode=0o700)
env.update(HOME=str(owned/'home'), npm_config_cache=str(owned/'cache'),
           MERIDIAN_CLAUDE_PATH=os.environ['E2E_GC_NATIVE'], MERIDIAN_CREDENTIALS_READONLY='1')
record = dict(head=meta['head'], packageSHA256=meta['packageSHA256'], scripts=seal,
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              platform=platform, cases=[], models=0, result='RUNNING', ownedRoot=str(owned))
def save():
    (art/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def run(args, name, timeout):
    with (art/(name+'.log')).open('w') as log:
        child = subprocess.Popen(args, env=env, cwd=owned, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
        timed_out = False
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)
    return dict(exit=code, originalControllerPID=child.pid, originalControllerJoined=True, timedOut=timed_out)
save()
try:
    install = run(['npm','install','--prefix',str(owned/'install'),'--ignore-scripts','--no-audit','--no-fund',meta['package']], 'install', 180)
    record['install'] = install
    assert install['exit'] == 0
    package = owned/'install/node_modules/@rynfar/meridian'
    sdk = json.loads((owned/'install/node_modules/@anthropic-ai/claude-agent-sdk/package.json').read_text())['version']
    assert sdk == '0.2.141', sdk
    for backend in ['sqlite', 'json']:
        for mode in ['normal','close','stdout','stderr']:
            name = backend+'-'+mode
            fixture = owned/name
            fixture.mkdir(mode=0o700)
            case = run(['node',str(harness),str(package),str(fixture),mode,'corrected',backend], name, 45)
            case['case'] = name
            lines = (art/(name+'.log')).read_text().splitlines()
            reports = [json.loads(line.removeprefix('INSTALLED_GC_REPORT ')) for line in lines if line.startswith('INSTALLED_GC_REPORT ')]
            case['report'] = reports[-1] if reports else None
            record['cases'].append(case)
            save()
            assert case['exit'] == 0 and len(reports) == 1
            report = reports[0]
            assert report['result'] == 'PASS'
            assert all(report[key] == 0 for key in ['upstreamModelRequests','credentialCommands','foreignRequests'])
            assert report['after']['actors'] and all(all(actor[key] for key in ['exit','close','stdout','stderr']) for actor in report['after']['actors'])
            assert all(actor['originalExitAndPipesJoined'] for actor in report['guardProbeActors'])
            shutil.rmtree(fixture)
            case['fixtureRemoved'] = True
            save()
    record.update(result='PASS', independentInstall=True,
                  olderHoldsUnchanged=hashlib.sha256(hold.read_bytes()).hexdigest()==hold_sha,
                  scriptBytesUnchanged=all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha for path,sha in seal.items()))
    assert record['olderHoldsUnchanged'] and record['scriptBytesUnchanged']
    shutil.rmtree(owned)
    record['installsAndCacheRemoved'] = True
except BaseException as error:
    record.update(result='FAIL', failure=type(error).__name__+': '+str(error)[:500])
finally:
    record['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key:record.get(key) for key in ['head','platform','result','failure','models','installsAndCacheRemoved']}),flush=True)
raise SystemExit(0 if record['result']=='PASS' else 1)
