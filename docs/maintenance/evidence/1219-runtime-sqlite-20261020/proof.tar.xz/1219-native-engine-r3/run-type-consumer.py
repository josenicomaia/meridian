from pathlib import Path
import subprocess, json, tempfile, shutil, os, datetime, hashlib
out=Path(__file__).parent
target=out/'type-consumer';target.mkdir(exist_ok=False)
meta=json.loads((out/'package-identity.json').read_text())
owned=Path(tempfile.mkdtemp(prefix='meridian-1219-type-consumer-'));owned.chmod(0o700)
(owned/'home').mkdir();(owned/'cache').mkdir()
env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']}
env.update(HOME=str(owned/'home'),npm_config_cache=str(owned/'cache'))
record=dict(head=meta['head'],packageSHA256=meta['packageSHA256'],models=0,result='RUNNING',started=datetime.datetime.now(datetime.timezone.utc).isoformat())
def command(label,args):
 with(target/(label+'.log')).open('w')as log:
  child=subprocess.Popen(args,cwd=owned,env=env,stdout=log,stderr=subprocess.STDOUT)
  code=child.wait(timeout=180)
 record[label]=dict(exit=code,originalPID=child.pid,joined=True)
 return code
try:
 assert command('install',['npm','install','--ignore-scripts','--no-audit','--no-fund',meta['package'],'typescript@5.9.3','@types/node@22.19.7'])==0
 assert not (owned/'node_modules/@types/bun').exists()
 source='''import {initializeProxyBookkeeping, createProxyServer, startProxyServer, type ProxyBookkeepingHandle} from '@rynfar/meridian';
const opaque: Exclude<keyof ProxyBookkeepingHandle, 'close'> extends never ? true : false = true;
const initializer: () => Promise<ProxyBookkeepingHandle | undefined> = initializeProxyBookkeeping;
async function embedded() {
 const owner = await initializer();
 const server = createProxyServer({});
 const running = await startProxyServer({port:0});
 const first: Promise<void> = running.close();
 await first; await owner?.close(); return server;
}
void opaque; void embedded;
'''
 (target/'consumer.ts').write_text(source);(owned/'consumer.ts').write_text(source)
 args=['node',str(owned/'node_modules/typescript/bin/tsc'),'--noEmit','--strict','--target','ES2022','--module','ESNext','--moduleResolution','Bundler','--types','node','consumer.ts']
 assert command('positive',args)==0
 negative="import { initializeProxyBookkeeping } from '@rynfar/meridian';\nconst handle = await initializeProxyBookkeeping();\nif (handle) { handle.reader; handle.path; handle.query; }\n"
 (target/'negative.ts').write_text(negative);(owned/'consumer.ts').write_text(negative)
 assert command('negative',args)!=0
 log=(target/'negative.log').read_text()
 assert all("Property '"+name+"' does not exist on type 'ProxyBookkeepingHandle'"in log for name in ['reader','path','query'])
 record.update(result='PASS',bunTypesInstalled=False,typescript='5.9.3',nodeTypes='22.19.7',opaqueHandleOnlyClose=True,privateReaderPathQueryRejected=True)
 shutil.rmtree(owned);record['installAndCacheRemoved']=True
except BaseException as error:
 record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:400],ownedRoot=str(owned))
finally:
 record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['scriptSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (target/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['result']=='PASS'else 1)
