from pathlib import Path
import subprocess,os,json,hashlib,datetime,signal
r=Path('/tmp/meridian-resume-20261020');out=r/'1219-native-engine-r3/packages-linux-ext4';meta=json.loads((out/'preparation.json').read_text());observer=out/'custody-observer.mjs';script=out/'harness/scripts/e2e-session-bookkeeping-packaged.mjs';assert not(out/'ATTEMPT.json').exists();seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [observer,script,Path(__file__),*list((out/'harness/scripts/fixtures').glob('*.mjs'))]};hold=r/'LIVE_MODEL_HOLD.json';before=hashlib.sha256(hold.read_bytes()).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':meta['scope'],'source':meta['head'],'scripts':seal,'models':0,'result':'RUNNING'};(out/'ATTEMPT.json').write_text(json.dumps(record,indent=2)+'\n');env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env['E2E_CUSTODY_ROOT']=str(out/'custody');args=['node','--import',str(observer),str(script),'--package',meta['candidateTar'],'--baseline-package',meta['baselineTar']]
with(out/'run.log').open('w')as log:
 process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['originalControllerPID']=process.pid
 try:code=process.wait(timeout=600)
 except subprocess.TimeoutExpired:
  record['timeout']=True
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:record['groupGoneBeforeTERM']=True
  try:code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
lines=(out/'run.log').read_text().splitlines();verdict=next((json.loads(line)for line in reversed(lines)if line.startswith('{"verdict":')),None);actors=[json.loads(p.read_text())for p in(out/'custody').glob('*.json')];record.update(exit=code,verdict=verdict,actorReports=len(actors),allOriginalActorsJoined=all(x['joined']for x in actors),forbiddenAttempts=[x for row in actors for x in row['forbidden']],olderHoldsUnchanged=hashlib.sha256(hold.read_bytes()).hexdigest()==before,scriptBytesUnchanged=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in seal.items()));record['result']='PASS'if code==0 and verdict and verdict['verdict']=='PASS'and actors and record['allOriginalActorsJoined']and not record['forbiddenAttempts']and record['olderHoldsUnchanged']and record['scriptBytesUnchanged']else'FAIL';(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True);raise SystemExit(0 if record['result']=='PASS'else 1)
