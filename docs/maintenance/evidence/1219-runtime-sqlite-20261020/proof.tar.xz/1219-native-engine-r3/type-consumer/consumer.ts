import {initializeProxyBookkeeping, createProxyServer, startProxyServer, type ProxyBookkeepingHandle} from '@rynfar/meridian';
const opaque: Exclude<keyof ProxyBookkeepingHandle, 'close'> extends never ? true : false = true;
const initializer: () => Promise<ProxyBookkeepingHandle | undefined> = initializeProxyBookkeeping;
async function embedded() {
 const owner = await initializer();
 const server = createProxyServer({});
 const running = await startProxyServer({port:0});
 const first: Promise<void> = running.close();
 await first; await owner?.close(); return server;
}
void opaque; void embedded;
