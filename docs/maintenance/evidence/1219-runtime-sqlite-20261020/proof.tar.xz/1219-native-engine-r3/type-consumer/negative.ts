import { initializeProxyBookkeeping } from '@rynfar/meridian';
const handle = await initializeProxyBookkeeping();
if (handle) { handle.reader; handle.path; handle.query; }
