import { createProxyServer, startProxyServer } from '@rynfar/meridian';
const server=createProxyServer({}); const proxy=await startProxyServer({port:0}); await proxy.close(); void server;
