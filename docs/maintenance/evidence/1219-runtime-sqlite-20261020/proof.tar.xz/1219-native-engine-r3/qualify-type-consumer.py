from pathlib import Path
import subprocess,json,os,shutil,re,hashlib,datetime
out=Path(__file__).parent;target=out/'type-consumer';prior=json.loads((target/'result.json').read_text())
assert prior['result']=='FAIL' and prior['install']['exit']==0 and prior['positive']['exit']==2
owned=Path(prior['ownedRoot']);assert owned.name.startswith('meridian-1219-type-consumer-')
env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(HOME=str(owned/'home'),npm_config_cache=str(owned/'cache'))
args=['node',str(owned/'node_modules/typescript/bin/tsc'),'--noEmit','--strict','--target','ES2022','--module','ESNext','--moduleResolution','Bundler','--types','node','consumer.ts']
record=dict(head=prior['head'],result='RUNNING',models=0,commands=[],started=datetime.datetime.now(datetime.timezone.utc).isoformat())
def run(label,command):
 with(target/(label+'.log')).open('w')as log:
  child=subprocess.Popen(command,cwd=owned,env=env,stdout=log,stderr=subprocess.STDOUT);code=child.wait(timeout=180)
 record['commands'].append(dict(label=label,exit=code,originalPID=child.pid,joined=True))
 return code
try:
 assert run('current-project-library-policy',args+['--skipLibCheck'])==0
 assert run('current-declaration-graph',args+['--listFilesOnly'])==0
 graph=(target/'current-declaration-graph.log').read_text()
 assert '@types/bun/'not in graph and 'bookkeeping/nativeDatabase.d.ts'not in graph
 negative="import { initializeProxyBookkeeping } from '@rynfar/meridian';\nconst handle = await initializeProxyBookkeeping();\nif (handle) { handle.reader; handle.path; handle.query; }\n"
 (target/'negative.ts').write_text(negative);(owned/'consumer.ts').write_text(negative)
 assert run('current-negative',args+['--skipLibCheck'])==2
 log=(target/'current-negative.log').read_text()
 assert all("Property '"+name+"' does not exist on type 'ProxyBookkeepingHandle'"in log for name in ['reader','path','query'])
 assert len(log.splitlines())==3
 # The same stock SDK declarations must reproduce every initial error through
 # the published package's established API before classifying them as upstream.
 baseline=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz')
 assert run('published-baseline-install',['npm','install','--ignore-scripts','--no-audit','--no-fund',str(baseline)])==0
 baseline_source="import { createProxyServer, startProxyServer } from '@rynfar/meridian';\nconst server=createProxyServer({}); const proxy=await startProxyServer({port:0}); await proxy.close(); void server;\n"
 (target/'published-consumer.ts').write_text(baseline_source);(owned/'consumer.ts').write_text(baseline_source)
 assert run('published-baseline-strict-library',args)==2
 def errors(path):return sorted(re.findall(r'^node_modules/@anthropic-ai/claude-agent-sdk/.*$',path.read_text(),re.M))
 before=errors(target/'positive.log');after=errors(target/'published-baseline-strict-library.log')
 assert before and before==after
 assert all(line.startswith('node_modules/@anthropic-ai/claude-agent-sdk/')for line in(target/'positive.log').read_text().splitlines())
 assert run('published-baseline-project-library-policy',args+['--skipLibCheck'])==0
 record.update(result='PASS_WITH_EXISTING_SDK_LIMITATION',projectLibraryPolicy='skipLibCheck (matches repository)',upstreamSDKStrictLibraryErrors=len(before),identicalPublishedBaselineErrors=True,bunTypesInstalled=False,privateNativeDeclarationReachable=False,privateReaderPathQueryRejected=True,publishedTarSHA256=hashlib.sha256(baseline.read_bytes()).hexdigest())
 shutil.rmtree(owned);record['installAndCacheRemoved']=True
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:400])
finally:
 record['scriptSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(target/'qualification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['result']=='PASS_WITH_EXISTING_SDK_LIMITATION'else 1)
