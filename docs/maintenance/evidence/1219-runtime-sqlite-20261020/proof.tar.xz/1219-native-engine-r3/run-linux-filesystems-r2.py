from pathlib import Path
import subprocess,json,os,tempfile,shutil,datetime,hashlib
out=Path(__file__).parent
record=dict(result='RUNNING',models=0,cases=[],started=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Owned loop images only; no existing device is formatted or detached')
def save():(out/'linux-filesystem-r2-result.json').write_text(json.dumps(record,indent=2)+'\n')
def command(args,log,check=True):
 p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 if check:assert p.returncode==0,args[0]
 return p.returncode
try:
 with(out/'linux-filesystem-r2-tools.log').open('w')as log:
  command(['apt-get','update','-qq'],log)
  command(['apt-get','install','-y','--no-install-recommends','btrfs-progs','xfsprogs'],log)
 Path('/etc/machine-id').write_text(os.urandom(16).hex()+'\n')
 for fs,magic in [('ext4',0xef53),('btrfs',0x9123683e),('xfs',0x58465342)]:
  art=out/('packages-linux-'+fs+'-r2');owned=Path(tempfile.mkdtemp(prefix='meridian-1219-loop-'+fs+'-'));image=owned/'fixture.img';mount=owned/'mount';mount.mkdir();device=None;mounted=False
  row=dict(filesystem=fs,result='RUNNING',ownedImage=str(image));record['cases'].append(row);save()
  try:
   with image.open('wb')as f:f.truncate(2*1024**3)
   with(art/'filesystem.log').open('w')as log:
    command(['mkfs.'+fs,'-f' if fs!='ext4'else'-F',str(image)],log)
    device=subprocess.check_output(['losetup','--find','--show',str(image)],text=True,timeout=30).strip();row['ownedLoopDevice']=device
    actual=subprocess.check_output(['losetup','--list','--json','--output','NAME,BACK-FILE',device],text=True,timeout=30);row['loopOwnership']=json.loads(actual)
    assert row['loopOwnership']['loopdevices'][0]['back-file']in [str(image),str(image).removeprefix('/tmp')]
    code=command(['mount',device,str(mount)],log,check=False);row['mountExit']=code
    if code:
     row['result']='HOST_UNAVAILABLE';continue
    mounted=True
    fsinfo=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import{statfsSync}from'node:fs';console.log(JSON.stringify(statfsSync(process.argv[1])))",str(mount)],text=True));row['statfs']=fsinfo;assert fsinfo['type']&0xffffffff==magic
    env=dict(os.environ,TMPDIR=str(mount))
    child=subprocess.Popen(['python3',str(art/'run-inside.py')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['controllerPID']=child.pid;row['exit']=child.wait(timeout=600)
    proof=json.loads((art/'result.json').read_text());assert row['exit']==0 and proof['result']=='PASS' and proof['allOriginalActorsJoined']
    row['result']='PASS'
  finally:
   if mounted:
    p=subprocess.run(['umount',str(mount)],capture_output=True,timeout=60);row['unmountExit']=p.returncode;assert p.returncode==0
   if device:
    # Verify the returned device still belongs to this exact image before detach.
    info=json.loads(subprocess.check_output(['losetup','--list','--json','--output','NAME,BACK-FILE',device],text=True,timeout=30));assert info['loopdevices'][0]['back-file']in [str(image),str(image).removeprefix('/tmp')]
    p=subprocess.run(['losetup','--detach',device],capture_output=True,timeout=30);row['detachExit']=p.returncode;assert p.returncode==0
   shutil.rmtree(owned);row['imageAndMountRemoved']=True;save()
 assert all(row['result']in ['PASS','HOST_UNAVAILABLE']for row in record['cases'])
 record['result']='PASS_AVAILABLE_FILESYSTEMS' if any(row['result']=='HOST_UNAVAILABLE'for row in record['cases'])else'PASS'
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:500])
finally:
 record['scriptSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(record),flush=True)
raise SystemExit(1 if record['result']=='FAIL'else 0)
