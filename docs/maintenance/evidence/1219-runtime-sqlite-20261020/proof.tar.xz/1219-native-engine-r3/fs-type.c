#include <sys/mount.h>
#include <stdio.h>
int main(int argc, char **argv) {
  struct statfs value;
  if (argc != 2 || statfs(argv[1], &value) != 0) return 1;
  printf("{\"type\":%u,\"name\":\"%s\"}\n", value.f_type, value.f_fstypename);
  return 0;
}
