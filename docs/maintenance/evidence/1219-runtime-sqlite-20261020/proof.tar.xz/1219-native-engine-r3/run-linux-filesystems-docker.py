from pathlib import Path
import subprocess,json,datetime
out=Path(__file__).parent;r=out.parent;name='meridian-1219-owned-filesystems-r3'
args=['docker','run','--rm','--init','--privileged','--name',name,'--label','meridian.backlog=1219-filesystems-20261020','--tmpfs','/tmp:rw,exec,mode=1777,size=5g','-v',str(r)+':'+str(r),'node:24.20.0-bookworm','python3',str(out/'run-linux-filesystems.py')]
record=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),container=name,models=0)
with(out/'linux-filesystem-docker.log').open('w')as log:
 child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);record['originalDockerPID']=child.pid
 try:record['exit']=child.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  record['timeout']=True;subprocess.run(['docker','stop','-t','10',name],stdout=log,stderr=subprocess.STDOUT,timeout=30);record['exit']=child.wait(timeout=15)
record['containerRemoved']=subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'linux-filesystem-docker-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['exit']==0 and record['containerRemoved']else 1)
