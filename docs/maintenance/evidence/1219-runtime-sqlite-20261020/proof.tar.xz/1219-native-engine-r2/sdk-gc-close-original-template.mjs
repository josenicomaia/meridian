// Stock Node, independently installed bundle, actual SDK deleteSession. No inference.
import assert from 'node:assert/strict'
import cp from 'node:child_process'
import {syncBuiltinESMExports, createRequire} from 'node:module'
import {mkdirSync, writeFileSync, realpathSync, readFileSync} from 'node:fs'
import {join, dirname} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash, randomUUID} from 'node:crypto'
import {createServer} from 'node:http'
import {once} from 'node:events'
const [packageRoot, rawRoot, mode, expectation, backend = 'sqlite'] = process.argv.slice(2)
assert(['normal','close','stdout','stderr'].includes(mode))
assert(['corrected','baseline'].includes(expectation))
assert(['json','sqlite'].includes(backend))
const root = realpathSync(rawRoot), directory = join(root,'sessions'), native = join(root,'native')
process.chdir(root)
for (const path of [directory,native,join(root,'home'),join(root,'config')]) mkdirSync(path,{mode:0o700})
Object.assign(process.env,{HOME:join(root,'home'),CLAUDE_CONFIG_DIR:native,MERIDIAN_CONFIG_DIR:join(root,'config'),
 MERIDIAN_SESSION_DIR:directory,MERIDIAN_BOOKKEEPING:backend,MERIDIAN_ROUTING:'manual',MERIDIAN_CREDENTIALS_READONLY:'1',
 MERIDIAN_NO_UPDATE_CHECK:'1',MERIDIAN_SESSION_GC_INTERVAL_MS:'0',MERIDIAN_SESSION_GC_GRACE_MS:'0',
 MERIDIAN_SESSION_GC_DELETE_TIMEOUT_MS:'1000',MERIDIAN_SESSION_GC_HANDSHAKE_TIMEOUT_MS:'1000'})
const sessionId=randomUUID(), key=createHash('sha256').update(native).update('\0').update(sessionId).digest('hex')
// Owned Meridian metadata only: no SDK transcript is read or manufactured.
writeFileSync(join(directory,'session-gc.json'),JSON.stringify({version:1,resources:{[key]:{
 key,locator:{sessionId,configDir:native,projectDir:root},state:'retired',createdAt:1,updatedAt:1,attempts:0}}})+'\n',{mode:0o600})
if(backend==='sqlite'){
const migration=cp.spawnSync(process.execPath,[join(packageRoot,'dist/session-bookkeeping.js'),'migrate','--session-dir',directory,'--writers-stopped','--json'],
 {env:process.env,encoding:'utf8',timeout:30000})
assert.equal(migration.status,0,migration.stderr)
}
let upstreamModelRequests=0, reachabilityRequests=0, credentialCommands=0, foreignRequests=0
const upstream=createServer((request,response)=>{
 if(request.method==='HEAD'&&request.url==='/api/hello'){reachabilityRequests++;response.writeHead(200).end();return}
 upstreamModelRequests++;response.writeHead(503).end('Owned fixture refuses inference')
})
upstream.listen(0,'127.0.0.1');await once(upstream,'listening')
const origin='http://127.0.0.1:'+upstream.address().port
const originalFetch=globalThis.fetch
 globalThis.fetch=(input,options)=>{const url=new URL(typeof input==='string'||input instanceof URL?input:input.url)
 if(url.origin!==origin){foreignRequests++;throw new Error('Owned fixture refuses foreign HTTP')}
 return originalFetch(input,options)}
const actors=[], originalSpawn=cp.spawn, originalExecFile=cp.execFile, originalSpawnSync=cp.spawnSync
let replay, withheld=false, proxy, closeOutcome='pending', closeError, before, after
const observe=(child,deletion)=>{
 const row={pid:child.pid,deletion,exit:false,close:false,stdout:!child.stdout,stderr:!child.stderr}
 const closed=new Promise((resolve,reject)=>{
  child.once('error',reject);child.once('exit',()=>row.exit=true);child.once('close',()=>{row.close=true;resolve()})
 })
 void closed.catch(()=>undefined)
 child.stdout?.once('close',()=>row.stdout=true);child.stderr?.once('close',()=>row.stderr=true)
 actors.push({child,row,closed})
 if(deletion&&mode!=='normal'){
  const target=mode==='close'?child:child[mode], emit=target.emit
  target.emit=function(event,...values){
   if(event==='close'&&!withheld){withheld=true;replay=()=>{target.emit=emit;return emit.call(target,event,...values)};return true}
   return emit.call(this,event,...values)
  }
 }
 return child
}
const forbidCredentialCommand=(command)=>{if(/(^|[\/])security$/.test(command)){credentialCommands++;throw new Error('Owner credential command forbidden')}}
cp.spawn=function(command,args,options){forbidCredentialCommand(command);return observe(Reflect.apply(originalSpawn,this,[command,args,options]),Boolean(options?.env?.MERIDIAN_GC_SESSION_ID))}
cp.execFile=function(command,...args){forbidCredentialCommand(command);return observe(Reflect.apply(originalExecFile,this,[command,...args]),false)}
cp.spawnSync=function(command,...args){forbidCredentialCommand(command);return Reflect.apply(originalSpawnSync,this,[command,...args])}
syncBuiltinESMExports()
const require=createRequire(join(packageRoot,'package.json')), Database=backend==='sqlite'?require('libsql'):null
const guardAvailable=()=>{
 if(backend==='json')return null
 const db=new Database(join(directory,'session-bookkeeping-maintenance.sqlite'))
 try{db.pragma('busy_timeout=0');db.exec('BEGIN EXCLUSIVE');db.exec('ROLLBACK');return true}
 catch(error){assert(/SQLITE_BUSY|SQLITE_LOCKED/.test(error.code??''),error.message);return false}
 finally{db.close()}
}
const waitUntil=async(check,ms)=>{const limit=Date.now()+ms;while(!check()){assert(Date.now()<limit,'Observation deadline exceeded');await new Promise(resolve=>setTimeout(resolve,25))}}
try{
 const api=await import(pathToFileURL(join(packageRoot,'dist/server.js')).href)
 proxy=await api.startProxyServer({port:0,host:'127.0.0.1',silent:true,profiles:[{id:'owned-api',type:'api',apiKey:'owned-not-provider',baseUrl:origin}],defaultProfile:'owned-api'})
 await waitUntil(()=>actors.some(actor=>actor.row.deletion),10000)
 if(mode==='normal')await waitUntil(()=>actors.filter(actor=>actor.row.deletion).every(actor=>actor.row.close&&actor.row.stdout&&actor.row.stderr),10000)
 else{await waitUntil(()=>withheld,10000);await new Promise(resolve=>setTimeout(resolve,2300))}
 const close=proxy.close();assert.equal(proxy.close(),close)
 close.then(()=>closeOutcome='fulfilled',error=>{closeOutcome='rejected';closeError=error.message})
 await waitUntil(()=>closeOutcome!=='pending',5000)
 before={closeOutcome,guardAvailable:guardAvailable(),withheld}
 assert.equal(actors.filter(actor=>actor.row.deletion).length,1,'A second deletion began before the original child and pipes joined')
 if(mode==='normal')assert.deepEqual(before,{closeOutcome:'fulfilled',guardAvailable:backend==='sqlite'?true:null,withheld:false})
 else if(expectation==='baseline')assert.deepEqual(before,{closeOutcome:'fulfilled',guardAvailable:backend==='sqlite'?true:null,withheld:true})
 else assert.deepEqual(before,{closeOutcome:'rejected',guardAvailable:backend==='sqlite'?false:null,withheld:true})
 replay?.();await Promise.all(actors.map(actor=>actor.closed))
 if(backend==='sqlite')await waitUntil(()=>guardAvailable(),5000)
 after={guardAvailable:guardAvailable(),actors:actors.map(actor=>actor.row)}
 assert(after.actors.every(actor=>actor.exit&&actor.close&&actor.stdout&&actor.stderr),'Original actor or pipe remains unjoined')
 assert.equal(credentialCommands,0);assert.equal(foreignRequests,0);assert.equal(upstreamModelRequests,0)
 console.log('INSTALLED_GC_REPORT '+JSON.stringify({result:'PASS',expectation,mode,backend,node:process.version,platform:process.platform,architecture:process.arch,
 sdk:JSON.parse(readFileSync(join(dirname(require.resolve('@anthropic-ai/claude-agent-sdk')),'package.json'),'utf8')).version,before,after,closeError,reachabilityRequests,upstreamModelRequests,credentialCommands,foreignRequests,
 control:'withheld original close witness; not organically lingering OS pipe',surface:'installed dist/server.js public HTTP instance.close and actual SDK deleteSession'}))
}finally{
 replay?.();if(proxy)await proxy.close().catch(()=>undefined)
 for(const actor of actors)if(actor.child.exitCode===null&&actor.child.signalCode===null)actor.child.kill('SIGKILL')
 await Promise.allSettled(actors.map(actor=>actor.closed))
 cp.spawn=originalSpawn;cp.execFile=originalExecFile;cp.spawnSync=originalSpawnSync;syncBuiltinESMExports();globalThis.fetch=originalFetch
 await new Promise((resolve,reject)=>upstream.close(error=>error?reject(error):resolve()))
}
