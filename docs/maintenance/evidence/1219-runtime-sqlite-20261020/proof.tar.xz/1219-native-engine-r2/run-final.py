from pathlib import Path
import subprocess, json, os, datetime, hashlib

out=Path('/tmp/meridian-resume-20261020/1219-native-engine-r2')
meta=json.loads((out/'final-source.json').read_text())
source=Path(meta['candidate'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==meta['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
assert hashlib.sha256(Path(meta['library']).read_bytes()).hexdigest()==meta['librarySHA256']
env=dict(os.environ,PATH='/tmp/meridian-1399-tooling/node_modules/.bin:'+os.environ['PATH'],
         MERIDIAN_TEST_SQLITE_LIBRARY=meta['library'],BOOKKEEPING_COMPAT_TARBALL=meta['compatTar'])
(out/'final-pack').mkdir(exist_ok=False)
record={'head':meta['head'],'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'commands':[],'exit':None,'compatIntegrityVerified':True,'sourceFrozen':True}
for label,args in [('typecheck',['npm','run','typecheck']),('build',['npm','run','build']),
                   ('pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(out/'final-pack')]),
                   ('full',['npm','test'])]:
    (out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n')
    with(out/('final-'+label+'.log')).open('w')as log:
        code=subprocess.run(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    record['commands'].append({'label':label,'exit':code})
    (out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n')
    print(label,code,flush=True)
    if code:
        record['exit']=code
        break
else:
    record['exit']=0
record['sourceBytesUnchanged']=not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(record['exit'])
