// src/proxy/session/bookkeeping/nativeDatabase.ts
import { createRequire } from "node:module";

// src/proxy/session/lifecycleErrors.ts
class SessionLifecycleError extends Error {
}

// src/proxy/session/bookkeeping/storagePaths.ts
class BookkeepingMaintenanceRequiredError extends SessionLifecycleError {
}

// src/proxy/session/bookkeeping/nativeDatabase.ts
var nativeRequire = createRequire(import.meta.url);
var qualifiedEngine;
function hasWalResetFix(version) {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
  if (!match)
    return false;
  const major = Number(match[1]), minor = Number(match[2]), patch = Number(match[3]);
  return major === 3 && (minor > 51 || minor === 51 && patch >= 3 || minor === 50 && patch >= 7 || minor === 44 && patch >= 6);
}
function openDriver(filename, options) {
  if (process.versions.bun) {
    const { Database, constants } = nativeRequire("bun:sqlite");
    const access = options?.readonly ? constants.SQLITE_OPEN_READONLY : constants.SQLITE_OPEN_READWRITE | constants.SQLITE_OPEN_CREATE;
    return new Database(filename, access | constants.SQLITE_OPEN_URI);
  }
  const { DatabaseSync } = nativeRequire("node:sqlite");
  return new DatabaseSync(filename, { readOnly: options?.readonly });
}
function closeDriver(driver) {
  if ("isTransaction" in driver)
    driver.close();
  else
    driver.close(true);
}
function bookkeepingEngineInfo() {
  if (qualifiedEngine)
    return qualifiedEngine;
  let probe;
  try {
    probe = openDriver(":memory:");
  } catch (cause) {
    throw new BookkeepingMaintenanceRequiredError("SQLite bookkeeping requires a runtime with builtin SQLite; use Node 22.22.3 or a qualified newer runtime", { cause });
  }
  let qualified;
  try {
    const statement = probe.prepare("SELECT sqlite_version() AS version, sqlite_source_id() AS sourceId");
    let row;
    try {
      row = statement.get();
    } finally {
      if ("finalize" in statement)
        statement.finalize();
    }
    if (!row || typeof row !== "object" || !("version" in row) || typeof row.version !== "string" || !("sourceId" in row) || typeof row.sourceId !== "string") {
      throw new BookkeepingMaintenanceRequiredError("native SQLite provenance is unavailable");
    }
    if (!hasWalResetFix(row.version)) {
      throw new BookkeepingMaintenanceRequiredError(`SQLite ${row.version} lacks the qualified WAL-reset fix; use Node 22.22.3+ or configure a patched Bun SQLite library before initialization`);
    }
    qualified = Object.freeze({ version: row.version, sourceId: row.sourceId });
  } finally {
    closeDriver(probe);
  }
  qualifiedEngine = qualified;
  return qualified;
}
function copyRow(row) {
  if (!row || typeof row !== "object" || Array.isArray(row))
    throw new Error("invalid native SQLite row");
  return { ...row };
}

class NativeStatement {
  driver;
  sql;
  constructor(driver, sql) {
    this.driver = driver;
    this.sql = sql;
  }
  use(operation) {
    const statement = this.driver.prepare(this.sql);
    try {
      return operation(statement);
    } finally {
      if ("finalize" in statement)
        statement.finalize();
    }
  }
  get(...parameters) {
    const row = this.use((statement) => statement.get(...parameters));
    return row === null || row === undefined ? undefined : copyRow(row);
  }
  all(...parameters) {
    return this.use((statement) => statement.all(...parameters)).map(copyRow);
  }
  run(...parameters) {
    const result = this.use((statement) => statement.run(...parameters));
    const row = new NativeStatement(this.driver, "SELECT changes() AS changes").get();
    if (!row || typeof row.changes !== "number" || !Number.isSafeInteger(row.changes)) {
      throw new Error("invalid native SQLite mutation count");
    }
    return { changes: row.changes, lastInsertRowid: result.lastInsertRowid };
  }
}

class NativeDatabase {
  driver;
  closed = false;
  constructor(filename, options) {
    bookkeepingEngineInfo();
    this.driver = openDriver(filename, options);
  }
  get inTransaction() {
    if (this.closed)
      return false;
    return "isTransaction" in this.driver ? this.driver.isTransaction : this.driver.inTransaction;
  }
  prepare(sql) {
    return new NativeStatement(this.driver, sql);
  }
  exec(sql) {
    this.driver.exec(sql);
  }
  pragma(setting) {
    return this.prepare(`PRAGMA ${setting}`).all();
  }
  close() {
    if (this.closed)
      return;
    closeDriver(this.driver);
    this.closed = true;
  }
}
export {
  hasWalResetFix,
  bookkeepingEngineInfo,
  NativeDatabase
};
