import Database from "better-sqlite3"
import { BookkeepingMaintenanceRequiredError } from "./storagePaths"

export type NativeDatabase = Database.Database
type NativeDatabaseOptions = Database.Options
type EngineInfo = Readonly<{ version: string; sourceId: string }>
let engine: EngineInfo | undefined

/** Versions with the official WAL-reset fix, including the two upstream backports. */
export function hasWalResetFix(version: string): boolean {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version)
  if (!match) return false
  const [, majorText, minorText, patchText] = match
  const major = Number(majorText), minor = Number(minorText), patch = Number(patchText)
  return major === 3 && (minor > 51 || (minor === 51 && patch >= 3)
    || (minor === 50 && patch >= 7) || (minor === 44 && patch >= 6))
}

/** Reject affected Bun releases before entering the native constructor. */
export function assertBookkeepingRuntime(bunVersion: string | undefined): void {
  if (bunVersion === undefined) return
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(bunVersion)
  if (match) {
    const [, majorText, minorText, patchText] = match
    const major = Number(majorText), minor = Number(minorText), patch = Number(patchText)
    if (major > 1 || (major === 1 && (minor > 4 || (minor === 4 && patch >= 3)))) return
  }
  throw new BookkeepingMaintenanceRequiredError(
    `SQLite bookkeeping requires Node 22+ or Bun 1.4.3+; Bun ${bunVersion} cannot use the qualified native binding`,
  )
}

/** Qualify the loaded addon in memory before it can open any persistent main/guard inode. */
export function bookkeepingEngineInfo(): EngineInfo {
  assertBookkeepingRuntime(process.versions.bun)
  if (engine) return engine
  const probe = new Database(":memory:")
  let qualified: EngineInfo
  try {
    const row = probe.prepare("SELECT sqlite_version() AS version, sqlite_source_id() AS sourceId").get()
    if (!row || typeof row !== "object" || !("version" in row) || typeof row.version !== "string"
      || !("sourceId" in row) || typeof row.sourceId !== "string" || !hasWalResetFix(row.version)) {
      throw new BookkeepingMaintenanceRequiredError("native SQLite lacks qualified WAL-reset provenance")
    }
    qualified = Object.freeze({ version: row.version, sourceId: row.sourceId })
  } finally {
    // An uncertain in-memory close cannot strand a persistent main/guard lock.
    // Do not cache qualification until that original native handle closes.
    probe.close()
  }
  engine = qualified
  return engine
}

export function openNativeDatabase(filename: string, options?: NativeDatabaseOptions): NativeDatabase {
  bookkeepingEngineInfo()
  return new Database(filename, options)
}
