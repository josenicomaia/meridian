from pathlib import Path
import subprocess,json,datetime,sys,os
out=Path(__file__).parent;r=out.parent.parent;mode=sys.argv[1];assert mode in ['offline','live'];name='meridian-1219-node-client-'+mode+'-r1'
bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve('/usr/bin/python3',['python3',"+json.dumps(str(out/'run-inside.py'))+","+json.dumps(mode)+"],process.env)"
args=['docker','run','--rm','--init','--name',name,'--label','meridian.backlog=1219-real-client-20261020','--tmpfs','/tmp:rw,exec,mode=1777,size=3g','-v',str(r)+':'+str(r),'-v','/tmp/meridian-issue-r2-evidence/linux-runtime:/runtime:ro','-v',str(r/'opencode2031-tooling')+':/client:ro']
if mode=='live':
 grant=os.environ['E2E_NODE_CLIENT_GRANT'];guard=os.environ['E2E_NODE_CLIENT_GUARD'];args+=['-v',grant+':/grant.json:ro','-v',guard+':/guard.json:ro']
args+=['node:24.20.0-bookworm','node','-e',bootstrap]
record=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),container=name,mode=mode)
with(out/(mode+'-docker.log')).open('w')as log:
 child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);record['originalPID']=child.pid
 try:record['exit']=child.wait(timeout=780)
 except subprocess.TimeoutExpired:
  record['timeout']=True;subprocess.run(['docker','stop','-t','10',name],stdout=log,stderr=subprocess.STDOUT,timeout=30);record['exit']=child.wait(timeout=15)
record['containerRemoved']=subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/(mode+'-docker-result.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['exit']==0 and record['containerRemoved']else 1)
