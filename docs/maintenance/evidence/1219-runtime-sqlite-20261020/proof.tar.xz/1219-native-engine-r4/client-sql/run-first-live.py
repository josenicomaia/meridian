from pathlib import Path
import subprocess,json,hashlib,os,datetime
out=Path(__file__).parent;r=out.parent.parent;private=r/'private'
grant=private/'1219-engine-r4-client-sql-pool-grant.json';guard=private/'1219-engine-r4-client-sql-admission.json';attempt=out.parent/'client-sql-MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json'
assert not attempt.exists() and not grant.exists()
meta=json.loads((out.parent/'package-identity.json').read_text());source=Path(meta['candidate'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==meta['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
offline=json.loads((out/'offline-r1/controller.json').read_text());assert offline['result']=='PASS'and offline['head']==meta['head']
for path,digest in offline['scripts'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
record=dict(head=meta['head'],result='RUNNING',task='1219-engine-r4-client-sql-haiku55',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),olderHoldsSHA256=hashlib.sha256(hold.read_bytes()).hexdigest(),scripts={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),out/'create-live-grant.mjs',out/'run-docker.py']})
try:
 env=dict(os.environ,E2E_PHASE='client-sql',E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1')
 subprocess.run(['/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun',str(out/'create-live-grant.mjs')],env=env,cwd=source,check=True,timeout=30)
 record['admission']=json.loads(guard.read_text());assert record['admission']['maximumCases']==1
 attempt.write_text(json.dumps(record,indent=2)+'\n')
 env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(E2E_NODE_CLIENT_GRANT=str(grant),E2E_NODE_CLIENT_GUARD=str(guard))
 with(out/'first-live-task.log').open('w')as log:
  child=subprocess.Popen(['python3',str(out/'run-docker.py'),'live'],env=env,stdout=log,stderr=subprocess.STDOUT);record['originalControllerPID']=child.pid;record['exit']=child.wait(timeout=810)
 proof=json.loads((out/'live-r1/controller.json').read_text());docker=json.loads((out/'live-docker-result.json').read_text());record['generations']=proof.get('generations')
 assert record['exit']==0 and proof['result']=='PASS'and docker['containerRemoved']
 assert 0<record['generations']<=12
 record['result']='PASS'
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:500])
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['olderHoldsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==record['olderHoldsSHA256'];record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'first-live-task.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({key:record.get(key)for key in ['head','result','failure','generations','grantRemoved','olderHoldsUnchanged']}),flush=True)
raise SystemExit(0 if record['result']=='PASS'else 1)
