from pathlib import Path
import subprocess,json,os,tempfile,shutil,datetime,hashlib,signal,sys
out=Path(__file__).parent;mode=sys.argv[1];assert mode in ['offline','live']
target=out/(mode+'-r1');target.mkdir(exist_ok=False)
meta=json.loads((out.parent/'package-identity.json').read_text())
assert hashlib.sha256(Path(meta['package']).read_bytes()).hexdigest()==meta['packageSHA256']
owned=Path(tempfile.mkdtemp(prefix='meridian-1219-node-client-'));owned.chmod(0o700)
for name in ['home','install','cache']:(owned/name).mkdir(mode=0o700)
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [*out.rglob('*.mjs'),Path(__file__)]}
hold=out.parent.parent/'LIVE_MODEL_HOLD.json';oldHold=hashlib.sha256(hold.read_bytes()).hexdigest()
env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(HOME=str(owned/'home'),npm_config_cache=str(owned/'cache'))
record=dict(head=meta['head'],packageSHA256=meta['packageSHA256'],mode=mode,scope='Installed stock Node/Linux + actual OpenCode 2.0.31 plugin/scrub + actual SDK/native; SQL publication/export/remigration; offline means scripted provider only',result='RUNNING',scripts=seal,started=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():(target/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
def command(label,args,timeout):
 with(target/(label+'.log')).open('w')as log:
  child=subprocess.Popen(args,cwd=owned,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  timed=False
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=10)
 record[label]=dict(exit=code,originalPID=child.pid,joined=True,timedOut=timed);save();return code
save()
try:
 assert command('install',['npm','install','--prefix',str(owned/'install'),'--ignore-scripts','--no-audit','--no-fund',meta['package']],180)==0
 env.update(E2E_MERIDIAN_ROOT=str(owned/'install/node_modules/@rynfar/meridian'),E2E_OPENCODE_BIN='/client/opencode',E2E_NATIVE_BIN='/runtime/node_modules/@anthropic-ai/claude-code-linux-arm64/claude',E2E_NATIVE_VERSION='2.1.301',E2E_OPENCODE_VERSION='2.0.31',E2E_PLUGIN_PATH='/runtime/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js',E2E_SCRUB_VERSION='0.2.3',E2E_EVIDENCE_DIR=str(target),E2E_EXPECT='candidate')
 if mode=='live':
  env.update(E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE='/grant.json',E2E_USAGE_GUARD_FILE='/guard.json')
  assert (out/'offline-r1/controller.json').exists()and json.loads((out/'offline-r1/controller.json').read_text())['result']=='PASS'
 assert command('harness',['node',str(out/'harness.mjs'),'--live'if mode=='live'else'--aliases'],600)==0
 report=json.loads((target/'report.json').read_text());assert report['result']=='PASS'and report['joined']and report['fixtureRemoved']
 assert report['bookkeeping']['backend']=='sqlite'and report['bookkeeping']['engine']['version']=='3.53.4'
 assert report['providerNativeStoredCorrelated']
 record.update(result='PASS',generations=len(report['provider'])if mode=='live'else 0,scriptedGenerations=len(report['provider'])if mode=='offline'else 0,originalActorsJoined=report['joined'],fixtureRemoved=report['fixtureRemoved'],olderHoldsUnchanged=hashlib.sha256(hold.read_bytes()).hexdigest()==oldHold,scriptBytesUnchanged=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items()))
 assert record['olderHoldsUnchanged']and record['scriptBytesUnchanged']
 shutil.rmtree(owned);record['installAndCacheRemoved']=True
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:500])
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:record.get(k)for k in ['head','mode','result','failure','generations','installAndCacheRemoved']}),flush=True)
raise SystemExit(0 if record['result']=='PASS'else 1)
