from pathlib import Path
import re,json
w=Path('/Volumes/DevSSD/meridian/worktrees/codex-clear-completion-20261020');o=Path('/tmp/meridian-resume-20261020/issue917-diagnosis');original=w/'src/__tests__/proxy-extra-usage-fallback.test.ts';s=original.read_text();s=s.replace('expect, mock, beforeEach','expect, mock, beforeEach, spyOn');s=s.replace('let mockBehavior:', 'let unrelatedSdkDelayMs = 0\nlet mockBehavior:').replace(' | "error_assistant_then_ratelimit" =',' | "error_assistant_then_ratelimit" | "rate_limit_twice_then_succeed" =');s=s.replace('    return (async function* () {','''    return (async function* () {
      if (unrelatedSdkDelayMs && callIndex === 1) {
        await new Promise(resolve => setTimeout(resolve, unrelatedSdkDelayMs))
      }
      if (mockBehavior === "rate_limit_twice_then_succeed" && callIndex <= 2) {
        throw new Error("429 rate limit exceeded")
      }''',1);s=s.replace('    queryCallCount = 0','    unrelatedSdkDelayMs = 0\n    queryCallCount = 0',1)
start=s.index('  describe("No backoff needed", () => {');end=s.index('  describe("Real SDK behaviour:',start)
new='''  describe("backoff timers, independent of request duration", () => {
    for (const stream of [false, true]) {
      for (const scenario of ["extra-usage", "unrelated-delay", "rate-limit-control"] as const) {
        it(`${scenario}: observes the actual backoff timer (stream=${stream})`, async () => {
          const baseDelayMs = 317
          const previousDelay = process.env.MERIDIAN_RATE_LIMIT_BASE_DELAY_MS
          process.env.MERIDIAN_RATE_LIMIT_BASE_DELAY_MS = String(baseDelayMs)
          mockBehavior = scenario === "rate-limit-control" ? "rate_limit_twice_then_succeed" : "extra_usage_then_succeed"
          unrelatedSdkDelayMs = scenario === "unrelated-delay" ? 701 : 0
          const observer = spyOn(globalThis, "setTimeout")
          try {
            const app = createTestApp()
            const started = Date.now()
            const response = await post(app, { model:"sonnet", stream, messages:[{role:"user",content:"hello"}] })
            expect(response.status).toBe(200)
            if (stream) {
              const events = parseSSE(await response.text())
              expect(events.some(event => event.event === "error")).toBe(false)
              expect(events.filter(event => event.event === "message_stop")).toHaveLength(1)
            } else {
              expect((await response.json()).stop_reason).toBe("end_turn")
            }
            const elapsed = Date.now() - started
            const backoffTimers = observer.mock.calls.filter(([, delay]) => delay === baseDelayMs)
            expect(backoffTimers).toHaveLength(scenario === "rate-limit-control" ? 1 : 0)
            expect(queryCalls.map(call => call.model)).toEqual(scenario === "rate-limit-control"
              ? ["sonnet[1m]", "sonnet", "sonnet"] : ["sonnet[1m]", "sonnet"])
            console.log(JSON.stringify({scenario,stream,elapsedMs:elapsed,backoffTimers:backoffTimers.length,models:queryCalls.map(call=>call.model)}))
          } finally {
            observer.mockRestore()
            if (previousDelay === undefined) delete process.env.MERIDIAN_RATE_LIMIT_BASE_DELAY_MS
            else process.env.MERIDIAN_RATE_LIMIT_BASE_DELAY_MS = previousDelay
          }
        })
      }
    }
  })

'''
s=s[:start]+new+s[end:]
(o/'proposed-test-relative.ts').write_text(s)
def absolute(m):
 quote,path=m.groups();resolved=(original.parent/path).resolve();return quote+str(resolved)+quote
s=re.sub(r'(["\'])(\.{1,2}/[^"\']+)\1',absolute,s)
(o/'backoff-timer-probe.test.ts').write_text(s)
print('External source-only experiment prepared; candidate source remains unchanged.')
