The extra-usage fallback test inferred backoff from total HTTP time. The original CI case took1992ms against a500ms assertion, so unrelated SDK/filesystem latency could fail it. The current amplified test still uses a wall-clock ceiling. This change observes actual configured retry timers and asserts the SDK model sequence instead.

JSON and SSE each cover ordinary extra-usage fallback, a deliberately unrelated701ms SDK-fixture delay, and a real base-model rate-limit control. Extra usage schedules zero317ms backoff timers and queries extended→base. The rate-limit control schedules one real317ms timer and queries extended→base→base. The spy lets the timer implementation run. All original fallback/history/ownership assertions are retained.

Refs #917. The original tool-cache failure cited there is actually a5003.04ms Bun timeout, with the third request completing18ms afterward; existing #990 already raised that default to30s. The title-turn polling case was corrected by #997. The precise scheduling cause of the original1.94s extra-usage gap is not claimed. #933 remains broader tracking for other fast assertion failures.

The change is confined to `src/__tests__/proxy-extra-usage-fallback.test.ts`. The committed HTTP/mocked-SDK fixture is the reproducible gate; no actual model call is needed for this test assertion correction.

Validation at opening: all22 fixture cases pass. Restoring the old500ms assertion fails both unrelated-delay controls; deliberately filtering out the real timer fails both positive controls. Exact source bytes restored. The prepared prototype passes strict TypeScript. Final committed-head typecheck/build/full (with explicit verified published1.84 compatibility), CI including test and final adversarial review remain merge gates. #917 remains open until validated delivery.

[Original CI logs, source snapshots and prepared causal proof](https://github.com/rynfar/meridian/blob/d14b06dd7c8c968d8f195aa5dec2ce27207ad2cd/docs/maintenance/evidence/917-ci-timing-20261021/README.md). One active candidate/dependency tree is reused from completed #1433; no new worktree, dependency installation or Docker resource.
