**Validated closeout (2026-10-21):** [#1434](https://github.com/rynfar/meridian/pull/1434) merged as `be79072673a22f86cfa27851e63127bdf8656b77` after all26 full groups passed8070/36/0 (published1.84 compatibility enabled), typecheck/build and all8 executed final-head CI checks. [Original logs, exact source, causal controls and review](https://github.com/rynfar/meridian/blob/439e493f2b7597c420df41ed280c935c84ea4d55/docs/maintenance/evidence/917-ci-timing-20261021/README.md).

The two remaining cited failures are now accounted for. Run34315620193's tool-cache case hit Bun's5003.04ms timeout; the third request had restored both tools and completed18ms afterward. Existing #990's30s harness budget covers that expiry. The title-turn100ms poll was already replaced by #997's signals and positive lease control.

Run34315145910's extra-usage case failed a500ms total-request assertion at1992ms. The exact cause of its1.94s scheduling gap is not directly observed and is not claimed. Its replacement checks actual configured retry timers: JSON/SSE extra-usage calls schedule zero317ms backoff timers even with unrelated701ms SDK latency, while a real base-model rate-limit control schedules exactly one and takes the strict extended→base→base model sequence. All22 cases pass. Restoring the old wall-clock assertion fails both unrelated-delay controls; breaking the timer observer fails both positive controls. No production behavior or timeout budget was changed.

This closes the concrete remaining cases tracked here. #933 remains open for broader fast assertion observations; no universal claim about every possible CI failure is made. Original report/comments remain below.

#915 fixed the largest category of intermittent CI failures — tests that slept through the real rate-limit backoff and tipped over bun's 5s per-test timeout. That accounted for every failure with a `500Xms` duration.

A second, distinct category remains. These fail **fast**, so they are not timeouts:

| test | duration |
|---|---|
| `MCP server per-request lifecycle > should not share MCP server between concurrent requests` | 919ms |
| `Plugin integration — end-to-end via HTTP > loads an absolute-path plugin and applies its onRequest hook` | 2197ms |
| `Integration: Concurrent subagent requests > should handle 3 concurrent requests (parent + 2 subagents)` | 119ms |
| `Fingerprint resume: cross-project safety via lineage > resumes correctly after cross-project rejection` | 89ms |
| `Integration: Non-stream usage propagation > falls back to zeros when no SDK assistant message is produced` | 43ms |
| `queue telemetry under cancellation` | 226ms |
| `Stale UUID retry` | 582ms |

## What is known

- **Never the same test twice.** Across ~6 failing runs, no test failed in two of them.
- **All pass locally**, individually and in the full suite, repeatedly. `npm test` on `main` is 3211 pass / 0 fail.
- **Several are explicitly concurrency tests** — "should not share MCP server between *concurrent* requests", "handle 3 *concurrent* requests". That is the strongest signal in the data.
- One observed failure was concrete rather than a timeout: `falls back to zeros` returned **500** instead of 200.
- The main pass runs ~2900 tests across ~175 files in a single bun process, and 75 test files call `mock.module("@anthropic-ai/claude-agent-sdk")`, which is process-global in bun.

## Two candidate explanations, not yet distinguished

1. **CPU contention on the runner.** Timing-sensitive concurrency assertions lose races when the runner is loaded. Would explain why it is never the same test and why it never reproduces on a developer machine.
2. **Cross-file mock leakage.** 75 files racing on one process-global module mock; file ordering can differ between macOS and Linux, which would explain the platform split.

These are not mutually exclusive, and I have not designed an experiment that separates them. Filing before investigating so the evidence is not lost.

## Why it matters

The `publish` job re-runs `npm test` before `npm publish`, so any flake there blocks a release. That is exactly what happened to 1.66.0 — tagged and Docker-published while npm sat on 1.65.2 through two failed publish attempts. #915 removed the cause in that instance, but this category can reproduce the same outcome.

## Suggested next step

Reproduce under artificial CPU load before attempting a fix — e.g. run the main pass on a constrained runner, or with a background load generator, and see whether the failure rate rises. That would distinguish explanation 1 from 2 cheaply and without guessing.
