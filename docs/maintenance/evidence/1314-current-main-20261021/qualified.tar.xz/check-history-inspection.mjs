import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { parseAgRequest, renderAgPrompt } from '/private/tmp/meridian-pr1314-current-20261021/src/proxy/backends/antigravityProtocol.ts'
import { inspectRenderedHistory } from './owned-history-live.mjs'
const rows = []
const render = (path, id = 'fixture-current-large', name = 'write') => {
  const request = parseAgRequest({ model: 'gemini-3.8-flash-low', messages: [
    { role: 'user', content: 'Write the controlled fixture, then continue.' },
    { role: 'assistant', content: [{ type: 'tool_use', id, name, input: { content: 'x'.repeat(100000), path } }] },
    { role: 'user', content: [{ type: 'tool_result', tool_use_id: id, content: 'created' }] },
  ] })
  return { prompt: renderAgPrompt(request), messages: request.messages }
}
for (const seedPath of ['/work/already-completed.txt', '/controlled/' + 'common-parent/'.repeat(12) + 'already-completed.txt']) {
  const good = render(seedPath)
  const observed = inspectRenderedHistory(good.prompt, good.messages, seedPath)
  assert(observed.currentTargetInRecap && observed.fullHistoryExact && observed.targetPreviewChars <= 80)
  rows.push({ case: seedPath.length <= 80 ? 'short-target' : 'long-target', ...observed })
  for (const [label, wrong] of [['wrong-target', render(seedPath + '-other')], ['wrong-id', render(seedPath, 'wrong-id')], ['wrong-tool', render(seedPath, 'fixture-current-large', 'delete')]]) {
    const prefix = wrong.prompt.slice(0, wrong.prompt.indexOf('Client conversation:\n'))
    const wireHistory = good.prompt.slice(good.prompt.indexOf('Client conversation:\n'))
    const bad = inspectRenderedHistory(prefix + wireHistory, good.messages, seedPath)
    assert(!bad.currentTargetInRecap && bad.fullHistoryExact)
    rows.push({ case: label, currentTargetInRecap: bad.currentTargetInRecap, fullHistoryExact: bad.fullHistoryExact })
  }
  const prefix = good.prompt.slice(0, good.prompt.indexOf('Client conversation:\n'))
  const bad = inspectRenderedHistory(prefix + 'Client conversation:\n' + JSON.stringify([]), good.messages, seedPath)
  assert(bad.currentTargetInRecap && !bad.fullHistoryExact)
  rows.push({ case: 'changed-history', currentTargetInRecap: bad.currentTargetInRecap, fullHistoryExact: bad.fullHistoryExact })
}
writeFileSync(new URL('./history-inspection-control.json', import.meta.url), JSON.stringify({ bun: Bun.version, actualClientModelCalls: 0, controls: rows }, null, 2) + '\n')
console.log(JSON.stringify({ bun: Bun.version, controls: rows.length, expectedDiscriminationPassed: true, actualClientModelCalls: 0 }))
