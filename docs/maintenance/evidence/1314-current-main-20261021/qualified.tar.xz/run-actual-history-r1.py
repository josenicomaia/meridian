from pathlib import Path
import subprocess,json,os,time,hashlib,datetime
out=Path('/tmp/meridian-resume-20261020/1314-current-renderer');root=Path('/private/tmp/meridian-pr1314-current-20261021');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='5c96dd307cb668e611725e9d33dd90211a68bb68';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);local=json.loads((out/'final-r1-local.json').read_text());assert len(local['commands'])==3 and all(c['exit']==0 for c in local['commands']);preflight=json.loads((out/'read-only-actual-preflight.json').read_text());assert preflight['modelAvailable']and preflight['defaultSubscriptionOnly']and preflight['paidCreditsDisabled']and preflight['customProvidersDisabled'];client=json.loads((out/'pi110-identity.json').read_text());bun=json.loads((out/'toolchain/bun1311/identity.json').read_text());env=dict(os.environ,E2E_MERIDIAN_ROOT=str(root),E2E_PI_BIN=client['CLI'],E2E_NODE_BIN=client['node'],MERIDIAN_AGY_PATH='/tmp/meridian-resume-20261020/agy1340-official/antigravity');cmd=[bun['binary'],str(out/'owned-history-live.mjs')];start=time.time();p=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True);record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'pid':p.pid,'status':'RUNNING','harnessSha256':hashlib.sha256((out/'owned-history-live.mjs').read_bytes()).hexdigest(),'historicalModel':'gemini-3.8-flash-low','client':'Pi1.1.0','node':client['nodeVersion'],'bun':'1.3.11','officialCli':'1.2.7','scope':'One actual source-arm after concrete active-assistant input-limit correction; original reporter ACP version/OS still unknown'};receipt=out/'actual-history-r1.json';receipt.write_text(json.dumps(record,indent=2)+'\n');print('Started owned actual history gate PID',p.pid,flush=True)
with(out/'actual-history-r1.log').open('w')as log:
 for line in p.stdout:
  log.write(line);log.flush()
  if line.startswith('Artifacts: '):
   record['artifacts']=line[len('Artifacts: '):].strip();receipt.write_text(json.dumps(record,indent=2)+'\n');print(line.strip(),flush=True)
code=p.wait();record.update({'exit':code,'seconds':time.time()-start,'status':'TERMINAL'});text=(out/'actual-history-r1.log').read_text();marker='\n{\n  "packageRoot":';at=text.rfind(marker);final=None
if at>=0:
 try:final=json.JSONDecoder().raw_decode(text[at+1:])[0]
 except json.JSONDecodeError:pass
if final is not None:
 (out/'actual-history-r1-postdrain-report.json').write_text(json.dumps(final,indent=2)+'\n');record['postDrainRunTermination']=final.get('runTermination');record['artifactDrain']=final.get('artifactDrain');record['qualified']=code==0 and final.get('runTermination')=='QUALIFIED_CHECKS_COMPLETE'and final.get('artifactDrain',{}).get('outcome')=='RESOLVED'
else:record['qualified']=False
record['combinedLogSha256']=hashlib.sha256((out/'actual-history-r1.log').read_bytes()).hexdigest();receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
