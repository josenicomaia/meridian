import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
process.env.AGY_CLI_DISABLE_AUTO_UPDATE='true'
import { writeFileSync } from 'node:fs'
import { readAgProbe } from '/private/tmp/meridian-pr1314-current-20261021/src/proxy/backends/antigravityProbe.ts'
const executable = '/tmp/meridian-resume-20261020/agy1340-official/antigravity'
const identity=()=>createHash('sha256').update(readFileSync(executable)).digest('hex'); const initial=identity(); assert.equal(initial,'8c01ef82307dc01455418eb2e6e82f2989a3fa8b815c4b192efaaa89a55bef8d');
const record = {initialBinarySHA256:initial, updateDisabled:true,  bun: Bun.version, model: 'gemini-3.8-flash-low', nativeCliVersion: undefined, defaultSubscriptionOnly: false, paidCreditsDisabled: false, customProvidersDisabled: false, modelAvailable: false, modelCalls: 0, operations: ['version', 'configuration', 'models'] }
const save = () => writeFileSync(new URL('./pinned-model-preflight-r2.json', import.meta.url), JSON.stringify(record, null, 2) + '\n')
try {
  record.nativeCliVersion = (await readAgProbe(executable, 'version', { signal: AbortSignal.timeout(45000) })).trim()
  if (record.nativeCliVersion !== '1.2.7') throw new Error('unsupported-version')
  assert.equal(identity(),initial);
  const raw = await readAgProbe(executable, 'configuration', { signal: AbortSignal.timeout(45000) })
  let object
  try { object = JSON.parse(raw) } catch { throw new Error('configuration-not-parseable') }
  const config = object?.command?.data?.config
  record.paidCreditsDisabled = config?.useG1Credits === false
  record.defaultSubscriptionOnly = !!config && !config.modelProvider && !config.gcp
  record.customProvidersDisabled = !!config && (!config.customModelsConfig || typeof config.customModelsConfig === 'object' && Object.keys(config.customModelsConfig).length === 0)
  if (!record.paidCreditsDisabled || !record.defaultSubscriptionOnly || !record.customProvidersDisabled) throw new Error('subscription-safety-preflight-refused')
  assert.equal(identity(),initial);
  const models = await readAgProbe(executable, 'models', { signal: AbortSignal.timeout(45000) })
  record.modelAvailable = models.split('\n').some(line => line.includes('\t') && line.split('\t')[0] === record.model)
  if (!record.modelAvailable) throw new Error('required-model-unavailable')
  assert.equal(identity(),initial);record.finalBinarySHA256=identity();record.unchanged=true;
  save(); console.log(JSON.stringify(record))
} catch (error) {
  record.failure = ['unsupported-version', 'configuration-not-parseable', 'subscription-safety-preflight-refused', 'required-model-unavailable'].includes(error.message) ? error.message : String(error.reason || error.name || 'probe-error')
  save(); console.log(JSON.stringify(record)); process.exitCode = 1
}
