import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { historyFixture } from './frozen-history-escrow.mjs'
const fixture = historyFixture('/controlled/fixture/project', 'gemini-3.8-flash-low', 'LATEST_CONTROLLED_RECEIPT')
// Reconstruct the public v3 fixture's Anthropic representation. This is not
// a recovered historical client/CLI trace; no client, native CLI or model runs.
const messages = fixture.entries.filter(entry => entry.type === 'message').map(({ message }) => {
  if (message.role === 'toolResult') return { role: 'user', content: [{ type: 'tool_result', tool_use_id: message.toolCallId, content: message.content, is_error: message.isError }] }
  if (message.role === 'assistant') return { role: 'assistant', content: message.content.map(block => block.type === 'toolCall' ? { type: 'tool_use', id: block.id, name: block.name, input: block.arguments } : block) }
  return { role: 'user', content: message.content }
})
messages.push({ role: 'assistant', content: [{ type: 'tool_use', id: 'live-completed-target', name: 'write', input: { content: fixture.expected, path: fixture.outputPath } }] })
messages.push({ role: 'user', content: [{ type: 'tool_result', tool_use_id: 'live-completed-target', content: [{ type: 'text', text: 'Successfully wrote the controlled target.' }], is_error: false }] })
const request = { model: 'gemini-3.8-flash-low', messages, tools: [{ name: 'write', input_schema: { type: 'object' } }, { name: 'read', input_schema: { type: 'object' } }] }
const rows = []
for (const [label, path] of [
  ['submitted', './variants/submitted/src/proxy/backends/antigravityProtocol.ts'],
  ['old-corrected', './variants/old-corrected/src/proxy/backends/antigravityProtocol.ts'],
  ['main', './variants/main/src/proxy/backends/antigravityProtocol.ts'],
  ['candidate', `${process.env.E2E_MERIDIAN_ROOT || '/private/tmp/meridian-pr1314-current-20261021'}/src/proxy/backends/antigravityProtocol.ts`],
]) {
  const module = await import(path.startsWith('/') ? pathToFileURL(path).href : path)
  const parsed = module.parseAgRequest(request)
  const raw = module.renderAgPrompt(parsed)
  let effective
  try { effective = module.renderAgPromptWithinLimit ? module.renderAgPromptWithinLimit(parsed) : raw }
  catch (error) {
    rows.push({ label, outcome: 'REJECTED', rawBytes: Buffer.byteLength(raw), inputLimitAvailable: !!module.renderAgPromptWithinLimit, error: { message: error.message, status: error.status } })
    continue
  }
  const history = JSON.parse(effective.slice(effective.lastIndexOf('Client conversation:\n') + 'Client conversation:\n'.length))
  const finalResult = history.flatMap(message => Array.isArray(message.content) ? message.content : []).find(block => block.type === 'tool_result' && block.tool_use_id === 'live-completed-target')
  assert.deepEqual(finalResult, parsed.messages.at(-1).content[0])
  const marker = '"tool_use_id":"live-completed-target"'
  rows.push({ label, outcome: 'RENDERED', rawBytes: Buffer.byteLength(raw), effectiveBytes: Buffer.byteLength(effective), inputLimitAvailable: !!module.renderAgPromptWithinLimit, resultMarkerOffsetBytes: Buffer.byteLength(raw.slice(0, raw.lastIndexOf(marker))), first192000BytesContainResultMarkerAnywhere: Buffer.from(effective).subarray(0, 192000).toString().includes(marker), first192000BytesContainAuthoritativeResult: Buffer.byteLength(effective.slice(0, effective.lastIndexOf(marker) + marker.length)) <= 192000, latestResultPreservedInFullRenderedHistory: true, inputOmissionDisclosed: effective.includes('omitted the middle') })
}
assert(rows.filter(row => ['submitted', 'old-corrected'].includes(row.label)).every(row => row.effectiveBytes > 192000 && !row.first192000BytesContainAuthoritativeResult))
assert.equal(rows.find(row => row.label === 'main').outcome, 'REJECTED')
assert(rows.filter(row => row.label === 'candidate').every(row => row.effectiveBytes <= 190000 && row.first192000BytesContainAuthoritativeResult))
const record = { rejectedHypotheses: ['Current main already fits the historical public fixture: false, it refuses older assistant text.', 'Any result marker in the first192000bytes proves the authoritative result survives: false, the old corrected recap itself contains that marker.'], scope: 'Reconstructed deterministic public fixture only; historical exact CLI stdin/provider receipt is not recovered. The first hypothesis that main could already fit this fixture was rejected: main refuses its older assistant text. The candidate includes a new text-compaction correction. This is a concrete new qualification target, not proof of the old model failure cause or present acceptance.', fixtureAssistantChars: fixture.longText.length, fixtureLargeWriteChars: fixture.large.length, noClientCliOrModelInvocation: true, rows }
writeFileSync(new URL('./public-fixture-budget-comparison.json', import.meta.url), JSON.stringify(record, null, 2) + '\n')
console.log(JSON.stringify(record, null, 2))
