import pathlib,subprocess,os,json,hashlib
root=pathlib.Path('/private/tmp/meridian-clear-completion-20261020');out=pathlib.Path('/tmp/meridian-resume-20261020/1220-current-composition');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');records=[]
p=root/'src/proxy/session/cache.ts';original=p.read_bytes();text=original.decode();line='  const fingerprint = !sessionId ? getConversationFingerprint(messages, workingDirectory) : null\n';assert text.count(line)==1
mutant=text.replace(line,'').replace('  }), restored => {\n    if (!restored)', '  }), restored => {\n'+line+'    if (!restored)');assert mutant!=text
cases=[('late-headerless-key',p,original,mutant,['--test-name-pattern','captures the headerless rollback','src/__tests__/execution-history-store.test.ts'])]
p=root/'src/proxy/session/storeMutationResult.ts';original=p.read_bytes();text=original.decode();mutant=text.replace('value instanceof Promise ? value.then(continuation) : continuation(value)','Promise.resolve(value).then(continuation)');assert mutant!=text
cases.append(('yielding-native-continuation',p,original,mutant,['--test-name-pattern','priority finalize: authority changes only on COMMIT','src/__tests__/bookkeeping-cache-publication.test.ts']))
for name,p,original,mutant,args in cases:
 try:
  p.write_text(mutant)
  with(out/(name+'-negative.log')).open('w')as log:r=subprocess.run([bun,'test','--timeout','30000',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert r.returncode!=0,name+' did not fail'
 finally:p.write_bytes(original)
 assert p.read_bytes()==original
 records.append({'name':name,'exit':r.returncode,'sourceRestored':True,'restoredSha256':hashlib.sha256(original).hexdigest()})
(out/'negative-controls.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
