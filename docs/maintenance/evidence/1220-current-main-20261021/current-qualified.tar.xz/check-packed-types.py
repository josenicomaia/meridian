import pathlib,subprocess,tarfile,json,hashlib,shutil
root=pathlib.Path('/private/tmp/meridian-clear-completion-20261020');out=pathlib.Path('/tmp/meridian-resume-20261020/1220-current-composition');qualified=json.loads((out/'final-r4-local.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert qualified['head']==head and {r['name']:r['exit'] for r in qualified['commands']}=={'typecheck':0,'build':0,'full':0}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
packed=out/'package-r4';packed.mkdir(exist_ok=True)
with(packed/'pack.json').open('w')as f:subprocess.run(['npm','pack','--json','--pack-destination',str(packed)],cwd=root,stdout=f,check=True)
meta=json.loads((packed/'pack.json').read_text())[0];candidate=packed/meta['filename'];records=[];tsc=root/'node_modules/typescript/bin/tsc'
for label,archive in [('published-1.84',pathlib.Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz')),('candidate',candidate)]:
 fixture=packed/(label+'-declarations');fixture.mkdir(exist_ok=True)
 try:
  names=[]
  with tarfile.open(archive)as tar:
   for member in tar.getmembers():
    if not member.isfile() or not(member.name.endswith('.d.ts') or member.name=='package/package.json'):continue
    target=fixture/member.name
    if not target.resolve().is_relative_to(fixture.resolve()):raise RuntimeError('archive escape')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read());names.append(member.name)
  target=fixture/'package/dist/proxy/server.js';probe=fixture/'check.mts';probe.write_text('import { clearSessionCache } from '+json.dumps(str(target))+';\ntype IsAny<T> = 0 extends (1 & T) ? true : false;\nconst notAny: IsAny<ReturnType<typeof clearSessionCache>> = false;\nconst completion: Promise<void> = clearSessionCache();\nconst exact: [ReturnType<typeof clearSessionCache>] extends [Promise<void>] ? true : false = true;\nvoid [notAny, completion, exact];\n')
  with(packed/(label+'-type-probe.log')).open('w')as log:result=subprocess.run(['node',str(tsc),'--noEmit','--skipLibCheck','--target','ES2022','--module','ESNext','--moduleResolution','Bundler','--types','node',str(probe)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  # The declarations are external to root, while Node ambient types are resolved from this explicit source project.
  if label=='candidate':assert result.returncode==0,(packed/(label+'-type-probe.log')).read_text()
  else:
   text=(packed/(label+'-type-probe.log')).read_text();assert result.returncode!=0 and "Type 'void' is not assignable to type 'Promise<void>'" in text,text
  records.append({'label':label,'exit':result.returncode,'declarationFiles':len(names),'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
 finally:shutil.rmtree(fixture)
(packed/'type-probe-results.json').write_text(json.dumps({'head':head,'cases':records,'newDependencyInstalls':0,'models':0,'declarationFixturesRemoved':True,'limitation':'Archive/declaration verification only; not a fresh installed client/model E2E.'},indent=2)+'\n');print(json.dumps(records))
