const ts = require('/private/tmp/meridian-clear-completion-20261020/node_modules/typescript');
const root='/private/tmp/meridian-clear-completion-20261020';
const path=require('node:path'),fs=require('node:fs');
const config=ts.readConfigFile(root+'/tsconfig.json',ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,root);const program=ts.createProgram(parsed.fileNames,parsed.options),checker=program.getTypeChecker();
const names=new Set(['storeSharedSession','claimPriorityAttempt','releasePriorityAttempt','blockPriorityAttempt','storeSharedSessionAndPriorityAssignment','finalizeSharedSessionAndPriorityAssignment','rollbackSharedSessionAndPriorityAssignment','attachSharedTranscriptLocator','evictSharedSession','pruneSupersededProfileCopies','clearSharedSessions','evictSession','finalizePrioritySessionPublication','rollbackPrioritySessionPublication','storeSession']);
const records=[];
for(const file of program.getSourceFiles())if(file.fileName.startsWith(root+'/src/')&&!file.isDeclarationFile){
 const walk=n=>{if(ts.isCallExpression(n)){
  let symbol=checker.getSymbolAtLocation(n.expression);if(symbol&&(symbol.flags&ts.SymbolFlags.Alias))symbol=checker.getAliasedSymbol(symbol);
  if(symbol&&names.has(symbol.name)&&symbol.declarations?.some(d=>/\/proxy\/(sessionStore\.ts|session\/cache\.ts)$/.test(d.getSourceFile().fileName))){
   let parent=n.parent;while(ts.isParenthesizedExpression(parent)||ts.isAsExpression(parent)||ts.isNonNullExpression(parent))parent=parent.parent;
   const pos=file.getLineAndCharacterOfPosition(n.getStart());records.push({file:path.relative(root,file.fileName),line:pos.line+1,name:symbol.name,parent:ts.SyntaxKind[parent.kind],text:parent.getText(file).slice(0,200)});
  }
 }ts.forEachChild(n,walk)};walk(file);
}
fs.writeFileSync('/tmp/meridian-resume-20261020/1220-current-composition/mutation-call-audit.json',JSON.stringify(records,null,2)+'\n');
const immediate=new Set(['AwaitExpression','ReturnStatement','ArrowFunction']);const unresolved=records.filter(x=>!immediate.has(x.parent));console.log(JSON.stringify({total:records.length,production:records.filter(x=>!x.file.includes('__tests__')).length,needsManual:unresolved.filter(x=>!x.file.includes('__tests__')),testContexts:unresolved.filter(x=>x.file.includes('__tests__')).reduce((o,x)=>(o[x.parent]=(o[x.parent]||0)+1,o),{})},null,2));
