export function expectedCheckpointStop(error, row, model) {
  return row.kind === 'denied-mcp-tool'
    && error instanceof Error
    && error.message === 'Claude Code returned an error result: Reached maximum number of turns (1)'
    && row.terminal?.subtype === 'error_max_turns' && row.terminal.isError === true
    && row.requests.length === 1 && row.requests[0].model === model && row.requests[0].status === 200
    && row.starts.length > 0 && row.starts.every(start => start.model === model)
    && row.hooks === 1 && row.toolExecutions === 0
}
