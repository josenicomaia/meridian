import assert from 'node:assert/strict'
import * as cp from 'node:child_process'
import { createServer } from 'node:http'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import { mkdir, readFile, writeFile, stat } from 'node:fs/promises'
import { join } from 'node:path'
import { spyOn } from 'bun:test'

const source = '/private/tmp/meridian-1400-current-main-20261021'
const out = '/tmp/meridian-active-history-budget-20261021/native-model-label-control/r2'
const MODEL = 'claude-fable-5-1', requested = 'fable[1m]'
await mkdir(out, { mode: 0o700 })
const sha = data => createHash('sha256').update(data).digest('hex')
const inheritedPath = process.env.PATH
const native = '/tmp/meridian-active-history-budget-20261021/native-model-label-control/pinned-cli302/claude'
assert((await stat(native)).isFile())
const nativeSha = sha(await readFile(native))
const { observeChildClosure, stopAndJoinChild } = await import(pathToFileURL(join(source, 'scripts/lib/e2eProcessCustody.mjs')).href)
const require = createRequire(join(source, 'package.json'))
const sdkVersion = JSON.parse(await readFile(require.resolve('@anthropic-ai/claude-agent-sdk/package.json'))).version
assert.equal(sdkVersion, '0.2.141')
const report = { scope: 'Native SDK model-metadata isolation with scripted loopback upstream and synthetic API key; no account credential read, refresh/write, real model call, or reported-client acceptance.', sdkVersion, sdkNativePackage: '0.2.141', nativeSha, requestedAlias: requested, scriptedResponseModel: MODEL, platform: process.platform + '/' + process.arch, bun: Bun.version, arms: [] }
const cleanEnv = root => ({ PATH: inheritedPath, HOME: join(root, 'home'), CLAUDE_CONFIG_DIR: join(root, 'config'), TMPDIR: join(root, 'tmp'), TERM: 'dumb', LANG: 'en_US.UTF-8', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', DISABLE_TELEMETRY: '1', DISABLE_ERROR_REPORTING: '1', DISABLE_AUTOUPDATER: '1', ANTHROPIC_API_KEY: 'owned-fixture-key', ANTHROPIC_DEFAULT_FABLE_MODEL: MODEL, ENABLE_TOOL_SEARCH: 'false', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '128' })
for (const kind of ['text', 'denied-mcp-tool']) {
  const root = join(out, kind)
  for (const name of ['', 'home', 'config', 'tmp', 'project']) await mkdir(join(root, name), { recursive: true, mode: 0o700 })
  const env = cleanEnv(root)
  process.env = { ...env }
  const version = cp.spawnSync(native, ['--version'], { env, encoding: 'utf8', timeout: 10000, maxBuffer: 65536 })
  assert.equal(version.status, 0)
  report.nativeVersion ??= (version.stdout || version.stderr).trim()
  await writeFile(join(out, 'preflight.json'), JSON.stringify({ nativeSha, nativeVersion: report.nativeVersion, sdkVersion, queryStarted: false, historicalBinaryHashMatched: false }, null, 2) + '\n', { mode: 0o600 })
  assert(/\b2\.1\.302\b/.test(report.nativeVersion), 'This control requires version-matched SDK native 2.1.302')
  const sdk = await import(pathToFileURL(require.resolve('@anthropic-ai/claude-agent-sdk')).href)
  const { z } = await import(pathToFileURL(require.resolve('zod')).href)
  const row = { kind, requests: [], starts: [], assistants: [], terminal: null, hooks: 0, toolExecutions: 0, actors: [], stderr: '', iteratorSettled: false }
  report.arms.push(row)
  let unexpected, q, timer
  const server = createServer(async (req, res) => {
    try {
      let length = 0; const chunks = []
      for await (const chunk of req) { length += chunk.length; assert(length <= 512 * 1024); chunks.push(chunk) }
      const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')
      if (req.url.includes('/count_tokens')) { res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"input_tokens":10}'); return }
      assert(req.url.split('?')[0] === '/v1/messages', 'Unexpected fixture route')
      assert(row.requests.length < 2, 'No retry loop allowed')
      row.requests.push({ model: body.model, stream: body.stream, bodySHA256: sha(JSON.stringify(body)), tools: (body.tools ?? []).map(tool => tool.name) })
      assert.equal(body.model, MODEL, 'Unexpected native model request')
      assert.equal(row.requests.length, 1, 'Only one API generation per arm')
      const name = (body.tools ?? []).find(tool => tool.name === 'mcp__oc__Read')?.name
      if (kind === 'denied-mcp-tool') assert(name, 'Owned MCP Read was not offered')
      const block = kind === 'text' ? { type: 'text', text: '' } : { type: 'tool_use', id: 'toolu_owned_model_label', name, input: {} }
      const delta = kind === 'text' ? { type: 'text_delta', text: 'OWNED_FIXTURE_OK' } : { type: 'input_json_delta', partial_json: JSON.stringify({ file_path: join(root, 'project/owned.txt') }) }
      const events = [
        { type: 'message_start', message: { id: 'msg_owned_' + kind, type: 'message', role: 'assistant', model: MODEL, content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 10, output_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 } } },
        { type: 'content_block_start', index: 0, content_block: block },
        { type: 'content_block_delta', index: 0, delta }, { type: 'content_block_stop', index: 0 },
        { type: 'message_delta', delta: { stop_reason: kind === 'text' ? 'end_turn' : 'tool_use', stop_sequence: null }, usage: { output_tokens: 4 } },
        { type: 'message_stop' },
      ]
      res.writeHead(200, { 'content-type': 'text/event-stream' })
      res.end(events.map(event => 'event: ' + event.type + '\ndata: ' + JSON.stringify(event) + '\n\n').join(''))
    } catch (error) { unexpected ??= String(error); res.writeHead(400, { 'content-type': 'application/json' }); res.end(JSON.stringify({ type: 'error', error: { type: 'invalid_request_error', message: 'Owned fixture stopped: ' + error.message } })) }
  })
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
  const address = server.address(); assert(address && typeof address !== 'string')
  const childEnv = { ...env, ANTHROPIC_BASE_URL: 'http://127.0.0.1:' + address.port }
  process.env = { ...childEnv }
  const actors = [], spawn = cp.spawn
  const observer = spyOn(cp, 'spawn').mockImplementation((...args) => {
    const child = Reflect.apply(spawn, cp, args)
    const witness = observeChildClosure(child)
    actors.push({ child, witness }); row.actors.push(witness.state)
    return child
  })
  const abort = new AbortController()
  try {
    timer = setTimeout(() => abort.abort(new Error('Owned native control deadline')), 25000)
    const mcp = sdk.createSdkMcpServer({ name: 'oc', version: '1.0.0', tools: [sdk.tool('Read', 'Owned synthetic read', { file_path: z.string() }, async () => { row.toolExecutions++; return { content: [{ type: 'text', text: 'owned receipt' }] } })] })
    q = sdk.query({ prompt: 'Follow the owned synthetic provider response.', options: {
      cwd: join(root, 'project'), env: childEnv, model: requested, pathToClaudeCodeExecutable: native,
      settingSources: [], tools: [], allowedTools: ['mcp__oc__Read'], mcpServers: { oc: mcp },
      permissionMode: 'bypassPermissions', allowDangerouslySkipPermissions: true, includePartialMessages: true,
      maxTurns: 1, systemPrompt: 'Owned SDK metadata control.', abortController: abort,
      stderr: text => { if (row.stderr.length < 32768) row.stderr += text.replaceAll('owned-fixture-key', '[FIXTURE_KEY]') },
      hooks: { PreToolUse: [{ matcher: 'mcp__oc__Read', hooks: [async () => { row.hooks++; return { hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: 'Owned forwarded-tool checkpoint control' } } }] }] },
    } })
    try {
      for await (const event of q) {
        if (event.type === 'stream_event' && event.event.type === 'message_start') row.starts.push({ model: event.event.message.model })
        if (event.type === 'assistant') row.assistants.push({ model: event.message?.model, error: event.error ?? null, contentTypes: event.message?.content?.map(block => block.type) ?? [] })
        if (event.type === 'result') row.terminal = { subtype: event.subtype, isError: event.is_error, modelUsage: event.modelUsage, usage: event.usage }
      }
    } finally { row.iteratorSettled = true }
    assert.equal(unexpected, undefined)
    assert.equal(row.requests.length, 1)
    assert(row.starts.length > 0 && row.starts.every(value => value.model === MODEL))
    if (kind === 'text') { assert.equal(row.terminal?.subtype, 'success'); assert(row.assistants.every(value => value.model === MODEL)) }
    else { assert.equal(row.hooks, 1); assert.equal(row.toolExecutions, 0); assert.equal(row.terminal?.subtype, 'error_max_turns') }
    row.canonicalModelsMatchScriptedResponse = row.assistants.length > 0 && row.assistants.every(value => value.model === MODEL)
    row.result = 'CONTROL_COMPLETE'
  } catch (error) { row.error = String(error); row.result = 'FAILED'; throw error }
  finally {
    clearTimeout(timer)
    try { q?.close() } catch (error) { row.closeError = String(error) }
    for (const actor of actors) if (!actor.witness.state.joined) await stopAndJoinChild(actor.child, actor.witness, { graceMs: 5000, forceMs: 1000 })
    observer.mockRestore(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve))
    row.nativeHandlesJoined = actors.length > 0 && actors.every(actor => actor.witness.state.joined)
    report.finalNativeSha = sha(await readFile(native))
    await writeFile(join(out, 'report.json'), JSON.stringify(report, null, 2) + '\n', { mode: 0o600 })
    assert(row.nativeHandlesJoined, 'Original native process/pipe joins unqualified')
    assert.equal(report.finalNativeSha, nativeSha)
  }
}
console.log(JSON.stringify({ result: 'CONTROL_COMPLETE', sdk: report.sdkVersion, native: report.nativeVersion, arms: report.arms.map(row => ({ kind: row.kind, requests: row.requests.length, starts: row.starts, assistants: row.assistants, terminal: row.terminal?.subtype, hooks: row.hooks, nativeHandlesJoined: row.nativeHandlesJoined })) }))
