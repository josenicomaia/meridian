import assert from 'node:assert/strict'
import { expectedCheckpointStop } from './expected-stop.mjs'
const model = 'claude-fable-5-1', error = new Error('Claude Code returned an error result: Reached maximum number of turns (1)')
const row = { kind: 'denied-mcp-tool', terminal: { subtype: 'error_max_turns', isError: true }, requests: [{ model, status: 200 }], starts: [{ model }], hooks: 1, toolExecutions: 0 }
assert(expectedCheckpointStop(error, row, model))
for (const change of [r => { r.kind = 'text' }, r => { r.terminal.subtype = 'billing_error' }, r => { r.terminal.isError = false }, r => { r.requests[0].status = 400 }, r => { r.requests[0].model = 'claude-opus-4-8' }, r => { r.requests.push({ model, status: 200 }) }, r => { r.starts = [] }, r => { r.starts[0].model = 'claude-opus-4-8' }, r => { r.hooks = 0 }, r => { r.toolExecutions = 1 }]) {
 const wrong = structuredClone(row); change(wrong); assert(!expectedCheckpointStop(error, wrong, model))
}
assert(!expectedCheckpointStop(new Error('API Error: quota exhausted'), row, model))
console.log(JSON.stringify({ exactExpectedBoundaryPasses: true, adverseControlsRejected: 11 }))
