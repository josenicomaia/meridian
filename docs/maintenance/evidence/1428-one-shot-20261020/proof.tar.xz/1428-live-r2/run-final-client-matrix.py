import os,json,subprocess,hashlib,datetime,socket,shutil,re
from pathlib import Path
r=Path('/tmp/meridian-resume-20261020');out=r/'1428-live-r2';qualified=out/'qualified-readiness';stage=out/'packages';source='/private/tmp/meridian-pr1428-20261020';base='/private/tmp/meridian-main-1401-post1406-20261020';package=str(stage/'candidate-mac/node_modules/@rynfar/meridian');head='e5100bd4cf40804cb8799f5a85a63890fe668984';bun='/tmp/meridian-1399-tooling/node_modules/.bin/bun';native='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302';grant=r/'private/1428-team-readiness-grant.json';guard=r/'private/1428-team-readiness-admission.json';attempt=out/'READINESS_MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json';hold_hash=hashlib.sha256(hold.read_bytes()).hexdigest();record={'task':'1428-final-client-matrix-haiku55','head':head,'base':'6f50d2f315f62369c99a9cd307e2beaa93440a6c','cases':[],'result':'RUNNING','retainedOriginalKnownQuotaFailure':'1428-title-live-summary.json; old personalaccount ordinal2 remains exhausted, this new same-Team baseline/candidate comparison is account-agnostic application verification','admissions':[]}
assert not attempt.exists() and not grant.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
local=json.loads((r/'1428-final-e510-local-exit.json').read_text());assert all(any(row['label']==label and row['exit']==0 for row in local['commands']) for label in ['focused','typecheck','build'])
packages=json.loads((stage/'summary.json').read_text());assert packages['result']=='PASS_PACKAGES_READY' and packages['heads']['candidate']==head
preflight=json.loads((out/'offline-summary.json').read_text());assert preflight['result']=='PASS' and len(preflight['cases'])==8
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'actual-client.mjs',out/'beta-client-warm.mjs',out/'create-team-readiness-grant.mjs',*qualified.glob('*.mjs')]}
common={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','TERM','TMPDIR')};common.update(E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard),E2E_PLUGIN_PATH=str(r/'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_NATIVE_BIN=native,E2E_EXPECT_MODEL='claude-haiku-5-5',E2E_MODEL='claude-haiku-5-5',E2E_HARNESS_ROOT=source)
def save():(out/'final-client-matrix.json').write_text(json.dumps(record,indent=2)+'\n')
def preserved():
 assert hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash,'Older failed-case holds changed'
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items()),'Executed harness changed'
def fresh_admission(case):
 subprocess.run([bun,str(out/'create-team-readiness-grant.mjs')],cwd=source,env=dict(os.environ,E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1'),check=True)
 admission=json.loads(guard.read_text());assert admission['includedCapacityKnown'] is False and admission['profileExtraUsageEnabled'] is False and admission['maximumCases']==8
 record['admissions'].append({'case':case,**admission});save();return admission
def run_case(name,command,env,check):
 assert len(record['cases'])<8;fresh_admission(name);target=out/name;target.mkdir()
 for directory in ['home','native-config','proxy']:(target/directory).mkdir()
 row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['cases'].append(row);save()
 with (target/'run.log').open('w') as log:p=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,**check(target));save();print(json.dumps(row),flush=True);preserved();assert p.returncode==0 and row['qualified'],'Retain actual failure; stop dependent work'
try:
 fresh_admission('initial')
 attempt.write_text(json.dumps({'task':record['task'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'state':'Remaining8 E42cases only. Original zero-model startup stall retained; bounded HTTP readiness helper has actual controlled first-response timeout then retry pass. No prior qualified cases repeated; no model/account/clientversion/productionchange. Original client stall cause is not claimed resolved.','scripts':seal,'firstAdmission':record['admissions'][0]},indent=2)+'\n')
 cases = [('beta', version, mode) for version in ['18866', '19271'] for mode in [True, False]]
 cases += [('stable', version, mode) for version, mode in [('2.0.31', True), ('2.0.31', False), ('2.0.16', False), ('2.0.21', False)]]
 for kind, version, source_mode in cases:
     name = 'e42-' + kind + '-' + version + ('-source-readiness-r1' if source_mode else '-installed-readiness-r1')
     target = out / name
     root = source if source_mode else package
     binary = r / (f'opencode-beta-{version}/node_modules/@opencode-ai/cli-darwin-arm64/bin/opencode2' if kind == 'beta'
                   else f'opencode-stable-{version}/node_modules/@opencode/cli-darwin-arm64/bin/opencode')
     env = dict(common, HOME=str(target / 'home'), E2E_MERIDIAN_ROOT=root, E2E_OPENCODE_BIN=str(binary),
                E2E_PROXY_REPORT_DIR=str(target / 'proxy'), E2E_OPENCODE_VERSION=version)
     command = [bun, str(qualified / (kind + '-gate.mjs'))]
     if kind == 'beta': command += ['--live', '--extended', '--separate-proxy-cwd'] + (['--source'] if source_mode else [])
     def e42(target, kind=kind):
         workers = [json.loads(path.read_text()) for path in (target / 'proxy').glob('proxy-*.json')]
         models = [json.loads(path.read_text()) for path in (target / 'proxy').glob('models-*.json')]
         return {'workers': [{'result': row.get('result'), 'failure': row.get('failure'), 'joined': row.get('joined'),
                               'correlated': row.get('providerNativeStoredCorrelated')} for row in workers],
                 'generations': sum(row.get('generationCount', 0) for row in models),
                 'qualified': len(workers) == (2 if kind == 'beta' else 1) and all(row.get('result') == 'PASS' and row.get('joined')
                    and row.get('providerNativeStoredCorrelated') for row in workers) and all(not row.get('stopped') and row.get('scripted') is False and row.get('realForwards',0)>=row.get('generationCount',0)>0 and row.get('generationCount',0)<=32 for row in models)}
     run_case(name, command, env, e42)
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['holdsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'holdsUnchanged':record['holdsUnchanged']}),flush=True)
