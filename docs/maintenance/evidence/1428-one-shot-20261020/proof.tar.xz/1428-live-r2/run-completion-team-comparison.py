import os,json,subprocess,hashlib,datetime,socket,shutil,re
from pathlib import Path
r=Path('/tmp/meridian-resume-20261020');out=r/'1428-live-r2';qualified=out/'qualified';stage=out/'packages';source='/private/tmp/meridian-pr1428-20261020';base='/private/tmp/meridian-main-1401-post1406-20261020';package=str(stage/'candidate-mac/node_modules/@rynfar/meridian');head='e5100bd4cf40804cb8799f5a85a63890fe668984';bun='/tmp/meridian-1399-tooling/node_modules/.bin/bun';native='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302';grant=r/'private/1428-team-completion-grant.json';guard=r/'private/1428-team-completion-admission.json';attempt=out/'COMPLETION_MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json';hold_hash=hashlib.sha256(hold.read_bytes()).hexdigest();record={'task':'1428-one-shot-completion-haiku55','head':head,'base':'6f50d2f315f62369c99a9cd307e2beaa93440a6c','cases':[],'result':'RUNNING','retainedOriginalKnownQuotaFailure':'1428-title-live-summary.json; old personalaccount ordinal2 remains exhausted, this new same-Team baseline/candidate comparison is account-agnostic application verification','admissions':[]}
assert not attempt.exists() and not grant.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
local=json.loads((r/'1428-final-e510-local-exit.json').read_text());assert all(any(row['label']==label and row['exit']==0 for row in local['commands']) for label in ['focused','typecheck','build'])
packages=json.loads((stage/'summary.json').read_text());assert packages['result']=='PASS_PACKAGES_READY' and packages['heads']['candidate']==head
preflight=json.loads((out/'offline-summary.json').read_text());assert preflight['result']=='PASS' and len(preflight['cases'])==8
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'actual-client.mjs',out/'beta-client-warm.mjs',out/'create-team-completion-grant.mjs',*qualified.glob('*.mjs')]}
common={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','TERM','TMPDIR')};common.update(E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard),E2E_PLUGIN_PATH=str(r/'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_NATIVE_BIN=native,E2E_EXPECT_MODEL='claude-haiku-5-5',E2E_MODEL='claude-haiku-5-5',E2E_HARNESS_ROOT=source)
def save():(out/'completion-team-comparison.json').write_text(json.dumps(record,indent=2)+'\n')
def preserved():
 assert hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash,'Older failed-case holds changed'
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items()),'Executed harness changed'
def fresh_admission(case):
 subprocess.run([bun,str(out/'create-team-completion-grant.mjs')],cwd=source,env=dict(os.environ,E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1'),check=True)
 admission=json.loads(guard.read_text());assert admission['includedCapacityKnown'] is False and admission['profileExtraUsageEnabled'] is False and admission['maximumCases']==16
 record['admissions'].append({'case':case,**admission});save();return admission
def run_case(name,command,env,check):
 assert len(record['cases'])<16;fresh_admission(name);target=out/name;target.mkdir()
 for directory in ['home','native-config','proxy']:(target/directory).mkdir()
 row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['cases'].append(row);save()
 with (target/'run.log').open('w') as log:p=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,**check(target));save();print(json.dumps(row),flush=True);preserved();assert p.returncode==0 and row['qualified'],'Retain actual failure; stop dependent work'
try:
 fresh_admission('initial')
 attempt.write_text(json.dumps({'task':record['task'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'state':'Continue only unqualified cases after causal zero-model catalog-gap coldFAIL/warmPASS; original6 qualifiedcases and7thzero-generationfailure retained; no account/model/clientversion/productionchange','scripts':seal,'firstAdmission':record['admissions'][0]},indent=2)+'\n')
 for version in ['19271']:
  for kind in ['baseline','candidate']:
   name='live-beta-'+version+'-'+kind+'-completion-r1';target=out/name;env=dict(common,E2E_MERIDIAN_ROOT=base if kind=='baseline' else package,E2E_OPENCODE_BIN=str(r/('opencode-beta-'+version+'/node_modules/@opencode-ai/cli-darwin-arm64/bin/opencode2')),E2E_OPENCODE_VERSION='0.0.0-beta-'+version,E2E_EVIDENCE_DIR=str(target),E2E_EXPECT='candidate',E2E_TITLE_MODE=kind)
   def beta_title(target):
    case=json.loads((target/'report.json').read_text()) if (target/'report.json').exists() else {};return {'result':case.get('result'),'failure':case.get('failure'),'generations':len(case.get('provider',[])),'qualified':case.get('result')=='PASS' and case.get('joined') and case.get('providerNativeStoredCorrelated') and case.get('usageGuard',{}).get('includedCapacityKnown') is False}
   run_case(name,['node',str(out/'beta-client-warm.mjs'),'--live'],env,beta_title)
 for mode in ['chain-json', 'chain-stream', 'parallel-json', 'parallel-stream']:
     name = 'e41-' + mode + '-r1'
     target = out / name
     port_socket = socket.socket(); port_socket.bind(('127.0.0.1', 0)); port = port_socket.getsockname()[1]; port_socket.close()
     env = dict(common, HOME=str(target / 'home'), CLAUDE_CONFIG_DIR=str(target / 'native-config'),
                MERIDIAN_CLAUDE_PATH=native, MERIDIAN_CREDENTIALS_READONLY='1', MERIDIAN_NO_UPDATE_CHECK='1',
                E2E_MERIDIAN_ROOT=source, E2E_MODEL_WITNESS=str(target / 'model-witness.json'),
                E2E_CLIENT_PLUGIN_PATH=source + '/dist/meridian/index.js', E2E_CLIENT_VERSION='1.84.0',
                PROBE_MODEL='claude-haiku-5-5', PROBE_PARALLEL='1' if mode.startswith('parallel') else '0', PROBE_TURNS='6', PROBE_PORT=str(port))
     # The protocol fixture creates these paths after its output root exists.
     command = [bun, str(qualified / 'run-e41.mjs')] + (['--stream'] if mode.endswith('stream') else [])
     def e41(target):
         lines = (target / 'run.log').read_text().splitlines()
         result = next((json.loads(line) for line in reversed(lines) if line.startswith('{"root":')), None)
         if result:
             shutil.copy2(Path(result['root']) / 'qualified-e41-report.json', target / 'report.json')
         witness = json.loads((target / 'model-witness.json').read_text()) if (target / 'model-witness.json').exists() else {}
         return {'result': result, 'generations': witness.get('generationCount'),
                 'qualified': bool(result and result.get('result') == 'PASS' and result.get('joined') and not witness.get('stopped'))}
     run_case(name, command, env, e41)

 cases = [('beta', version, mode) for version in ['18314', '18866', '19271'] for mode in [True, False]]
 cases += [('stable', version, mode) for version, mode in [('2.0.31', True), ('2.0.31', False), ('2.0.16', False), ('2.0.21', False)]]
 for kind, version, source_mode in cases:
     name = 'e42-' + kind + '-' + version + ('-source-r1' if source_mode else '-installed-r1')
     target = out / name
     root = source if source_mode else package
     binary = r / (f'opencode-beta-{version}/node_modules/@opencode-ai/cli-darwin-arm64/bin/opencode2' if kind == 'beta'
                   else f'opencode-stable-{version}/node_modules/@opencode/cli-darwin-arm64/bin/opencode')
     env = dict(common, HOME=str(target / 'home'), E2E_MERIDIAN_ROOT=root, E2E_OPENCODE_BIN=str(binary),
                E2E_PROXY_REPORT_DIR=str(target / 'proxy'), E2E_OPENCODE_VERSION=version)
     command = [bun, str(qualified / (kind + '-gate.mjs'))]
     if kind == 'beta': command += ['--live', '--extended', '--separate-proxy-cwd'] + (['--source'] if source_mode else [])
     def e42(target, kind=kind):
         workers = [json.loads(path.read_text()) for path in (target / 'proxy').glob('proxy-*.json')]
         models = [json.loads(path.read_text()) for path in (target / 'proxy').glob('models-*.json')]
         return {'workers': [{'result': row.get('result'), 'failure': row.get('failure'), 'joined': row.get('joined'),
                               'correlated': row.get('providerNativeStoredCorrelated')} for row in workers],
                 'generations': sum(row.get('generationCount', 0) for row in models),
                 'qualified': len(workers) == (2 if kind == 'beta' else 1) and all(row.get('result') == 'PASS' and row.get('joined')
                    and row.get('providerNativeStoredCorrelated') for row in workers) and all(not row.get('stopped') and row.get('scripted') is False and row.get('realForwards',0)>=row.get('generationCount',0)>0 and row.get('generationCount',0)<=32 for row in models)}
     run_case(name, command, env, e42)
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['holdsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'holdsUnchanged':record['holdsUnchanged']}),flush=True)
