#!/usr/bin/env bun
// Actual pinned OpenCode host against a local API, with isolated client state.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdtempSync, mkdirSync, readFileSync, writeFileSync, realpathSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const client = process.env.E2E_OPENCODE_BIN
assert(client, 'Set E2E_OPENCODE_BIN to the pinned OpenCode binary')
const repo = resolve(process.env.E2E_MERIDIAN_ROOT ?? '.')
const live = process.argv.includes('--live')
const source = process.argv.includes('--source')
const v1 = process.argv.includes('--v1')
const extended = process.argv.includes('--extended')
// The negative control: serve no catalog and require discovery to fail closed.
const discovery = !process.argv.includes('--no-discovery')
assert(!extended || (live && !v1), '--extended requires --live and a V2 host')
const root = realpathSync(mkdtempSync(join(tmpdir(), 'meridian-v2-package-')))
const proxyWorkdir = process.argv.includes('--separate-proxy-cwd') ? join(root, 'proxy-workdir') : root
mkdirSync(proxyWorkdir, { recursive: true })
const config = join(root, 'config', 'opencode')
mkdirSync(config, { recursive: true })
const env = { ...process.env }
for (const key of Object.keys(env)) if (key.startsWith('OPENCODE_') || key.startsWith('MERIDIAN_') || key.startsWith('CLAUDE_PROXY_')) delete env[key]
for (const kind of ['CONFIG', 'DATA', 'CACHE', 'STATE']) env[`XDG_${kind}_HOME`] = join(root, kind.toLowerCase())
// Only the client uses this home; the proxy retains the real Claude credentials.
const clientHome = join(root, 'client-home')
mkdirSync(clientHome, { recursive: true })
Object.assign(env, { HOME: clientHome, PWD: root, INIT_CWD: root, OPENCODE_CONFIG_DIR: config, OPENCODE_DISABLE_AUTOUPDATE: '1', MERIDIAN_CONFIG_DIR: join(root, 'meridian') })
const serverPassword = 'local-e2e-fixture-password'
env.OPENCODE_SERVER_PASSWORD = serverPassword
env.OPENCODE_PASSWORD = serverPassword
const serverAuthorization = `Basic ${Buffer.from(`opencode:${serverPassword}`).toString('base64')}`
const receipt = `BETA_RECEIPT_${crypto.randomUUID()}`
const forkMarker = `FORK_ONLY_${crypto.randomUUID()}`
const summaryMarker = `SUMMARY_PROBE_${crypto.randomUUID()}`
const undoMarker = `UNDO_ONLY_${crypto.randomUUID()}`
const fixturePath = join(root, 'fixture.txt')
writeFileSync(fixturePath, receipt)
let proxy
let proxyUrl
const proxyOutputs = []
async function startMeridian() {
  let ready
  let rejectReady
  const readiness = new Promise((resolve, reject) => { ready = resolve; rejectReady = reject })
  const child = Bun.spawn([process.execPath, '/tmp/meridian-resume-20261020/1428-live-r2/qualified/qualified-proxy-host.mjs'], {
    cwd: root, env: { ...process.env, E2E_PROXY_MODULE: pathToFileURL(join(repo, 'dist/server.js')).href },
    stdout: 'pipe', stderr: 'pipe', ipc(message) { if (message.port) ready(message.port) },
  })
  const output = Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text()])
  child.exited.then(code => rejectReady(new Error(`Proxy exited before readiness: ${code}`)))
  const timer = setTimeout(() => rejectReady(new Error('Proxy did not become ready')), 30_000)
  proxy = { close: async () => {
    child.kill()
    const killTimer = setTimeout(() => child.kill('SIGKILL'), 20_000)
    try { await child.exited; proxyOutputs.push(await output) } finally { clearTimeout(killTimer) }
  } }
  try { proxyUrl = `http://127.0.0.1:${await readiness}` } finally { clearTimeout(timer) }
}
if (live) {
  for (const key of Object.keys(process.env)) if (key.startsWith('MERIDIAN_') || key.startsWith('CLAUDE_PROXY_')) delete process.env[key]
  Object.assign(process.env, { MERIDIAN_CONFIG_DIR: env.MERIDIAN_CONFIG_DIR, MERIDIAN_SESSION_DIR: join(root, 'sessions'),
    MERIDIAN_WORKDIR: proxyWorkdir, MERIDIAN_PASSTHROUGH: '1', MERIDIAN_TELEMETRY_PERSIST: '0' })
  await startMeridian()
}
const requests = []
const discoveryRequests = []
let primaryRequests = 0
let deliveredResultSeen = false
// Mirrors Meridian's own /v1/models shape for the non-live mode, including the
// two values OpenCode's models.dev entry disagrees with: Haiku's full effort set
// and a 200k window.
const fixtureCatalog = { data: [{
  id: 'claude-haiku-4-5', object: 'model', owned_by: 'anthropic',
  display_name: 'Claude Haiku 4.5', context_window: 200_000,
  capabilities: { effort: { low: { supported: true }, medium: { supported: true }, high: { supported: true },
    xhigh: { supported: true }, max: { supported: true }, supported: true } },
}] }
let teardownStarted = false
const endpoint = Bun.serve({ hostname: '127.0.0.1', port: 0, async fetch(request) {
  if (teardownStarted) {
    const row = { method: request.method, path: new URL(request.url).pathname, startedAt: Date.now(), teardownStraggler: true, status: 503, error: 'Teardown in progress' }
    if (request.method === 'POST') requests.push(row)
    else discoveryRequests.push(row)
    return new Response('teardown in progress', { status: 503 })
  }
  // #1004's model discovery issues a body-less `GET /v1/models`. Parsing a body
  // unconditionally threw here, which both failed discovery closed and set this
  // process's exit code, so the gate reported PASS and exited 1 (#1014).
  if (request.method !== 'POST') {
    const url = new URL(request.url)
    const row = { method: request.method, path: url.pathname, startedAt: Date.now() }
    discoveryRequests.push(row)
    if (!discovery) {
      row.status = 404
      return new Response('discovery disabled', { status: 404 })
    }
    if (live) {
      // A one-shot client process can exit while its discovery request is still
      // in flight, which aborts this forward. Record that instead of throwing:
      // an unhandled rejection here is what made the gate exit 1 (#1014).
      try {
        const upstream = await fetch(`${proxyUrl}${url.pathname}${url.search}`,
          { method: request.method, headers: request.headers, signal: request.signal })
        const text = await upstream.text()
        row.status = upstream.status
        row.body = text
        return new Response(text, { status: upstream.status,
          headers: { 'content-type': upstream.headers.get('content-type') ?? 'application/json' } })
      } catch (error) {
        row.status = 0
        row.aborted = request.signal.aborted
        row.error = String(error)
        if (teardownStarted) row.teardownStraggler = true
        return new Response('discovery forward failed', { status: 502 })
      }
    }
    const text = JSON.stringify(fixtureCatalog)
    row.status = 200
    row.body = text
    return new Response(text, { status: 200, headers: { 'content-type': 'application/json' } })
  }
  let body
  try {
    body = await request.json()
  } catch (error) {
    const row = { method: request.method, path: new URL(request.url).pathname, startedAt: Date.now(), status: 0, aborted: request.signal.aborted, error: String(error) }
    if (teardownStarted) row.teardownStraggler = true
    requests.push(row)
    return new Response('invalid request body', { status: 400 })
  }
  const headers = Object.fromEntries([...request.headers].filter(([key]) => (key.startsWith('x-') && key !== 'x-api-key') || key === 'user-agent'))
  const systemText = typeof body.system === 'string' ? body.system : (body.system ?? []).map(block => block.text ?? '').join('\n')
  const clientCwd = systemText.match(/Working directory:\s*([^\n]+)/i)?.[1]?.trim()
  const clientSystemHash = createHash('sha256').update(JSON.stringify(body.system ?? null)).digest('hex')
  const row = { clientSystemHash, clientCwd, requestId: crypto.randomUUID(), path: new URL(request.url).pathname, model: body.model, effort: body.effort || body.output_config?.effort, effortFields: {top:body.effort, output:body.output_config, thinking:body.thinking}, headers, hasForkMarker: JSON.stringify(body.messages).includes(forkMarker),
    hasUndoMarker: JSON.stringify(body.messages).includes(undoMarker), hasSummaryMarker: JSON.stringify(body.messages).includes(summaryMarker), startedAt: Date.now() }
  requests.push(row)
  if (live) {
    // #1028: Traps unhandled rejections if the forward fails or is aborted during
    // client exit or fixture teardown.
    const forwardedHeaders = new Headers(request.headers)
    forwardedHeaders.set('x-request-id', row.requestId)
    try {
      const response = await fetch(`${proxyUrl}${new URL(request.url).pathname}`, { method: 'POST', headers: forwardedHeaders, body: JSON.stringify(body), signal: request.signal })
      return new Response(response.body.pipeThrough(new TransformStream({ flush() { row.completedAt = Date.now() } })), { status: response.status, headers: response.headers })
    } catch (error) {
      row.status = 0
      row.aborted = request.signal.aborted
      row.error = String(error)
      if (teardownStarted) row.teardownStraggler = true
      return new Response('proxy post forward failed', { status: 502 })
    }
  }
  const primary = headers['x-opencode-agent-name'] === 'build'
  if (primary) primaryRequests++
  const read = primary && primaryRequests === 1 ? body.tools?.find(tool => tool.name === 'read') : undefined
  if (primary && primaryRequests > 1 && body.messages.some(message => Array.isArray(message.content) && message.content.some(block =>
    block.type === 'tool_result' && block.tool_use_id === 'toolu_beta_read' && JSON.stringify(block.content).includes(receipt)))) deliveredResultSeen = true
  const text = receipt
  const pathKey = read?.input_schema?.properties?.path ? 'path' : 'filePath'
  if (read) assert(read.input_schema.properties[pathKey], 'Read tool has no supported file path property')
  const toolInput = { [pathKey]: fixturePath }
  const events = [
    { type: 'message_start', message: { id: `msg_${requests.length}`, type: 'message', role: 'assistant', content: [], model: body.model,
      stop_reason: null, stop_sequence: null, usage: { input_tokens: 100, output_tokens: 0 } } },
    { type: 'content_block_start', index: 0, content_block: read ? { type: 'tool_use', id: 'toolu_beta_read', name: read.name, input: {} } : { type: 'text', text: '' } },
    { type: 'content_block_delta', index: 0, delta: read ? { type: 'input_json_delta', partial_json: JSON.stringify(toolInput) } : { type: 'text_delta', text } },
    { type: 'content_block_stop', index: 0 },
    { type: 'message_delta', delta: { stop_reason: read ? 'tool_use' : 'end_turn', stop_sequence: null }, usage: { output_tokens: 10 } },
    { type: 'message_stop' },
  ]
  return new Response(events.map(event => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join(''), { headers: { 'content-type': 'text/event-stream' } })
} })
async function run(args, { allowFailure = false } = {}) {
  const child = Bun.spawn(args, { cwd: root, env, stdout: 'pipe', stderr: 'pipe' })
  const timer = setTimeout(() => child.kill(), 180_000)
  try {
    const [stdout, stderr, exitCode] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited])
    console.log(JSON.stringify({ root, args, exitCode, stdout, stderr }))
    if (!allowFailure) assert.equal(exitCode, 0)
    return stdout
  } finally { clearTimeout(timer) }
}
let server
let serverUrl
let serverOutput
async function startClientServer() {
  const reservation = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch: () => new Response('reserved') })
  const port = reservation.port
  await reservation.stop(true)
  serverUrl = `http://127.0.0.1:${port}`
  server = Bun.spawn([client, 'serve', '--hostname', '127.0.0.1', '--port', String(port)], { cwd: root, env, stdout: 'pipe', stderr: 'pipe' })
  serverOutput = Promise.all([new Response(server.stdout).text(), new Response(server.stderr).text()])
  for (let attempt = 0; attempt < 150; attempt++) {
    try {
      const response = await fetch(`${serverUrl}/api/session?directory=${encodeURIComponent(root)}`, { headers: { authorization: serverAuthorization } })
      if (response.ok) return
    } catch (error) { if (server.exitCode !== null) throw error }
    await Bun.sleep(100)
  }
  throw new Error('OpenCode API did not start')
}
async function api(path, method = 'GET', payload) {
  const response = await fetch(`${serverUrl}${path}`, { method, headers: { 'content-type': 'application/json', authorization: serverAuthorization },
    ...(payload === undefined ? {} : { body: JSON.stringify(payload) }), signal: AbortSignal.timeout(180_000) })
  const text = await response.text()
  assert(response.ok, `${method} ${path}: ${response.status} ${text}`)
  return text ? JSON.parse(text) : undefined
}
const resumeEvidence = []
async function latestPrimaryTelemetry(session) {
  const requestId = requests.findLast(row => row.headers['x-opencode-session'] === session)?.requestId
  const rows = await (await fetch(`${proxyUrl}/telemetry/requests?limit=500`)).json()
  const row = rows.find(candidate => candidate.requestId === requestId)
  assert(row, 'No telemetry for the completed primary request')
  return row
}
function verifyResume(prior, current, label) {
  const priorRequest = requests.find(row => row.requestId === prior.requestId)
  const currentRequest = requests.find(row => row.requestId === current.requestId)
  assert(priorRequest && currentRequest)
  assert.equal(currentRequest.clientSystemHash, priorRequest.clientSystemHash, `${label}: client changed its system prompt; cache comparison is not stable`)
  assert.equal(current.isResume, true, `${label} did not resume`)
  assert.equal(current.lineageType, 'continuation', `${label} replayed the conversation`)
  assert.notEqual(current.sdkSessionId, prior.sdkSessionId, `${label} did not publish a distinct fork`)
  const cached = (prior.cacheReadInputTokens ?? 0) + (prior.cacheCreationInputTokens ?? 0)
  assert(cached > 0 && current.cacheReadInputTokens >= cached * 0.95, `${label} lost the cached prefix: ${current.cacheReadInputTokens}/${cached}`)
  resumeEvidence.push({ label, prior: prior.sdkSessionId, current: current.sdkSessionId, cached, cacheRead: current.cacheReadInputTokens })
}
try {
  const version = (await run([client, '--version'])).trim()
  assert(v1 ? version === '1.18.11' : ['opencode2 v0.0.0-beta-18314', 'opencode2 v0.0.0-beta-18866', 'opencode2 v0.0.0-beta-19271'].includes(version))
  await run([source ? process.execPath : 'node', join(repo, source ? 'bin/cli.ts' : 'dist/cli.js'), 'setup', v1 ? '--v1' : '--v2', '--opencode-bin', client])
  const path = join(config, 'opencode.json')
  const data = JSON.parse(readFileSync(path, 'utf8'))
  if (v1) data.permission = { external_directory: { [`${root}/*`]: 'allow' } }
  else data.permissions = [{ action: 'external_directory', resource: `${root}/*`, effect: 'allow' }]
  const provider = { settings: { apiKey: 'local-fixture-key', baseURL: `http://127.0.0.1:${endpoint.port}/v1` },
    headers: { 'x-opencode-session': 'spoofed', 'x-session-affinity': 'spoofed', 'x-meridian-source': 'spoofed', 'x-opencode-agent-mode': 'subagent' } }
  if (v1) data.provider = { anthropic: { options: provider.settings } }
  else data.providers = { anthropic: provider }
  writeFileSync(path, JSON.stringify(data, null, 2))
  if (extended) {
    await startClientServer()
    if (live) {
      // This is the warm-server gate. HTTP readiness precedes the asynchronous
      // catalog reload for models newer than the pinned client. The separate
      // --standalone probe below still tests cold cache seeding.
      let ready = false
      for (let attempt = 0; attempt < 150; attempt++) {
        const catalog = await api('/api/model')
        ready = catalog.data.some(model => model.providerID === 'anthropic' && model.id === 'claude-haiku-5-5')
        if (ready) break
        await Bun.sleep(100)
      }
      assert(ready, 'Warm client catalog never exposed claude-haiku-5-5')
      console.log(JSON.stringify({ warmCatalogReady: true, model: 'claude-haiku-5-5' }))
    }
  }
  const base = [client, 'run', ...(extended ? ['--server', serverUrl] : v1 ? [] : ['--standalone']), '--format', 'json', '--model', live ? 'anthropic/claude-haiku-5-5' : 'anthropic/claude-haiku-4-5-20251001']
  const initial = await run([...base, `Read ${fixturePath} using the read tool. Return only its receipt text. Do not inspect other files or run commands.`])
  const parse = text => text.split('\n').filter(line => line.startsWith('{')).map(line => JSON.parse(line))
  const first = parse(initial)
  assert(!first.some(event => event.type === 'error'), initial)
  assert(first.some(event => event.part?.type === 'tool' && event.part.state?.status === 'completed' && JSON.stringify(event.part.state.output).includes(receipt)),
    'Actual client did not complete a tool returning the fixture receipt')
  assert(first.some(event => event.type === 'text' && event.part?.text.includes(receipt)), initial)
  const session = first.find(event => event.sessionID)?.sessionID
  assert(session)
  let priorTelemetry = live ? await latestPrimaryTelemetry(session) : undefined
  const continued = await run([...base, '--session', session, '--agent', 'build', 'Return the receipt you just read, without calling tools.'])
  assert(parse(continued).some(event => event.type === 'text' && event.part?.text.includes(receipt)), continued)
  if (live) {
    const current = await latestPrimaryTelemetry(session)
    verifyResume(priorTelemetry, current, 'ordinary continuation')
    priorTelemetry = current
  }
  if (extended) {
    await proxy.close()
    await startMeridian()
    const restarted = parse(await run([...base, '--session', session, '--agent', 'build', 'Return the receipt again from context, without calling tools.']))
    assert(restarted.some(event => event.type === 'text' && event.part?.text.includes(receipt)), 'Restart lost the receipt')
    verifyResume(priorTelemetry, await latestPrimaryTelemetry(session), 'process restart')
  }
  // Warm-host selection must send the selected effort through the actual client.
  // The offline fixture separately proves Meridian-only catalog discovery;
  // current live Haiku variants can also exist in the client's native catalog.
  let variantProbe
  if (extended && discovery && !v1) {
    const variantModel = live ? 'anthropic/claude-haiku-5-5#xhigh' : 'anthropic/claude-haiku-4-5#xhigh'
    const modelIndex = base.lastIndexOf('--model')
    const variantArgs = [...base.slice(0, modelIndex), '--model', variantModel,
      'Reply with exactly VARIANT_OK and nothing else. Do not call tools.']
    const before = requests.length
    const output = await run(variantArgs, { allowFailure: true })
    const events = parse(output)
    const errors = events.filter(event => event.type === 'error').map(event => event.error?.type ?? 'unknown')
    const served = requests.slice(before)
    // Detached title requests can outlive the primary answer. Qualify the selected
    // primary variant and retain every request in the trace.
    const primaryVariant = served.filter(row => row.headers?.['x-opencode-agent-mode'] === 'primary'
      && !row.headers?.['x-meridian-source'])
    variantProbe = {
      model: variantModel,
      selected: errors.length === 0,
      errors,
      efforts: primaryVariant.map(row => row.effort ?? null),
      completed: primaryVariant.some(row => row.effort === 'xhigh')
        && primaryVariant.filter(row => row.effort === 'xhigh').every(row => typeof row.completedAt === 'number'),
      // Recorded, not asserted: the wording the model chooses varies between runs.
      answered: events.some(event => event.type === 'text' && event.part?.text.includes('VARIANT_OK')),
    }
    console.log(JSON.stringify({ variantProbe }))
    assert(variantProbe.selected, `Meridian-only variant was rejected: ${JSON.stringify(variantProbe.errors)}`)
    assert(variantProbe.efforts.includes('xhigh'), `Variant did not send its effort: ${JSON.stringify(variantProbe.efforts)}`)
    assert(variantProbe.completed, 'Variant request never completed upstream')
  }

  // #1008: a cold client process must accept a Meridian-only variant on its
  // FIRST request. That only works if the plugin seeded the catalog from its
  // cache before the first transform ran, so this deliberately spawns a fresh
  // `--standalone` process rather than reusing the warm server.
  let coldStartProbe
  if (!v1 && discovery) {
    const coldArgs = [client, 'run', '--standalone', '--format', 'json',
      '--model', live ? 'anthropic/claude-haiku-5-5#xhigh' : 'anthropic/claude-haiku-4-5#xhigh',
      'Reply with exactly COLD_OK and nothing else. Do not call tools.']
    const before = requests.length
    const output = await run(coldArgs, { allowFailure: true })
    const events = parse(output)
    const errors = events.filter(event => event.type === 'error').map(event => event.error?.type ?? 'unknown')
    const served = requests.slice(before)
    coldStartProbe = { errors, efforts: served.map(row => row.effort ?? null) }
    console.log(JSON.stringify({ coldStartProbe }))
    assert(errors.length === 0, `Cold start rejected the Meridian-only variant: ${JSON.stringify(errors)}`)
    assert(coldStartProbe.efforts.includes('xhigh'),
      `Cold start did not send the effort: ${JSON.stringify(coldStartProbe.efforts)}`)
  }

  // Hidden-agent header probing must not switch the primary client's active agent.
  if (!v1) {
    const summary = parse(await run([...base, '--session', session, '--fork', '--agent', 'summary', `Summarize the fixture receipt in one sentence. Probe token: ${summaryMarker}`]))
    assert(summary.some(event => event.sessionID && event.sessionID !== session))
    assert(requests.some(row => row.headers['x-opencode-agent-name'] === 'summary' && row.hasSummaryMarker))
  }
  const fork = parse(await run([...base, '--session', session, '--agent', 'build', '--fork', `This fork has tracking token ${forkMarker}. Return the same receipt, without tools.`]))
  assert(fork.some(event => event.type === 'text' && event.part?.text.includes(receipt)))
  const forkSession = fork.find(event => event.sessionID)?.sessionID
  assert(forkSession && forkSession !== session)
  assert(requests.some(row => row.headers['x-opencode-agent-name'] === 'build' && row.headers['x-opencode-session'] === forkSession && row.hasForkMarker))
  const original = parse(await run([...base, '--session', session, '--agent', 'build', 'Return the original receipt, without calling tools.']))
  assert(original.some(event => event.type === 'text' && event.part?.text.includes(receipt)))
  assert.equal(requests.findLast(row => row.headers['x-opencode-session'] === session)?.hasForkMarker, false)
  if (extended) {
    const undoPath = join(root, 'undo.txt')
    writeFileSync(undoPath, undoMarker)
    const disposable = parse(await run([...base, '--session', session, '--agent', 'build', `Read ${undoPath} with read and return its exact text only.`]))
    assert(disposable.some(event => event.type === 'text' && event.part?.text.includes(undoMarker)))
    const context = await api(`/api/session/${session}/context`)
    const removed = context.data.find(message => message.type === 'user' && message.text.includes(undoPath))
    assert(removed, 'Missing disposable user message in supported context API')
    await api(`/api/session/${session}/revert/stage`, 'POST', { messageID: removed.id, files: false })
    await api(`/api/session/${session}/revert/commit`, 'POST')
    assert(!JSON.stringify(await api(`/api/session/${session}/context`)).includes(undoMarker), 'Undo retained removed result')
    const undone = parse(await run([...base, '--session', session, '--agent', 'build', 'Return the original fixture receipt from context without tools.']))
    assert(undone.some(event => event.type === 'text' && event.part?.text.includes(receipt)))
    assert.equal(requests.findLast(row => row.headers['x-opencode-session'] === session)?.hasUndoMarker, false)
    const childStart = requests.length
    const children = parse(await run([...base, '--session', session, '--agent', 'build',
      'Launch two general subagents concurrently with the task tool. Ask the first to reply CHILD_ALPHA_ONLY and the second CHILD_BRAVO_ONLY, without tools. Wait for both and report both exact tokens. Do not read files or use shell commands.']))
    assert(children.some(event => event.type === 'text' && event.part?.text.includes('CHILD_ALPHA_ONLY') && event.part.text.includes('CHILD_BRAVO_ONLY')))
    const childRequests = requests.slice(childStart).filter(row => row.headers['x-opencode-agent-name'] === 'general')
    assert(new Set(childRequests.map(row => row.headers['x-opencode-session'])).size >= 2, 'No distinct general child sessions')
    assert(childRequests.every(row => row.headers['x-opencode-agent-mode'] === 'subagent'))
    assert(childRequests.some((a, index) => childRequests.some((b, other) => index !== other && a.startedAt < b.completedAt && b.startedAt < a.completedAt)), 'Child requests did not overlap')
    await run([...base, '--session', session, '--agent', 'build', 'Our next task needs the original fixture receipt exactly. State it now and preserve it for the next turn. Do not call tools.'])
    await api(`/api/session/${session}/compact`, 'POST', {})
    await api(`/api/session/${session}/wait`, 'POST')
    const compacted = await api(`/api/session/${session}/context`)
    assert(compacted.data.some(message => message.type === 'compaction' && message.summary), 'No durable compaction summary')
    const afterCompact = parse(await run([...base, '--session', session, '--agent', 'build', 'Return the original receipt exactly from context, without tools.']))
    assert(afterCompact.some(event => event.type === 'text' && event.part?.text.includes(receipt)))
    const compactionRequests = requests.filter(row => row.headers['x-opencode-agent-name'] === 'compaction')
    assert(compactionRequests.length)
    assert(compactionRequests.every(row => row.headers['x-opencode-session'] === session && row.headers['x-meridian-source'] === 'subagent-compaction'))
  }
  assert(requests.length > 0, 'No API request reached fixture')
  assert(requests.some(row => row.headers['x-opencode-agent-mode'] === 'primary'), 'Primary plugin hook did not run')
  for (const name of v1 ? [] : ['title', 'summary']) {
    const rows = requests.filter(row => row.headers['x-opencode-agent-name'] === name)
    assert(rows.length, `No ${name} request observed`)
    for (const { headers } of rows) {
      assert.equal(headers['x-meridian-source'], `subagent-${name}`)
      assert.equal(headers['x-opencode-agent-mode'], 'subagent')
      for (const header of ['x-opencode-session', 'x-session-affinity', 'x-session-id', 'x-parent-session-id', 'x-meridian-opencode-turn']) assert(!headers[header], `${name} retained ${header}`)
    }
  }
  for (const { headers } of requests.filter(row => row.headers['x-opencode-agent-name'] === 'build')) {
    assert.equal(headers['x-opencode-agent-mode'], 'primary')
    assert(headers['x-opencode-session'] && headers['x-opencode-session'] !== 'spoofed')
    assert(!headers['x-meridian-source'])
  }
  if (!live) assert(deliveredResultSeen, 'Actual file result did not return to the API')
  assert.equal((await run([client, '--version'])).trim(), version)
  const primaryRows = requests.filter(row => row.headers['x-opencode-agent-name'] === 'build')
  assert(primaryRows.length > 0)
  assert(primaryRows.every(row => !row.hasSummaryMarker), 'Hidden-agent probe entered primary client history')
  assert(primaryRows.every(row => row.clientCwd === root), JSON.stringify(primaryRows.map(row => row.clientCwd)))
  if (process.argv.includes('--separate-proxy-cwd')) assert.notEqual(proxyWorkdir, root)

  // #1004 model discovery. The original contributor version requested
  // `/v1/v1/models` because the Anthropic provider carries the version in its
  // base URL, so discovery 404'd and silently applied nothing. Assert the exact
  // path, not merely that some request arrived.
  if (!v1) {
    const catalogHits = discoveryRequests.filter(row => row.method === 'GET' && row.path.endsWith('/models'))
    assert(catalogHits.length > 0, 'Model discovery never requested the catalog')
    assert(catalogHits.every(row => row.path === '/v1/models'),
      `Discovery requested the wrong path: ${JSON.stringify(catalogHits.map(row => row.path))}`)
    if (discovery) {
      // Attempts the client abandoned on process exit are expected; at least one
      // must have completed, and nothing may fail for another reason.
      assert(catalogHits.every(row => row.status === 200 || row.aborted === true),
        `Discovery failed for an unexpected reason: ${JSON.stringify(catalogHits.map(row => ({ status: row.status, error: row.error })))}`)
      const served = catalogHits.filter(row => row.status === 200)
      assert(served.length > 0, 'No discovery request ever completed')
      const payload = JSON.parse(served[0].body)
      assert(Array.isArray(payload.data) && payload.data.length > 0, 'Discovery response carried no catalog')
      const haiku = payload.data.find(model => model.id === (live ? 'claude-haiku-5-5' : 'claude-haiku-4-5'))
      assert(haiku, `Catalog omitted the selected Haiku model: ${JSON.stringify(payload.data.map(model => model.id))}`)
      // The two values OpenCode's own entry gets wrong, and the reason applying
      // the catalog has to overwrite rather than skip an existing model.
      assert.equal(haiku.context_window, live ? 1_000_000 : 200_000, 'Catalog advertised an unexpected Haiku context window')
      assert.equal(haiku.capabilities?.effort?.xhigh?.supported, true, 'Catalog did not advertise the xhigh effort')
    } else {
      assert(catalogHits.every(row => row.status === 404), 'Negative control served a catalog')
    }
  }

  // #1008 invalidation. The seed is applied optimistically, because a draft
  // Provider.Info carries no URL to check it against, so the guarantee is
  // self-healing rather than prevention: once a cold process sees no
  // Meridian-shaped provider it drops the cache, and the next one is back to
  // OpenCode's own catalog. Only those two facts are asserted. The first
  // repointed run is recorded but not asserted — whether it still offers the
  // variant depends on how far model resolution gets before discovery lands.
  // Asserted here, at the end, because it rewrites the client config.
  let invalidationProbe
  if (!v1 && discovery && !live) {
    const cachePath = join(root, 'meridian', 'opencode-v2-catalog.json')
    assert(existsSync(cachePath), 'Discovery never wrote a catalog cache to seed')
    const repointed = JSON.parse(readFileSync(path, 'utf8'))
    repointed.providers = { anthropic: { settings: { apiKey: 'local-fixture-key', baseURL: 'https://meridian-repointed.invalid/v1' } } }
    writeFileSync(path, JSON.stringify(repointed, null, 2))
    const variantArgs = ['run', '--standalone', '--format', 'json',
      '--model', live ? 'anthropic/claude-haiku-5-5#xhigh' : 'anthropic/claude-haiku-4-5#xhigh', 'Reply with exactly REPOINTED and nothing else.']
    const firstOutput = await run([client, ...variantArgs], { allowFailure: true })
    const cacheDropped = !existsSync(cachePath)
    const secondOutput = await run([client, ...variantArgs], { allowFailure: true })
    const errorsOf = output => parse(output).filter(event => event.type === 'error').map(event => event.error?.type ?? 'unknown')
    invalidationProbe = { cacheDropped, first: errorsOf(firstOutput), second: errorsOf(secondOutput) }
    console.log(JSON.stringify({ invalidationProbe }))
    assert(cacheDropped, 'Repointing the provider away from Meridian left the seed in place')
    assert(invalidationProbe.second.includes('provider.no-route'),
      `A repointed provider still offered a Meridian-only variant: ${JSON.stringify(invalidationProbe.second)}`)
  }
  console.log(JSON.stringify({ result: 'PASS', version, source, live, extended, discovery, root, session, requests, resumeEvidence, discoveryRequests, variantProbe, coldStartProbe, invalidationProbe }))
} finally {
  teardownStarted = true
  if (server) { server.kill(); await server.exited; console.log(JSON.stringify({ serverOutput: await serverOutput })) }
  await endpoint.stop(true)
  await proxy?.close()
  console.log(JSON.stringify({ requestTrace: requests, discoveryTrace: discoveryRequests }))
  if (live) console.log(JSON.stringify({ proxyOutputs }))
}
