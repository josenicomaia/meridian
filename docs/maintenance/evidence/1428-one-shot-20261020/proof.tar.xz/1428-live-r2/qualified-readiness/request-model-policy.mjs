import assert from 'node:assert/strict'
export function expectedRequestModel(row){
 assert(row&&typeof row.model==='string','SDK query lacks its original HTTP model request')
 if(row.agent==='title'){
  assert.equal(row.mode,'subagent');assert.equal(row.source,'subagent-title');assert(!row.session)
  assert(['claude-haiku-4-5','claude-haiku-5-5'].includes(row.model),'Unexpected client title model')
 }else assert.equal(row.model,'claude-haiku-5-5','Only the detached title may request the legacy model')
 return {...row}
}

// Official pre-4.6 convenience alias; no cross-generation normalization.
export function canonicalResponseModel(model){return model==='claude-haiku-4-5'?'claude-haiku-4-5-20251001':model}
