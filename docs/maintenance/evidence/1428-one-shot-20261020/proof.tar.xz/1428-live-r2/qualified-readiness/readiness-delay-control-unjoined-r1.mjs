import assert from 'node:assert/strict';import {writeFileSync}from'node:fs';import {probeClientReady}from'./boundedClientReadiness.mjs';
const output=process.argv[2],rows=[];
for(const mode of ['old-unbounded','new-bounded']){
 let calls=0,aborts=0,settled=false,joined=false;
 const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(request){calls++;if(calls===1){request.signal.addEventListener('abort',()=>aborts++);return new Promise(()=>{})}return Response.json({data:[]})}});const url='http://127.0.0.1:'+server.port+'/api/session';
 if(mode==='old-unbounded'){
  const pending=fetch(url,{headers:{authorization:'owned-control'}}).then(response=>{settled=true;return response.ok},()=>{settled=true;return false});
  await Bun.sleep(250);assert.equal(calls,1);assert.equal(settled,false);await server.stop(true);await pending;joined=true;
  rows.push({mode,settledBeforeDeadline:false,calls,joined,realGenerations:0});
 }else{
  let ready=false,firstError;
  for(let n=0;n<3;n++)try{ready=await probeClientReady(url,'owned-control',100);if(ready)break}catch(error){firstError??=error.name}
  assert(ready&&calls===2&&firstError==='TimeoutError');await server.stop(true);joined=true;rows.push({mode,ready,calls,firstError,aborts,joined,realGenerations:0});
 }
}
writeFileSync(output,JSON.stringify({result:'PASS',scope:'Controlled first HTTP readiness response stalls; exact new helper retries only bodyless readiness before any model activity',rows},null,2)+'\n');console.log(JSON.stringify(rows));
