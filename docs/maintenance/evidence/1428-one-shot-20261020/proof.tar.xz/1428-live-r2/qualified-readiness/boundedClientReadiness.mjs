export async function probeClientReady(url, authorization, timeoutMs=1000) {
 const response=await fetch(url,{headers:{authorization},signal:AbortSignal.timeout(timeoutMs)})
 await response.arrayBuffer() // Readiness includes a complete response, not only headers.
 return response.ok
}
