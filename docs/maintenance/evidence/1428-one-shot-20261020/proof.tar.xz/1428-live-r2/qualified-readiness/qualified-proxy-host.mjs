// Owned proxy subprocess for live OpenCode gates, including real process restart.
import assert from 'node:assert/strict'
import * as cp from 'node:child_process'
import {spyOn} from 'bun:test'
import {readFileSync,statSync,mkdirSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import {createRequire} from 'node:module'
import {AsyncLocalStorage} from 'node:async_hooks'
import {randomUUID} from 'node:crypto'
import {expectedRequestModel} from './request-model-policy.mjs'
import {pathToFileURL} from 'node:url'
import {resolveOpenCodeScrub,configureOpenCodeScrub,verifyOpenCodeScrub} from '/private/tmp/meridian-pr1428-20261020/scripts/lib-opencode-scrub-preflight.mjs'
import {observeChildClosure,stopAndJoinChild} from '/private/tmp/meridian-pr1428-20261020/scripts/lib/e2eProcessCustody.mjs'
assert.equal(process.env.E2E_ALLOW_LIVE_MODEL,'1')
const scrub=resolveOpenCodeScrub(process.env.E2E_PLUGIN_PATH,process.env.E2E_SCRUB_VERSION)
const grant=process.env.E2E_LIVE_PROFILE_FILE
assert.equal(statSync(grant).mode&0o077,0,'Access-only grant must be private')
const profiles=JSON.parse(readFileSync(grant,'utf8'))
assert(Array.isArray(profiles)&&profiles.length===1&&profiles[0].type==='oauth-token'&&typeof profiles[0].oauthToken==='string'&&!profiles[0].refreshToken)
assert(process.env.MERIDIAN_CONFIG_DIR&&process.env.MERIDIAN_WORKDIR&&process.env.E2E_PROXY_REPORT_DIR)
mkdirSync(process.env.MERIDIAN_CONFIG_DIR,{recursive:true})
mkdirSync(process.env.E2E_PROXY_REPORT_DIR,{recursive:true})
process.env.MERIDIAN_CREDENTIALS_READONLY='1'
if(process.env.E2E_NATIVE_BIN)process.env.MERIDIAN_CLAUDE_PATH=process.env.E2E_NATIVE_BIN
process.chdir(process.env.MERIDIAN_WORKDIR)
const actors=[],spies=[]
for(const name of ['spawn','execFile']){const original=cp[name];spies.push(spyOn(cp,name).mockImplementation((...args)=>{const child=Reflect.apply(original,cp,args);actors.push({child,witness:observeChildClosure(child)});return child}))}
const report={pid:process.pid,result:'RUNNING',children:[]}
const {installModelObserver}=await import('/tmp/meridian-resume-20261020/1428-live-r2/qualified-readiness/model-observer.mjs')
const requestModels=new AsyncLocalStorage()
function expectedForQuery(){return expectedRequestModel(requestModels.getStore())}
const modelObserver=await installModelObserver(process.env.E2E_MERIDIAN_ROOT,join(process.env.E2E_PROXY_REPORT_DIR,`models-${process.pid}.json`),process.env.E2E_EXPECT_MODEL,expectedForQuery)
const {startProxyServer}=await import(process.env.E2E_PROXY_MODULE)
const proxy=await startProxyServer({port:0,host:'127.0.0.1',silent:true,profiles,defaultProfile:profiles[0].id,...configureOpenCodeScrub(process.env.MERIDIAN_CONFIG_DIR,scrub)})
report.clientRequests=[]
const originalEmit=proxy.server.emit
proxy.server.emit=function(event,...args){
 if(event!=='request'||new URL(args[0].url,'http://localhost').pathname!=='/v1/messages')return originalEmit.call(this,event,...args)
 const req=args[0],row={requestId:req.headers['x-request-id']??randomUUID(),agent:req.headers['x-opencode-agent-name'],mode:req.headers['x-opencode-agent-mode'],source:req.headers['x-meridian-source'],session:req.headers['x-opencode-session']??null};report.clientRequests.push(row)
 const emit=req.emit;let body=''
 req.emit=function(event,...values){if(event==='data'){body+=Buffer.from(values[0]).toString();assert(body.length<4*1024*1024)}if(event==='end'){try{row.model=JSON.parse(body).model}catch{row.parseFailure=true}}return emit.call(this,event,...values)}
 return requestModels.run(row,()=>originalEmit.call(this,event,...args))
}
const url=`http://127.0.0.1:${proxy.server.address().port}`
report.scrubPreflight=verifyOpenCodeScrub(await(await fetch(url+'/plugins/list')).json(),scrub)
process.send({port:proxy.server.address().port,pid:process.pid})
let closing=false
async function close(){
 if(closing)return;closing=true
 try{
 const rows=await(await fetch(url+'/telemetry/requests?limit=500')).json()
 const require=createRequire(process.env.E2E_PROXY_MODULE);const sdk=await import(pathToFileURL(require.resolve('@anthropic-ai/claude-agent-sdk')).href)
 // Only application-owned mapping metadata is read directly. Transcript
 // content is queried exclusively through the supported SDK API.
 const mappings=JSON.parse(readFileSync(join(process.env.MERIDIAN_SESSION_DIR,'sessions.json'),'utf8'))
 const locators=Object.values(mappings).flatMap(row=>[row.currentTranscript,row.previousTranscript]).filter(Boolean)
 const configs=[...new Set(locators.map(row=>row.configDir))]
 assert(configs.length===1&&configs[0].startsWith(process.env.MERIDIAN_CONFIG_DIR+'/'),'One owned namespace required')
 process.env.CLAUDE_CONFIG_DIR=configs[0]
 const dirs=[...new Set(locators.map(row=>row.projectDir).filter(Boolean))]
 const ids=new Set(modelObserver.witness.native.map(row=>row.session).filter(Boolean))
 const stored=[]
 report.sdkHistoryReads=[]
 for(const id of ids){
  const info=await sdk.getSessionInfo(id)
  let messages=[]
  if(info?.cwd){
   const ownedRoot=process.env.MERIDIAN_CONFIG_DIR.slice(0,process.env.MERIDIAN_CONFIG_DIR.lastIndexOf('/'))
   assert(info.cwd===ownedRoot||info.cwd.startsWith(ownedRoot+'/'),'SDK project escaped owned root')
   messages=await sdk.getSessionMessages(id,{dir:info.cwd})
  }
  // The public conversation projection can omit auxiliary sessions. The SDK's
  // public import API exposes their stored records to this in-memory sink.
  // Never open private SDK files or retain message content in the witness.
  const imported=[]
  await sdk.importSessionToStore(id,{async append(_key,rows){for(const row of rows)if(row.type==='assistant')imported.push({type:'assistant',message:{id:row.message?.id,model:row.message?.model}})}},{includeSubagents:false})
  report.sdkHistoryReads.push({session:id,conversationMessages:messages.length,importedAssistantRecords:imported.length})
  modelObserver.recordStored({claudeSessionId:id},[...messages,...imported])
  stored.push(...[...messages,...imported].filter(row=>row.type==='assistant').map(row=>({id:row.message?.id,model:row.message?.model})))
 }

 const witness=modelObserver.witness
 assert(!witness.stopped,'Model boundary stopped: '+witness.stopped)
 assert(witness.provider.length>0&&stored.length>0,'Actual model metadata missing')
 for(const row of witness.provider){assert.equal(row.status,200);const start=row.events.find(e=>e.type==='message_start');assert(start?.id&&start.model===row.expectedResponseModel)
  assert(witness.native.some(n=>n.query===row.query&&n.id===start.id&&n.model===start.model),'Native response correlation missing')
  assert(stored.some(s=>s.id===start.id&&s.model===start.model),'Stored response correlation missing')
 }
 report.observedModels=[...new Set(stored.map(row=>row.model))];assert(report.observedModels.every(model=>['claude-haiku-4-5-20251001','claude-haiku-5-5'].includes(model)))
 report.providerNativeStoredCorrelated=true

 report.scrubFinal=verifyOpenCodeScrub(await(await fetch(url+'/plugins/list')).json(),scrub);report.result='PASS'}catch(error){report.result='FAIL';report.failure=String(error)}
 try{await proxy.close()}catch(error){report.result='FAIL';report.closeFailure=error?.name??'UnknownError'}
 await modelObserver.close()
 for(const actor of actors)report.children.push(await stopAndJoinChild(actor.child,actor.witness))
 report.joined=report.children.every(row=>row.joined);if(!report.joined)report.result='FAIL'
 for(const spy of spies.reverse())spy.mockRestore()
 writeFileSync(join(process.env.E2E_PROXY_REPORT_DIR,`proxy-${process.pid}.json`),JSON.stringify(report,null,2)+'\n',{mode:0o600})
 process.exit(report.result==='PASS'?0:1)
}
process.on('SIGTERM',()=>void close())
process.on('SIGINT',()=>void close())
