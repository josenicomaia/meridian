from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1428-live-r2';w=Path('/private/tmp/meridian-1406-evidence-20261020');target=w/'docs/maintenance/evidence/1428-one-shot-20261020'
tasks=[json.loads((out/n).read_text()) for n in ['first-team-comparison.json','completion-team-comparison.json','final-client-matrix.json']]
assert tasks[-1]['result']=='PASS' and all(t['grantRemoved'] and t['holdsUnchanged'] for t in tasks)
qualified=[row for task in tasks for row in task['cases'] if row.get('qualified')];assert len(qualified)==22
total=sum(row.get('generations',0) for row in qualified);assert total>0
assert [row['generations'] for task in tasks for row in task['cases'] if not row.get('qualified')]==[0,0]
head='e5100bd4cf40804cb8799f5a85a63890fe668984';base='6f50d2f315f62369c99a9cd307e2beaa93440a6c'
local=json.loads((r/'1428-final-e510-local-exit.json').read_text());assert local['exit']==0 and local['totals']=={'pass':7091,'skip':36,'fail':0} and local['invocations']==25
ci=json.loads(subprocess.check_output(['gh','pr','view','1428','--repo','rynfar/meridian','--json','state,headRefOid,mergeStateStatus,statusCheckRollup,headRepositoryOwner,headRefName'],text=True));assert ci['headRefOid']==head and ci['state']=='OPEN';assert len(ci['statusCheckRollup'])==9 and sum(row['conclusion']=='SUCCESS'for row in ci['statusCheckRollup'])==8 and sum(row['conclusion']=='SKIPPED'for row in ci['statusCheckRollup'])==1
(out/'final-CI.json').write_text(json.dumps(ci,indent=2)+'\n')
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':head,'baseline':base,'qualifiedCases':22,'actualGenerations':total,'retainedPreInferenceFailedCases':2,'eachFailedCaseActualGenerations':0,'local':local,'CI':ci,'allGrantsRemoved':True,'olderHoldsUnchanged':True,'harnessPR':json.loads((out/'owner-harness-pr.json').read_text()),'oldPersonalQuotaFailureRetained':True,'currentComparisonAccount':'SameownedTeamordinal1throughout; paidExtraUsagedisabled; capacityexplicitlyunknown; freshofficialprofilepercase; noOAuthrefresh/credentialwrite','originalClientReadinessStallCause':'Unknown; zero-modeloriginalretained; controlledHTTPdeadlineprovesboundedprobecompletion, not clientproductfix'}
models=set()
for task in tasks:
 for row in task['cases']:
  d=out/row['case']
  report=d/'report.json'
  if report.exists():
   x=json.loads(report.read_text());models.update(p.get('responseModel') for p in x.get('provider',[]) if p.get('responseModel'))
  for p in (d/'proxy').glob('models-*.json'):
   x=json.loads(p.read_text());models.update(e.get('model') for row in x.get('provider',[]) for e in row.get('events',[]) if e.get('model'))
summary['actualResponseModels']=sorted(models);(out/'final-qualified-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
def add(p,name=None):
 p=Path(p);assert p.is_file(),p;data=p.read_bytes();assert not re.search(rb'sk-ant-[A-Za-z0-9_-]{15,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data),p
 files[name or str(p.relative_to(r))]=data
for n in ['1428-final-credit-and-signatures.json','1428-current-main-integration.json','1428-pre-main-integration.json','1428-pre-main-integration-body.md','1428-final-adversarial-review.json','1428-final-e510-local-exit.json','1428-final-e510-workflow-approval.json','1428-title-live-summary.json','1428-installed-title-protocol-qualified.json','1428-beta-title-summary-protocol-qualified.json','root-checkout-preserved-current.json']:add(r/n)
for p in out.glob('*.py'):add(p)
for p in out.glob('*.mjs'):add(p)
for p in out.glob('*.json'):add(p)
for folder in ['qualified','qualified-readiness']:
 for p in (out/folder).glob('*.mjs'):add(p)
add(out/'packages/summary.json')
for task in tasks:
 for row in task['cases']:
  d=out/row['case']
  for n in ['report.json','forward-journal.json','model-witness.json','native-args.jsonl']:
   if (d/n).is_file():add(d/n)
  for p in (d/'proxy').glob('*.json'):add(p)
for folder in ['catalog-delay-cold-r1','catalog-delay-warm-r1',*[row['case'] for row in json.loads((out/'offline-summary.json').read_text())['cases']]]:
 p=out/folder/'report.json'
 if p.is_file():add(p)
old=r/'1428-title-live-baseline-r1/report.json'
if old.is_file():add(old)
for label in ['focused','typecheck','build']:
 p=r/('1428-final-e510-'+label+'.log');add(p)
full=r/'1428-final-e510-full.log';s=full.read_text();files['full-local-totals-and-sha.txt']=('Full local log SHA256 '+hashlib.sha256(full.read_bytes()).hexdigest()+'\n'+'\n'.join(line for line in s.splitlines() if re.match(r'^\s*\d+ (?:pass|skip|fail)\s*$',line))+'\n').encode()
files['final-application.patch']=subprocess.check_output(['git','diff',base,head],cwd='/private/tmp/meridian-pr1428-20261020')
files['manifest.sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},indent=2)+'\n').encode()
target.mkdir();p=target/'proof.tar.xz'
with tarfile.open(p,'w:xz',preset=9)as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(p.read_bytes()).hexdigest()
(target/'README.md').write_text(f'''# OpenCode one-shot prompt proof\n\nOriginal PR #1428 source `{head}` against unchanged main `{base}`. The adapter-boundary correction limits replacement system prompts to OpenCode one-shot title/summary requests with client prompts enabled. Ordinary turns, compaction, other adapters and client-prompt opt-outs keep their configured behavior.\n\nFinal local gates:7091pass/36skip/0fail across25isolated invocations; focused/typecheck/build0;8executedCIchecksSUCCESS+expectedskip. Required test: https://github.com/rynfar/meridian/actions/runs/39481622366/job/118832718354\n\n22qualified actual cases,{total}real generations: actual pinned OpenCode2.0.31 on DebianLinuxarm64, SDK0.2.141/native2.1.301 and independently installed baseline/candidate packages; three pinned Macbeta title+summary baseline/candidate pairs; all4E41 modes on Macnative2.1.302;10supported-client E42 source/package cases. PrimaryHaiku5.5 and originalolderclientdetachedHaiku4.5 role/alias are checked against each originalrequest/provider/native/publicSDKmessage. Alloriginalactors/pipesjoined, allgrantsremoved, olderholdhashunchanged.\n\nThe Linux baseline's actual detached title answered `NONE`; the candidate returned a descriptive title. Both retained all four primary/agent-switch turns. Native initialization records baseline append-domain versus candidate replacement-domain; actual title and summary hooks are present. Complete reports retain original responses from owned fixture prompts only.\n\nThe original personal-account included-quota rejection remains unqualified and is not claimed recovered. The fix has no account or entitlement branches; the new controlled comparison uses one owned Team account throughout, fresh official active-profile metadata with paidExtraUsage disabled, explicitly unknown currentwindows and fixedattemptbounds. No OAuthrefresh, credentialwrite, usageendpointretry or billingchange.\n\nTwo new zero-generation preflight failures are retained. A pinned beta submitted before asynchronous catalog adoption; controlled1000msdelay reproduces coldModelUnavailable and warmreadinesspasses, followed by actualsamebeta baseline/candidate passes. Later an unbounded firstHTTPreadiness fetch stalled despite independent boundedHTTPresponses; the originalclientstallcause remainsunknown. The verified ownedclient was stopped and originalactorsjoined with0queries. An exact bounded complete-response readiness helper passes controlled first-response timeout/second-readinesssuccess, joining both requests/server; the remaining cases use that helper. No claim that the client startup bug itself is fixed. One initially unjoined synthetic HTTP control was retained and corrected by resolving its originalrequest beforejoining.\n\nExact reusable stable/beta titleharness scripts are committed separately in ownerPR #1432 (`980864bc4492e67168b6f204d665952052d6fca0`), keeping this contributor's branch free of evidence-only changes. The archive includes every executed controller/helper variant, complete metadata, causal controls, packageidentities, originalquota failure and originalPRarchive.\n\nArchive SHA256 `{sha}`,{p.stat().st_size}bytes,{len(files)}regularfiles. Verify `manifest.sha256.json`, inspect the scripts, supply pinnedabsoluteclient/native/package paths and privateaccess-onlycredentials, and run in new isolateddirectories. No credentials/customertranscripts/privateSDKfiles included.\n''')
receipt={'sha256':sha,'bytes':p.stat().st_size,'files':len(files),'summary':{'qualifiedCases':22,'actualGenerations':total,'local':'7091/36/0all25','head':head,'base':base},'path':str(p)};(out/'durable-proof-prepared.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
