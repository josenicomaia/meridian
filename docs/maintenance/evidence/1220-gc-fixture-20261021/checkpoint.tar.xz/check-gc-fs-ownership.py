from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/1220-current-composition');priority=root/'src/__tests__/priority-client-cancel.test.ts';contract=root/'src/__tests__/bookkeeping-store-contract.test.ts';fixed=priority.read_bytes();original=contract.read_bytes();before=subprocess.check_output(['git','show','HEAD:src/__tests__/priority-client-cancel.test.ts'],cwd=root)
probe='''
// Temporary real-FS provenance diagnostic, confined to this child test process.
import { AsyncLocalStorage } from "node:async_hooks"
import * as gcProbe from "../proxy/sessionLifecycle"
import * as fsProbe from "node:fs/promises"
import { mock } from "bun:test"
const gcScopes = new AsyncLocalStorage<string>()
const actualGc = gcProbe.runGc
const actualChmod = fsProbe.chmod
let totalGcCalls = 0
const foreignGcPaths: Array<{ origin: string; target: string }> = []
mock.module("../proxy/sessionLifecycle", () => ({ ...gcProbe,
  runGc: (...args: Parameters<typeof actualGc>) => {
    totalGcCalls++
    return gcScopes.run(store.getSessionStoreDir(), () => actualGc(...args))
  },
}))
const chmodSpy = spyOn(fsProbe, "chmod").mockImplementation(async (...args: Parameters<typeof actualChmod>) => {
  const origin = gcScopes.getStore(), target = String(args[0])
  if (origin && target.includes("/bookkeeping-store-contract-") && origin !== target) foreignGcPaths.push({ origin, target })
  return actualChmod(...args)
})
afterAll(() => {
  chmodSpy.mockRestore()
  console.log("GC_FS_PROVENANCE", JSON.stringify({ totalGcCalls, foreignGcPaths }))
  expect(totalGcCalls).toBeGreaterThan(0)
  expect(foreignGcPaths).toEqual([])
})
''';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';records=[]
try:
 contract.write_bytes(original+probe.encode())
 for label,data in [('before',before),('after',fixed)]:
  priority.write_bytes(data)
  with(out/f'gc-fs-ownership-{label}.log').open('w')as log:p=subprocess.run([bun,'test','src/__tests__/priority-client-cancel.test.ts','src/__tests__/bookkeeping-store-contract.test.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(out/f'gc-fs-ownership-{label}.log').read_text();records.append({'case':label,'exit':p.returncode,'provenance':[l for l in text.splitlines()if l.startswith('GC_FS_PROVENANCE')],'failed':[l for l in text.splitlines()if l.startswith('(fail)')]});print(json.dumps(records[-1]),flush=True)
finally:
 priority.write_bytes(fixed);contract.write_bytes(original)
 assert priority.read_bytes()==fixed and contract.read_bytes()==original
 (out/'gc-fs-ownership-control.json').write_text(json.dumps({'cases':records,'sourceBytesRestored':True,'prioritySha256':hashlib.sha256(fixed).hexdigest(),'contractSha256':hashlib.sha256(original).hexdigest(),'models':0},indent=2)+'\n')
