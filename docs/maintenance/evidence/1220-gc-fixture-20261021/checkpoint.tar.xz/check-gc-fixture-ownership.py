from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/1220-current-composition');priority=root/'src/__tests__/priority-client-cancel.test.ts';contract=root/'src/__tests__/bookkeeping-store-contract.test.ts';fixed=priority.read_bytes();original=contract.read_bytes();before=subprocess.check_output(['git','show','HEAD:src/__tests__/priority-client-cancel.test.ts'],cwd=root)
probe='''\n// Temporary provenance diagnostic: these pure contract cases never request GC.
import * as gcProbe from "../proxy/sessionLifecycle"
const actualGc = gcProbe.runGc
let foreignGcCalls = 0
const gcSpy = spyOn(gcProbe, "runGc").mockImplementation((...args: Parameters<typeof actualGc>) => {
  if (store.getSessionStoreDir().includes("/bookkeeping-store-contract-")) foreignGcCalls++
  return actualGc(...args)
})
afterAll(() => {
  gcSpy.mockRestore()
  console.log("GC_PROVENANCE", JSON.stringify({ foreignGcCalls }))
  expect(foreignGcCalls).toBe(0)
})
''';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';records=[]
try:
 contract.write_bytes(original+probe.encode())
 for label,data in [('before',before),('after',fixed)]:
  priority.write_bytes(data)
  with(out/f'gc-ownership-{label}.log').open('w')as log:p=subprocess.run([bun,'test','src/__tests__/priority-client-cancel.test.ts','src/__tests__/bookkeeping-store-contract.test.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(out/f'gc-ownership-{label}.log').read_text();records.append({'case':label,'exit':p.returncode,'provenance':[l for l in text.splitlines()if l.startswith('GC_PROVENANCE')],'failed':[l for l in text.splitlines()if l.startswith('(fail)')]});print(json.dumps(records[-1]),flush=True)
finally:
 priority.write_bytes(fixed);contract.write_bytes(original)
 assert priority.read_bytes()==fixed and contract.read_bytes()==original
 (out/'gc-ownership-control.json').write_text(json.dumps({'cases':records,'sourceBytesRestored':True,'prioritySha256':hashlib.sha256(fixed).hexdigest(),'contractSha256':hashlib.sha256(original).hexdigest(),'models':0},indent=2)+'\n')
