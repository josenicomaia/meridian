from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/1220-current-composition');priority=root/'src/__tests__/priority-client-cancel.test.ts';fixed=priority.read_bytes();before=subprocess.check_output(['git','show','82ff117dee79fb04f815efcb6c70aa5c1cc770ad:src/__tests__/priority-client-cancel.test.ts'],cwd=root)
probe='''
// Temporary isolated-file observer of the real pending-work registry.
import { afterAll as probeAfterAll } from "bun:test"
import { hasPendingSessionDeletionCleanup as probePending } from "../proxy/session/deletionCleanup"
import { getSessionStoreDir as probeDirectory } from "../proxy/sessionStore"
probeAfterAll(() => {
  const pending = probePending(probeDirectory())
  console.log("GC_PENDING_AFTER_FILE", JSON.stringify({ pending }))
  expect(pending).toBe(false)
})
''';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';records=[]
try:
 for label,data in [('before',before),('after',fixed)]:
  priority.write_bytes(data+probe.encode())
  with(out/f'gc-pending-owner-{label}.log').open('w')as log:p=subprocess.run([bun,'test','src/__tests__/priority-client-cancel.test.ts','src/__tests__/bookkeeping-store-contract.test.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(out/f'gc-pending-owner-{label}.log').read_text();records.append({'case':label,'exit':p.returncode,'provenance':[l for l in text.splitlines()if l.startswith('GC_PENDING_AFTER_FILE')],'failed':[l for l in text.splitlines()if l.startswith('(fail)')]});print(json.dumps(records[-1]),flush=True)
finally:
 priority.write_bytes(fixed);assert priority.read_bytes()==fixed
 (out/'gc-pending-owner-control.json').write_text(json.dumps({'cases':records,'sourceBytesRestored':True,'prioritySha256':hashlib.sha256(fixed).hexdigest(),'models':0},indent=2)+'\n')
