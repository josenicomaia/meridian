import { spyOn } from 'bun:test'
import * as fs from 'node:fs'
import * as cp from 'node:child_process'
const root='/private/tmp/meridian-clear-completion-20261020'
const { snapshotSource }=await import(root+'/src/proxy/buildSnapshot.ts')
const records=[]
for(let index=1;index<=3;index++){
 const spans=[],spies=[];let lastPath
 for(const [namespace,name]of [[fs,'lstatSync'],[fs,'openSync'],[fs,'fstatSync'],[fs,'readSync'],[cp,'spawnSync']]){
  const original=namespace[name]
  spies.push(spyOn(namespace,name).mockImplementation((...args)=>{
   const start=performance.now()
   if(name==='openSync'||name==='lstatSync')lastPath=String(args[0])
   try{return Reflect.apply(original,namespace,args)}finally{
    spans.push({operation:name,ms:performance.now()-start,...(name==='spawnSync'?{command:args[0],args:args[1]}:name==='openSync'||name==='lstatSync'?{path:String(args[0])}:{})})
   }
  }))
 }
 const start=performance.now(),cpu=process.cpuUsage();let result
 try{const v=snapshotSource(root);result={result:'PASS',sha:v.sha,sourceHash:v.sourceHash}}
 catch(error){result={result:'FAIL',name:error.name,reason:error.reason,message:error.message,lastPath}}
 finally{for(const spy of spies.reverse())spy.mockRestore()}
 const usage=process.cpuUsage(cpu)
 records.push({attempt:index,...result,totalMs:performance.now()-start,cpuMs:(usage.user+usage.system)/1000,observedCalls:spans.length,operationMs:Object.fromEntries([...new Set(spans.map(s=>s.operation))].map(op=>[op,spans.filter(s=>s.operation===op).reduce((sum,s)=>sum+s.ms,0)])),slowest:spans.sort((a,b)=>b.ms-a.ms).slice(0,15)})
}
fs.writeFileSync('/tmp/meridian-resume-20261020/1220-current-composition/current-fingerprint-observation.json',JSON.stringify({scope:'Instrumented actual source snapshot with unchanged two-second budget. No source changes, model calls, installs or acceptance from a green rerun; original failed span was not retained.',records},null,2)+'\n')
console.log(JSON.stringify(records.map(({slowest,...r})=>r)))
