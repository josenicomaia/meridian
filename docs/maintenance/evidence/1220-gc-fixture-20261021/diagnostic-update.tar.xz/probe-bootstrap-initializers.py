from pathlib import Path
import subprocess,os,json
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/1220-current-composition');env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
for index in range(1,13):
 log=out/f'bootstrap-observation-{index}.log'
 with log.open('w')as f:p=subprocess.run([bun,'test','--test-name-pattern','two simultaneous initializers','src/__tests__/bookkeeping-review.test.ts'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'attempt':index,'exit':p.returncode,'log':log.name});(out/'bootstrap-observation-results.json').write_text(json.dumps({'scope':'Bounded diagnostic attempts, stop on first reproduced failure. Passing attempts do not explain original discarded stderr.','cases':rows,'models':0},indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if p.returncode:
  print(log.read_text()[-9000:],flush=True);break
