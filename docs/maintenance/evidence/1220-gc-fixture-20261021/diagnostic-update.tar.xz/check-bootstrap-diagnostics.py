from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/1220-current-composition');review=root/'src/__tests__/bookkeeping-review.test.ts';fixture=root/'src/__tests__/fixtures/bookkeeping-bootstrap.ts';fixed=review.read_bytes();original=fixture.read_bytes();before=subprocess.check_output(['git','show','3ea2bf7a884f8ca49881fc1e34d679181e7da915:src/__tests__/bookkeeping-review.test.ts'],cwd=root);sentinel='bootstrap-pipe-evidence-sentinel';fault=original.replace(b'const handle = await',b'if (process.env.BOOTSTRAP_FAILURE_PROBE === "owned-sentinel") throw new Error("bootstrap-pipe-evidence-sentinel")\nconst handle = await');assert fault!=original
env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOTSTRAP_FAILURE_PROBE='owned-sentinel');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
try:
 fixture.write_bytes(fault)
 for label,data in [('before',before),('after',fixed)]:
  review.write_bytes(data);log=out/f'bootstrap-diagnostic-{label}.log'
  with log.open('w')as f:p=subprocess.run([bun,'test','--test-name-pattern','two simultaneous initializers','src/__tests__/bookkeeping-review.test.ts'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  text=log.read_text();rows.append({'case':label,'exit':p.returncode,'originalChildStderrRetained':sentinel in text,'log':log.name});print(json.dumps(rows[-1]),flush=True)
finally:
 review.write_bytes(fixed);fixture.write_bytes(original);assert review.read_bytes()==fixed and fixture.read_bytes()==original
 (out/'bootstrap-diagnostic-control.json').write_text(json.dumps({'scope':'Both cases deliberately fail the original both-success assertion. Only corrected parent retains child stderr and explicitly joins original pipes. This diagnostic is not a fix for the unobserved original initializer failure.','cases':rows,'sourcesRestored':True,'reviewSha256':hashlib.sha256(fixed).hexdigest(),'fixtureSha256':hashlib.sha256(original).hexdigest(),'models':0},indent=2)+'\n')
