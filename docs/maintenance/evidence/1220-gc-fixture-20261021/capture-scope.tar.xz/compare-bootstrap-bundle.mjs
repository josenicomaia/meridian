import {spawnSync} from 'node:child_process'
import {relative,extname} from 'node:path'
import {createHash} from 'node:crypto'
import {writeFileSync} from 'node:fs'
const root='/private/tmp/meridian-clear-completion-20261020'
const git=(...args)=>{const p=spawnSync('git',['-C',root,...args],{encoding:'utf8'});if(p.status!==0)throw new Error(p.stderr);return p.stdout}
const base=git('rev-parse','origin/main').trim(),head=git('rev-parse','HEAD').trim(),loaded=new Map()
const rows=[]
for(const mode of ['main','candidate']){
 const plugins=mode==='main'?[{name:'immutable-main-source',setup(builder){builder.onLoad({filter:/\.(?:ts|js|json)$/},args=>{
  if(!args.path.startsWith(root+'/src/'))return
  const path=relative(root,args.path);const contents=git('show',base+':'+path);loaded.set(path,createHash('sha256').update(contents).digest('hex'))
  return{contents,loader:extname(path)==='.json'?'json':'ts'}
 })}}]:[]
 const build=await Bun.build({entrypoints:[root+'/src/__tests__/fixtures/bookkeeping-bootstrap.ts'],target:'node',external:['libsql'],write:false,plugins})
 if(!build.success)throw new Error(String(build.logs))
 const artifacts=[];for(const item of build.outputs){const b=new Uint8Array(await item.arrayBuffer());artifacts.push({bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')})}
 rows.push({mode,artifacts})
}
const result={base,head,rows,byteIdentical:JSON.stringify(rows[0].artifacts)===JSON.stringify(rows[1].artifacts),mainSourcesObserved:loaded.size,sourceManifest:Object.fromEntries(loaded),scope:'Same pinned compiler, entrypoint, package dependencies and physical paths; main source loaded from immutable Git objects in-memory. No source/worktree/install mutation. Byte equality can bound code scope; it does not explain discarded original child stderr or reproduce its execution environment.'}
writeFileSync('/tmp/meridian-resume-20261020/1220-current-composition/bootstrap-bundle-comparison.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({base,head,rows,byteIdentical:result.byteIdentical,mainSourcesObserved:loaded.size}))
