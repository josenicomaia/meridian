from pathlib import Path
import subprocess, json, hashlib, tarfile, io, re

r = Path('/tmp/meridian-resume-20261020')
s = Path('/private/tmp/meridian-pr1219-migration-20261020')
e = Path('/private/tmp/meridian-1406-evidence-20261020')
out = e / 'docs/maintenance/evidence/1219-migration-20261020'
head = 'f97e6dbf05f82873d5759671a54010b5ad237f46'
base = '413f4b7c73dc25302b877404066767f599ac210e'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=s, text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=s, text=True).strip()
final = json.loads((r / '1219-migration-validation-r2/final-local.json').read_text())
assert final['head'] == head and final['exit'] == 0
package = r / '1219-migration-validation-r2/pack/rynfar-meridian-1.84.0.tgz'
assert hashlib.sha256(package.read_bytes()).hexdigest() == 'dc52da980cd459149cfeb0ae3a691f978055f1299828b15f1d3b18cb0b7c11d3'
for case in ['1219-migration-native-r4', '1219-published-rollback-r2', '1219-linux-storage-r2']:
    result = json.loads((r / case / 'result.json').read_text())
    assert result['source'] == head and result['result'] == 'PASS'
    assert result['allOriginalActorsJoined'] and not result['forbiddenAttempts']
assert json.loads((r / '1219-linux-storage-r2/docker-result.json').read_text())['containerRemoved']
files = {}
directories = [
    '1219-migration-native-r1', '1219-migration-diagnostic',
    '1219-migration-native-r2', '1219-migration-native-r3', '1219-published-rollback-r1',
    '1219-migration-validation', '1219-linux-storage-r1',
    '1219-lock-deadline-control', '1219-migration-validation-r2',
    '1219-migration-native-r4', '1219-published-rollback-r2', '1219-linux-storage-r2',
    '1219-linux-tmpfs-control', '1219-native-binding-options',
]
for directory in directories:
    for p in (r / directory).rglob('*'):
        rel = p.relative_to(r / directory)
        if not p.is_file() or p.is_symlink():
            continue
        if {'node_modules', 'package', 'pack', 'probe'} & set(rel.parts):
            continue
        if p.name == 'official-sqlite-source.txt' or p.suffix not in {'.json', '.mjs', '.py', '.log', '.ts', '.txt', '.md', '.patch', '.cjs'}:
            continue
        files[str(p.relative_to(r))] = p.read_bytes()
for name in [
    '1219-current-main-composition.json', '1219-migration-current-source.json',
    '1219-migration-credit.json', '1219-migration-root-preserved.json',
    '1219-migration-resource-ledger.json',
    '1219-migration-proof-content-check.json',
    '1219-migration-pr-body-before.md', '1219-migration-pr-before.json',
    '1219-migration-push.json',
    'build-1219-migration-proof.py',
]:
    files[name] = (r / name).read_bytes()
for sha, label in [('4cf77705ca7ef7aa9e7f11916efe60d9cfbb1dae', 'fixture-correction'), (head, 'lock-correction')]:
    files[label + '.patch'] = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', sha], cwd=s)
for name in ['scripts/e2e-session-bookkeeping-packaged.mjs', 'scripts/fixtures/bookkeeping-package-server.mjs',
             'scripts/fixtures/bookkeeping-package-legacy-writer.mjs', 'scripts/lib/e2eProcessCustody.mjs']:
    files['committed/' + name] = subprocess.check_output(['git', 'show', head + ':' + name], cwd=s)
log = (r / '1219-migration-validation-r2/final-full.log').read_text()
totals = {k: sum(map(int, re.findall(r'^\s*(\d+) ' + k + r'\s*$', log, re.M))) for k in ['pass', 'skip', 'fail']}
groups = len(re.findall(r'Ran \d+ tests? across', log))
assert totals['fail'] == 0 and groups == 26
summary = {'head': head, 'base': base, 'local': totals, 'isolatedGroups': groups,
           'packageSHA256': 'dc52da980cd459149cfeb0ae3a691f978055f1299828b15f1d3b18cb0b7c11d3',
           'models': 0, 'scope': 'Packaged storage/operator acceptance only; actual model/client/native-engine gates remain open'}
files['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
files['manifest.sha256.json'] = (json.dumps({n: hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())}, indent=2) + '\n').encode()
out.mkdir(exist_ok=False)
archive = out / 'proof.tar.xz'
with tarfile.open(archive, 'w:xz', preset=9) as t:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        t.addfile(info, io.BytesIO(data))
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
receipt = {'head': head, 'sha256': sha, 'bytes': archive.stat().st_size, 'files': len(files), 'summary': summary}
(out / 'manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
(r / '1219-migration-proof-prepared.json').write_text(json.dumps(receipt, indent=2) + '\n')
(out / 'README.md').write_text(f'''# Bookkeeping migration and fixture recovery proof

Original PR [#1219](https://github.com/rynfar/meridian/pull/1219) remains **held for whole-PR acceptance**. This batch preserves original source `5da7b6b40e2b2871c0f50313f59dc09e4c13806d`, adds current main `{base}` without rewriting any contributor object, and adds separate signed fixture correction `4cf77705ca7ef7aa9e7f11916efe60d9cfbb1dae` and lock correction `{head}`. No default backend, public interface, native dependency, release, or model account changed.

The original isolated package gate reached the migration/export/rollback operations but failed a health assertion: both unchanged JSON and SQLite return 503 without authentication, and 200 with an explicit nonsecret fixture API profile. Actual pinned native CLI metadata-only authentication controls confirm the cause. The committed server fixture now supplies this profile. It observes and joins original child exit/close and both captured pipe closures before removing temporary installs and state. Ambiguous original recorder state remains unqualified; it is not rewritten as success.

The first final full suite failed with a 100 ms lifecycle maintenance lock timeout after a PREPARED-phase SIGKILL. A deterministic regression delays a real recovery directory sync by 150 ms: unchanged source retires the dead lock then throws before trying the free lock. The fix attempts the same initialized candidate's exclusive hard link immediately after recovery, before another wait/deadline decision. The 100 ms budget is unchanged. Successor and cancellation controls pass, and 261 adjacent tests pass. The original full failure lacked an individual fsync trace: this proves the matching real failure mechanism without inventing an exact historical duration.

Exact final local verification: **{totals['pass']} pass, {totals['skip']} skip, 0 fail, all {groups} isolated groups**, standalone typecheck/build and pack pass. Full logs, original failure, exact regressions and signed correction diffs are archived. Final-head hosted CI is recorded separately; a local pass does not waive it.

Exact independently installed package SHA256 `dc52da980cd459149cfeb0ae3a691f978055f1299828b15f1d3b18cb0b7c11d3` passes the committed storage gate on stock Node22.22.3/macOS arm64 and Node24.20.0/Linux arm64, each against unchanged current main. A separate Mac run passes rollback against the current published npm1.84.0 tarball after freshly verifying its registry integrity. Each run covers migration, two HTTP processes sharing one directory, restart, export and baseline reads, old writer fencing, malformed refusal, same-process instances, retirement/residue and bootstrap crash recovery. All original actors/pipes join; forbidden model operations are 0; old model-hold hash is unchanged. This is storage/operator evidence, **not live SDK/model/client acceptance**.

The original Linux temporary mount was noexec and could not map the native module. The same official libsql native file fails on noexec and loads on exec, with actual mount flags captured. The corrected container uses an executable disposable tmpfs, valid machine ID, original native CLI and no application-guard bypass. It passes and is removed. The harness removes its joined installs/fixtures.

The libsql0.5.29 / SQLite3.45.1 native WAL provenance and topology gate remains open. A read-only alternative audit verifies official better-sqlite3 13.0.3 tar integrity and bundled SQLite3.53.4; a stock Node22 native probe passes. Pinned Bun1.3.11 panics at the first constructor before SQL, and its embedded SQLite reports3.51.0. No replacement is adopted and no corruption reproduction is claimed. See [SQLite's primary advisory](https://sqlite.org/wal.html) and the [official alternative release](https://github.com/WiseLibs/better-sqlite3/releases/tag/v13.0.3). Actual affected client/model/platform and remaining long-run/native gates are still required before merge. No new model calls were made in this batch.

Archive SHA256 `{sha}`, {archive.stat().st_size} bytes, {len(files)} regular files. Verify its internal manifest. The exact committed harness is `scripts/e2e-session-bookkeeping-packaged.mjs`; run it with `--package candidate.tgz --baseline-package baseline.tgz` in fresh owned state. Supplemental controllers pin local runtime/package paths and sealed attempt markers; inspect and supply new deliberate paths rather than rerunning completed attempts. Native binaries and dependency trees are excluded; package identities and official provenance permit reconstruction. The previous 63,145-character PR body is preserved byte-for-byte in the archive so the current body can describe the final state without losing earlier proof.
''')
print(json.dumps(receipt, indent=2))
