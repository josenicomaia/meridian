import cp from 'node:child_process'
import {syncBuiltinESMExports}from'node:module'
import{promisify}from'node:util'
import {writeFileSync,mkdirSync}from'node:fs'
import {join,basename}from'node:path'
import {pathToFileURL}from'node:url'
import {observeChildClosure,stopAndJoinChild}from'./harness/scripts/lib/e2eProcessCustody.mjs'
const root=process.env.E2E_CUSTODY_ROOT
if(!root)throw Error('Owned custody output root required')
mkdirSync(root,{recursive:true})
const output=join(root,'actor-'+process.pid+'.json'),actors=[],entries=[],report={pid:process.pid,parent:process.ppid,scope:'Stock Node storage-only package gate; no model, no owner Keychain',spawns:entries,actors:[],http:[],forbidden:[],joined:false}
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n',{mode:0o600})
function guard(method,command,args=[]){
 const name=basename(String(command)),native=/claude(?:\.exe)?$|claude-[0-9]|\/claude-agent-sdk\/cli\./.test(String(command)+' '+args.join(' '))
 const denied=name==='security'||(native&&!args.includes('--version'))
 entries.push({method,command:String(command),args,pid:null});if(denied){report.forbidden.push({method,command:String(command),reason:'No owner credential command or native inference allowed'});save();throw Error('Storage gate refused owner Keychain/native inference')}
 save();return entries.at(-1)
}
for(const method of ['fork','spawn','execFile','spawnSync','execFileSync']){
 const original=cp[method]
 const wrapper=function(command,...rest){
  const args=Array.isArray(rest[0])?rest[0]:[];const row=guard(method,command,args)
  if(method==='fork'){
   const i=Array.isArray(rest[0])?1:0,options=rest[i]??{}
   rest[i]={...options,env:{...(options.env??process.env),NODE_OPTIONS:'--import '+new URL(import.meta.url).pathname,E2E_CUSTODY_ROOT:root}}
  }
  const child=Reflect.apply(original,this,[command,...rest]);row.pid=child?.pid??null
  if(child?.once){
   const witness=observeChildClosure(child);actors.push({child,witness});child.stdout?.resume();child.stderr?.resume();child.once('close',()=>save())
  }else{row.status=child?.status??null;row.signal=child?.signal??null;row.synchronousCompleted=true}
  save();return child
 }
 for(const symbol of Object.getOwnPropertySymbols(original))Object.defineProperty(wrapper,symbol,Object.getOwnPropertyDescriptor(original,symbol))
 cp[method]=wrapper
}
syncBuiltinESMExports()
const originalFetch=globalThis.fetch
globalThis.fetch=async(input,options)=>{
 const url=new URL(typeof input==='string'?input:input.url??String(input));report.http.push({origin:url.origin,path:url.pathname});save()
 if(!['127.0.0.1','localhost','::1','[::1]'].includes(url.hostname)){report.forbidden.push({origin:url.origin,reason:'Foreign HTTP forbidden in storage-only gate'});save();throw Error('Storage gate refused foreign HTTP')}
 return originalFetch(input,options)
}
let finished=false
process.on('beforeExit',async()=>{
 if(finished)return
 finished=true
 for(const{child,witness}of actors)report.actors.push({pid:child.pid,...await stopAndJoinChild(child,witness,{graceMs:3000,forceMs:3000})})
 report.joined=report.actors.every(row=>row.joined);save();if(!report.joined||report.forbidden.length)process.exitCode=1
})
process.on('exit',()=>{report.actors=actors.map(({child,witness})=>({pid:child.pid,...witness.state}));report.joined=report.actors.every(row=>row.joined);report.exitObserved=true;save()})
save()
