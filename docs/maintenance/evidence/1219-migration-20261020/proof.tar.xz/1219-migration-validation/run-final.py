from pathlib import Path
import subprocess,json,os,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1219-migration-validation';source=Path('/private/tmp/meridian-pr1219-migration-20261020');head=json.loads((r/'1219-migration-current-source.json').read_text())['head'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();record={'head':head,'base':'413f4b7c73dc25302b877404066767f599ac210e','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'exit':None};env=dict(os.environ,PATH='/tmp/meridian-1399-tooling/node_modules/.bin:'+os.environ['PATH'])
for label,args in [('typecheck',['npm','run','typecheck']),('build',['npm','run','build']),('full',['npm','test'])]:
 (out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n')
 with(out/('final-'+label+'.log')).open('w')as log:code=subprocess.run(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 record['commands'].append({'label':label,'exit':code});(out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n');print(label,code,flush=True)
 if code:record['exit']=code;break
else:record['exit']=0
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'final-local.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['exit'])
