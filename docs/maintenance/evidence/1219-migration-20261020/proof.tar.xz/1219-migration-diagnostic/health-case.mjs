import cp from'node:child_process'
import{syncBuiltinESMExports}from'node:module'
import{promisify}from'node:util'
import{mkdtempSync,mkdirSync,rmSync,writeFileSync}from'node:fs'
import{join}from'node:path'
import{pathToFileURL}from'node:url'
import{observeChildClosure,stopAndJoinChild}from'../1219-migration-native-r1/harness/scripts/lib/e2eProcessCustody.mjs'
const [mode,profile]=process.argv.slice(2),root=mkdtempSync('/tmp/meridian-bookkeeping-health-'),actors=[],result={mode,profile,scope:'Unchanged candidate package + same dependency versions, diagnostic only; no model calls',commands:[]}
for(const name of['home','claude','config'])mkdirSync(join(root,name),{mode:0o700})
for(const name of Object.keys(process.env))if(/^(MERIDIAN_|CLAUDE_|ANTHROPIC_)/.test(name))delete process.env[name]
Object.assign(process.env,{HOME:join(root,'home'),CLAUDE_CONFIG_DIR:join(root,'claude'),MERIDIAN_CONFIG_DIR:join(root,'config'),MERIDIAN_SESSION_DIR:join(root,'sessions'),MERIDIAN_BOOKKEEPING:mode,MERIDIAN_SESSION_GC_INTERVAL_MS:'0',MERIDIAN_CREDENTIALS_READONLY:'1',MERIDIAN_NO_UPDATE_CHECK:'1'})
const original=cp.execFile
function observed(child,command,args){if(!child)throw Error('Original child required');actors.push({child,witness:observeChildClosure(child)});result.commands.push({pid:child.pid,command,args});return child}
function check(command,args,options){if(!args.includes('--version')&&!(args[0]==='auth'&&args[1]==='status'))throw Error('No non-metadata CLI command allowed');const env=options?.env??process.env;if(!String(env.CLAUDE_CONFIG_DIR).startsWith(root+'/'))throw Error('Auth metadata must use own empty namespace')}
const wrapper=function(command,args,options,callback){check(command,args,options);return observed(original.call(this,command,args,options,callback),command,args)}
Object.defineProperty(wrapper,promisify.custom,{value:function(command,args,options){check(command,args,options);const promise=original[promisify.custom].call(this,command,args,options);observed(promise.child,command,args);return promise}})
cp.execFile=wrapper;syncBuiltinESMExports()
let proxy
try{
 const api=await import(pathToFileURL(new URL('./package/dist/server.js',import.meta.url).pathname));const profiles=profile==='api'?[{id:'bookkeeping-fixture',type:'api',apiKey:'bookkeeping-fixture-key',baseUrl:'http://127.0.0.1:1'}]:undefined
 proxy=await api.startProxyServer({port:0,host:'127.0.0.1',silent:true,profiles,defaultProfile:profiles?.[0].id});if(!proxy.server.address())await new Promise(r=>proxy.server.once('listening',r));const response=await fetch('http://127.0.0.1:'+proxy.server.address().port+'/health',{signal:AbortSignal.timeout(10000)});const body=await response.json();result.health={http:response.status,status:body.status,error:body.error,auth:body.auth?{loggedIn:body.auth.loggedIn}:null,build:body.build?{status:body.build.status,source:body.build.source}:null}
}catch(error){result.error={name:error.name,message:error.message}}
finally{
 if(proxy)try{await proxy.close()}catch(error){result.closeError={name:error.name,message:error.message}}
 result.childrenJoinedAtClose=actors.every(x=>x.witness.state.joined);result.children=[]
 for(const{child,witness}of actors)result.children.push({pid:child.pid,...await stopAndJoinChild(child,witness,{graceMs:3000,forceMs:3000})})
 result.joined=result.children.every(x=>x.joined);if(result.joined)rmSync(root,{recursive:true,force:true});result.fixtureRemoved=result.joined;writeFileSync(new URL('./health-'+mode+'-'+profile+'.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
}
