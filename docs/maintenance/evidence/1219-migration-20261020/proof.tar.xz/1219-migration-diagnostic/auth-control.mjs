import cp from'node:child_process'
import{mkdtempSync,mkdirSync,writeFileSync,rmSync}from'node:fs'
import{join}from'node:path'
import{observeChildClosure,stopAndJoinChild}from'../1219-migration-native-r1/harness/scripts/lib/e2eProcessCustody.mjs'
const result={scope:'Actual pinned native CLI, isolated empty auth config versus explicit nonsecret fixture API key; auth status only, zero model commands',cases:[]}
for(const kind of['empty','api']){
 const root=mkdtempSync('/tmp/meridian-bookkeeping-auth-');mkdirSync(join(root,'config'),{mode:0o700})
 const env={PATH:process.env.PATH,HOME:root,CLAUDE_CONFIG_DIR:join(root,'config'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1'}
 if(kind==='api'){env.ANTHROPIC_API_KEY='bookkeeping-fixture-key';env.ANTHROPIC_BASE_URL='http://127.0.0.1:1'}
 const child=cp.spawn('/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302',['auth','status'],{env,stdio:['ignore','pipe','pipe']});const witness=observeChildClosure(child);let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);const timer=setTimeout(()=>child.kill('SIGTERM'),10000);await witness.joined;clearTimeout(timer);const state=await stopAndJoinChild(child,witness);let auth
 try{const parsed=JSON.parse(stdout);auth={loggedIn:parsed.loggedIn,authMethod:parsed.authMethod,apiKeySource:parsed.apiKeySource}}catch(error){auth={parseFailure:error.name,stdoutBytes:stdout.length,stderrBytes:stderr.length}}
 result.cases.push({kind,pid:child.pid,exit:child.exitCode,auth,...state});rmSync(root,{recursive:true,force:true})
}
writeFileSync('/tmp/meridian-resume-20261020/1219-migration-diagnostic/auth-control.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
