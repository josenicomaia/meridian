import os,json,subprocess,hashlib,datetime,socket,shutil,re
from pathlib import Path
r=Path('/tmp/meridian-resume-20261020');out=r/'1401-live';qualified=out/'qualified';stage=out/'final-packages-r3';source='/private/tmp/meridian-pr1401-r2-20261019';package=str(stage/'candidate-mac/node_modules/@rynfar/meridian');head='f923e9df3cf0c54a11f9a9df86ed5d95af5791a6';bun='/tmp/meridian-1399-tooling/node_modules/.bin/bun';native='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302';harness=Path(source)/'scripts/e2e-profile-history-client.mjs';grant=r/'private/1401-grant.json';guard=r/'private/1401-admission.json';attempt=out/'REAL_MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json';hold_hash=hashlib.sha256(hold.read_bytes()).hexdigest();record={'task':'1401-profile-history-haiku55','head':head,'cases':[],'result':'RUNNING'}
assert not attempt.exists() and not grant.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
local=json.loads((r/'1401-final-f923-local-exit.json').read_text());assert local['head']==head and all(any(row['label']==label and row['exit']==0 for row in local['commands']) for label in ['typecheck','build'])
priorLocal=json.loads((r/'1401-post1406-final-local-exit.json').read_text());assert priorLocal['final'] and priorLocal['exit']==0
assert not subprocess.check_output(['git','diff','--name-only','71ab157fd73099de627fc8ecccc2940e803cc26e..'+head,'--','src/proxy','src/telemetry','bin','plugin','package.json','package-lock.json'],cwd=source,text=True).strip(),'Application changed after qualified source gate'
assert json.loads((r/'1401-ci-receipt-final/report.json').read_text())['result']=='PASS'
ci=json.loads(subprocess.check_output(['gh','pr','view','1401','--repo','rynfar/meridian','--json','headRefOid,statusCheckRollup']));assert ci['headRefOid']==head;record['ciAtLiveStart']=ci;record['mergeGate']='Final-head local full and CI must pass before merge. Live verification runs independently while those checks finish; no gate is waived.'
packages=json.loads((stage/'summary.json').read_text());assert packages['result']=='PASS_PACKAGES_READY' and packages['heads']['candidate']==head
identity=json.loads((stage/'candidate-mac-identity.json').read_text());assert identity['head']==head and identity['@anthropic-ai/claude-agent-sdk']=='0.2.141' and hashlib.sha256(Path(identity['tarball']).read_bytes()).hexdigest()==identity['sha256']
preflight=json.loads((out/'post1406-unified-offline-r3/summary.json').read_text());assert preflight['result']=='PASS' and len(preflight['cases'])==6 and preflight['sourceSHA256']==hashlib.sha256(harness.read_bytes()).hexdigest()
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [harness,harness.parent/'lib/profileHistoryAdmission.mjs',*qualified.glob('*.mjs')]}
common={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','TERM','TMPDIR')};common.update(E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard),E2E_PLUGIN_PATH=str(r/'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_NATIVE_BIN=native,E2E_EXPECT_MODEL='claude-haiku-5-5',E2E_MODEL='claude-haiku-5-5')
def save():(out/'first-live-task.json').write_text(json.dumps(record,indent=2)+'\n')
def preserved():
    assert hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash,'Older failed-case holds changed'
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items()),'Executed source changed'
def run_case(name,command,env,check):
    assert len(record['cases'])<20;target=out/name;target.mkdir()
    for directory in ['home','native-config','proxy']:(target/directory).mkdir()
    row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['cases'].append(row);save()
    with (target/'run.log').open('w') as log:p=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
    row.update(exit=p.returncode,**check(target));save();print(json.dumps(row),flush=True);preserved();assert p.returncode==0 and row['qualified'],'Retain actual failure; stop dependent work'
try:
    subprocess.run([bun,str(qualified/'create-profile-history-grant.mjs')],cwd=source,env=dict(os.environ,E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1'),check=True)
    admission=json.loads(guard.read_text());assert admission['includedCapacityKnown'] is False and admission['includedAttemptPermitted'] and admission['profileExtraUsageEnabled'] is False and admission['maximumCases']==20
    attempt.write_text(json.dumps({'task':record['task'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'state':'First actual1401 task; no unexplained rerun or older hold cleared','scripts':seal,'admission':admission},indent=2)+'\n')
    for flow,label in [('keyed','baseline'),('keyed','candidate'),('rewind','baseline'),('rewind','candidate'),('pi','baseline'),('pi','candidate')]:
        assert len(record['cases'])<20;name='e85-'+flow+'-'+label+'-live-r1';target=out/name;target.mkdir();artifact=stage/(label+'-linux');container='meridian-1401-'+flow+'-'+label+'-r1';cidfile=target/'container-id';caseguard=target/'admission.json';derived=dict(admission,maximumGenerationsPerCase=12,maximumCases=1,case=name,parentTask=record['task']);caseguard.write_text(json.dumps(derived,indent=2)+'\n');caseguard.chmod(0o600)
        row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'container':container,'originalObservationAt':admission['at']};record['cases'].append(row);save()
        args=['docker','run','--rm','--name',container,'--cidfile',str(cidfile),'--platform','linux/arm64','-v',source+':/harness:ro','-v',str(artifact)+':/artifact:ro','-v','/tmp/meridian-issue-r2-evidence/linux-runtime:/runtime:ro','-v',str(r/'opencode2031-tooling')+':/client:ro','-v',str(r/'pi-linux-client')+':/pi:ro','-v',str(target)+':/evidence','-v',str(grant)+':/grant.json:ro','-v',str(caseguard)+':/guard.json:ro']
        settings={'E2E_MERIDIAN_ROOT':'/artifact/node_modules/@rynfar/meridian','E2E_OPENCODE_BIN':'/client/opencode','E2E_NATIVE_BIN':'/runtime/node_modules/@anthropic-ai/claude-code-linux-arm64/claude','E2E_NATIVE_VERSION':'2.1.301','E2E_OPENCODE_VERSION':'2.0.31','E2E_PLUGIN_PATH':'/runtime/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js','E2E_SCRUB_VERSION':'0.2.3','E2E_EVIDENCE_DIR':'/evidence','E2E_PI_PACKAGE':'/pi/node_modules/@earendil-works/pi-coding-agent','E2E_EXPECT':label,'E2E_ALLOW_LIVE_MODEL':'1','E2E_LIVE_PROFILE_FILE':'/grant.json','E2E_USAGE_GUARD_FILE':'/guard.json'}
        for key,value in settings.items():args+=['-e',key+'='+value]
        flags=['--live']+(['--rewind'] if flow=='rewind' else ['--pi'] if flow=='pi' else [])
        bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));const p=require('node:child_process').spawnSync(process.execPath,['/harness/scripts/e2e-profile-history-client.mjs',..."+json.dumps(flags)+"],{env:process.env,stdio:'inherit'});if(p.error)throw p.error;process.exit(p.status??1)"
        args+=['node:24.20.0-bookworm','node','-e',bootstrap]
        try:
            with (target/'run.log').open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=300)
            case=json.loads((target/'report.json').read_text()) if (target/'report.json').exists() else {};expected='EXPECTED_BASELINE_FAILURE' if flow!='rewind' and label=='baseline' else 'PASS';row.update(exit=p.returncode,result=case.get('result'),failure=case.get('failure'),generations=len(case.get('provider',[])),qualified=p.returncode==0 and case.get('result')==expected and case.get('joined') and case.get('providerNativeStoredCorrelated') and case.get('usageGuard',{}).get('includedCapacityKnown') is False)
        except subprocess.TimeoutExpired:
            row.update(exit='timeout',qualified=False,cleanupUnknown=True)
            if cidfile.exists():
                cid=cidfile.read_text().strip();assert re.fullmatch('[a-f0-9]{64}',cid);stopped=subprocess.run(['docker','stop','--time','10',cid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);row['ownedContainerStopExit']=stopped.returncode
        save();print(json.dumps(row),flush=True);preserved();assert row['qualified'],'Retain actual failure; no blind retry'
    for mode in ['chain-json', 'chain-stream', 'parallel-json', 'parallel-stream']:
        name = 'e41-' + mode + '-r1'
        target = out / name
        port_socket = socket.socket(); port_socket.bind(('127.0.0.1', 0)); port = port_socket.getsockname()[1]; port_socket.close()
        env = dict(common, HOME=str(target / 'home'), CLAUDE_CONFIG_DIR=str(target / 'native-config'),
                   MERIDIAN_CLAUDE_PATH=native, MERIDIAN_CREDENTIALS_READONLY='1', MERIDIAN_NO_UPDATE_CHECK='1',
                   E2E_MERIDIAN_ROOT=source, E2E_MODEL_WITNESS=str(target / 'model-witness.json'),
                   E2E_CLIENT_PLUGIN_PATH=source + '/dist/meridian/index.js', E2E_CLIENT_VERSION='1.84.0',
                   PROBE_MODEL='claude-haiku-5-5', PROBE_PARALLEL='1' if mode.startswith('parallel') else '0', PROBE_TURNS='6', PROBE_PORT=str(port))
        # The protocol fixture creates these paths after its output root exists.
        command = [bun, str(qualified / 'run-e41.mjs')] + (['--stream'] if mode.endswith('stream') else [])
        def e41(target):
            lines = (target / 'run.log').read_text().splitlines()
            result = next((json.loads(line) for line in reversed(lines) if line.startswith('{"root":')), None)
            if result:
                shutil.copy2(Path(result['root']) / 'qualified-e41-report.json', target / 'report.json')
            witness = json.loads((target / 'model-witness.json').read_text()) if (target / 'model-witness.json').exists() else {}
            return {'result': result, 'generations': witness.get('generationCount'),
                    'qualified': bool(result and result.get('result') == 'PASS' and result.get('joined') and not witness.get('stopped'))}
        run_case(name, command, env, e41)

    cases = [('beta', version, mode) for version in ['18314', '18866', '19271'] for mode in [True, False]]
    cases += [('stable', version, mode) for version, mode in [('2.0.31', True), ('2.0.31', False), ('2.0.16', False), ('2.0.21', False)]]
    for kind, version, source_mode in cases:
        name = 'e42-' + kind + '-' + version + ('-source-r1' if source_mode else '-installed-r1')
        target = out / name
        root = source if source_mode else package
        binary = r / (f'opencode-beta-{version}/node_modules/@opencode-ai/cli-darwin-arm64/bin/opencode2' if kind == 'beta'
                      else f'opencode-stable-{version}/node_modules/@opencode/cli-darwin-arm64/bin/opencode')
        env = dict(common, HOME=str(target / 'home'), E2E_MERIDIAN_ROOT=root, E2E_OPENCODE_BIN=str(binary),
                   E2E_PROXY_REPORT_DIR=str(target / 'proxy'), E2E_OPENCODE_VERSION=version)
        command = [bun, str(qualified / (kind + '-gate.mjs'))]
        if kind == 'beta': command += ['--live', '--extended', '--separate-proxy-cwd'] + (['--source'] if source_mode else [])
        def e42(target, kind=kind):
            workers = [json.loads(path.read_text()) for path in (target / 'proxy').glob('proxy-*.json')]
            models = [json.loads(path.read_text()) for path in (target / 'proxy').glob('models-*.json')]
            return {'workers': [{'result': row.get('result'), 'failure': row.get('failure'), 'joined': row.get('joined'),
                                  'correlated': row.get('providerNativeStoredCorrelated')} for row in workers],
                    'generations': sum(row.get('generationCount', 0) for row in models),
                    'qualified': len(workers) == (2 if kind == 'beta' else 1) and all(row.get('result') == 'PASS' and row.get('joined')
                       and row.get('providerNativeStoredCorrelated') for row in workers) and all(not row.get('stopped') and row.get('scripted') is False and row.get('realForwards',0)>=row.get('generationCount',0)>0 and row.get('generationCount',0)<=32 for row in models)}
        run_case(name, command, env, e42)
    record['result']='PASS'
finally:
    grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['holdsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==hold_hash
    if record['result']!='PASS':record['result']='FAIL'
    save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'holdsUnchanged':record['holdsUnchanged']}),flush=True)
