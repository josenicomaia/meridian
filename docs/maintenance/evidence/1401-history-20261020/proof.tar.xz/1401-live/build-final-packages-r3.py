import pathlib,subprocess,os,json,hashlib
r=pathlib.Path('/tmp/meridian-resume-20261020');out=r/'1401-live';stage=out/'final-packages-r3';stage.mkdir()
local=json.loads((r/'1401-final-f923-local-exit.json').read_text());assert any(c['label']=='build' and c['exit']==0 for c in local['commands'])
source=pathlib.Path('/private/tmp/meridian-pr1401-r2-20261019');baseline=pathlib.Path('/private/tmp/meridian-main-1401-post1406-20261020')
heads={'candidate':'f923e9df3cf0c54a11f9a9df86ed5d95af5791a6','baseline':'e57dd9c3b795bbf0340c78b6f377799e5b8e0136'}
env=dict(os.environ);env['PATH']='/tmp/meridian-1399-tooling/node_modules/.bin:'+env['PATH']
report={'scope':'actual Linux OpenCode/SDK/native, scripted upstream only; profile-alias preparation, zero real generations','heads':heads,'commands':[],'cases':[],'result':'RUNNING'}
def save():(stage/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,cwd=source,timeout=300):
 with (stage/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 report['commands'].append({'label':label,'exit':p.returncode});save();print(label,p.returncode,flush=True);assert p.returncode==0,label
try:
 for label,path in [('candidate',source),('baseline',baseline)]:
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==heads[label]
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).strip()
 for label,path in [('baseline',baseline),('candidate',source)]:
  if label=='baseline':run(label+'-build',['npm','run','build'],path)
  pack=stage/(label+'-pack');pack.mkdir();run(label+'-pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(pack)],path)
  tarball=next(pack.glob('*.tgz'));report[label+'Package']={'head':heads[label],'sha256':hashlib.sha256(tarball.read_bytes()).hexdigest()};save()
  artifact=stage/(label+'-linux');artifact.mkdir();(artifact/'package.json').write_text('{"private":true,"type":"module"}\n')
  args=['docker','run','--rm','--platform','linux/arm64','-v',str(pack)+':/package:ro','-v',str(artifact)+':/artifact','-v',str(r/'npm-cache')+':/npm-cache','-w','/artifact','node:24.20.0-bookworm','npm','install','--ignore-scripts','--no-audit','--no-fund','--cache','/npm-cache','/package/'+tarball.name]
  run(label+'-linux-install',args,timeout=300)
  for name in ['@anthropic-ai/claude-agent-sdk','libsql']:
   version=json.loads((artifact/'node_modules'/name/'package.json').read_text())['version'];assert version==('0.2.141' if name.startswith('@anthropic') else '0.5.29')
 report['result']='PASS_PACKAGES_READY'
finally:
 if report['result']!='PASS_PACKAGES_READY':report['result']='FAIL'
 save();print(__import__('json').dumps({'result':report['result'],'heads':heads}),flush=True)
