import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,existsSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'
import {observeChildClosure,stopAndJoinChild} from '/private/tmp/meridian-pr1401-r2-20261019/scripts/lib/e2eProcessCustody.mjs'
const [label,output]=process.argv.slice(2);assert(label&&output);mkdirSync(output)
const root=mkdtempSync(join(tmpdir(),'meridian-receipt-control-')),fixture='/private/tmp/meridian-pr1401-r2-20261019/src/__tests__/fixtures/chatgpt-lease-process.ts'
const worker=join(root,'worker.mjs'),code=[
"import * as fs from 'node:fs'", "import {mock} from 'bun:test'", "const raw={...fs},root="+JSON.stringify(root)+";let paused=false",
"mock.module('node:fs',()=>({...raw,writeFileSync(path,data,...opts){if(!paused&&String(path).includes('writer.validated')){paused=true;const fd=raw.openSync(path,'w');raw.writeFileSync(root+'/receipt-opened','opened');while(!raw.existsSync(root+'/receipt-resume'))Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10);try{return raw.writeFileSync(fd,data,...opts)}finally{raw.closeSync(fd)}}return raw.writeFileSync(path,data,...opts)}}))",
"process.argv=[process.execPath,"+JSON.stringify(fixture)+",'attempt',root,'writer'];await import("+JSON.stringify(pathToFileURL(fixture).href)+")"
].join('\n').replaceAll('\\n','\n')
writeFileSync(worker,code)
const child=spawn('/tmp/meridian-1399-tooling/node_modules/.bin/bun',[worker],{stdio:['ignore','pipe','pipe']}),witness=observeChildClosure(child);let stderr='';child.stdout.resume();child.stderr.on('data',b=>{stderr=(stderr+b).slice(-8192)})
async function waitFile(name){const path=join(root,name),deadline=Date.now()+20000;while(!existsSync(path)){if(Date.now()>deadline)throw Error('Owned fixture did not publish '+name);await new Promise(resolve=>setTimeout(resolve,10))}return readFileSync(path,'utf8')}
const report={label,realModels:0,source:fixture};let release
try{assert.equal(await waitFile('writer.result'),'admitted');writeFileSync(join(root,'writer.validate'),'validate');assert.equal(await waitFile('receipt-opened'),'opened');release=setTimeout(()=>writeFileSync(join(root,'receipt-resume'),'resume'),100);report.received=await waitFile('writer.validated');assert.equal(report.received,'still-valid');report.result='PASS'}catch(error){report.result='FAIL';report.failure=String(error)}finally{clearTimeout(release);writeFileSync(join(root,'receipt-resume'),'resume');report.child=await stopAndJoinChild(child,witness,{graceMs:3000,forceMs:1000});report.joined=report.child.joined;report.stderr=stderr;if(!report.joined)report.result='FAIL';writeFileSync(join(output,'report.json'),JSON.stringify(report,null,2)+'\n');if(report.joined)rmSync(root,{recursive:true,force:true});console.log(JSON.stringify(report));process.exitCode=report.result==='PASS'?0:1}
