Synchronous store write/fsync waits can freeze every proxy request during a mapping update. Perform the same durability sequence through `fs/promises` while holding the existing cross-process lock: write the temporary file, sync it, rename it over the store, then sync the directory. JSON serialization still costs CPU; this does not replace the store format.

Mutations within one process run in call order. Request publication and cancellation writes retain their ordering; an arrival snapshot waits for already-started writes, and stream cancellation completes its durable eviction before releasing the session. Store mutators and exported `clearSessionCache()` now return promises, within the existing #1244 approval.

The maintainer corrections own mutable history/options/locators before queue or disk yields, recheck request/shutdown authority after awaited write/fsync/close and immediately before dispatching rename, and prevent older cache completions from repopulating memory across clear. Later writes still publish. Both ordinary and recovery attachment/publication paths carry the guard. A cancellation cannot recall an already-dispatched filesystem rename. The local read-error fallback owns the same UUID/context/locator snapshot as the durable store.

Validation at `b1fffe4ac8118f52fec9d74555cae45f31332fb7`, based on main `6c241a897`:

- Five original-implementation regressions reproduce mutable-input publication, request/shutdown publication during a held real FileHandle fsync, and stale cache revival across clear. Two further intermediate-correction regressions expose local-fallback input aliasing. Passing later-write controls retain correct ordering.
- All **29 affected-file tests** and **59 adjacent priority/store/prune tests** pass. Seven newer test hooks now await async cleanup; benchmark thresholds are unchanged.
- Complete `npm test`: **6,997 pass / 36 skip / 0 fail**, all 24 isolated invocations on Bun **1.3.11+af24e281e**. Standalone typecheck/build and all final-head CI checks, including `test`, pass.
- [Durable drivers, red/green evidence, provenance and gate receipts](https://github.com/rynfar/meridian/pull/1421). No paid model calls were used for these corrections.

**Acceptance remains held:** the original unexplained residual 200-token E41 cache-prefix reduction and actual affected-client/model/SDK/platform proof remain pre-merge gates. These tests do not establish that old live discrepancy fixed. No SQLite behavior, issue closure or release is claimed.

The original Nowaker contribution remains unchanged on its own PR; additive signed maintainer corrections and main integration preserve it. A future squash must retain Nowaker as Git Author with maintainer coauthor credit for the substantive corrections.


### Approved cleanup contract follow-up (2026-10-20)

After #1219 merged, a final API audit found #1244/#1277 item6 still exposed `clearSessionCache(): void`. Focused maintainer [#1433](https://github.com/rynfar/meridian/pull/1433) independently corrects the approved completion contract on current main: immediate memory reset, Promise completion and existing SQL writer ordering. It carries no contributor commits and does not land this PR's broader asynchronous JSON writer. This idea/contract was proposed with this contribution; the separate cache-prefix evidence hold and final-head gates recorded here remain. #1277 was reopened after premature closure and stays open until validated delivery.
