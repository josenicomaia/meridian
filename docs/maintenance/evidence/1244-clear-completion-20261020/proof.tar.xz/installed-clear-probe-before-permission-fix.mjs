import assert from 'node:assert/strict'
import {mkdtempSync,mkdirSync,rmSync,writeFileSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'
import {spawn} from 'node:child_process'
import {once} from 'node:events'
import {setTimeout as delay} from 'node:timers/promises'
const [packageRoot,mode,reportPath]=process.argv.slice(2)
assert(['json','sqlite'].includes(mode))
const root=mkdtempSync(join(tmpdir(),'meridian-clear-installed-'))
for(const key of Object.keys(process.env))if(/^(MERIDIAN_|CLAUDE_PROXY_|ANTHROPIC_|CLAUDE_)/.test(key))delete process.env[key]
for(const p of ['home','config','sessions'])mkdirSync(join(root,p))
Object.assign(process.env,{HOME:join(root,'home'),MERIDIAN_CONFIG_DIR:join(root,'config'),MERIDIAN_SESSION_DIR:join(root,'sessions'),MERIDIAN_BOOKKEEPING:mode,MERIDIAN_TELEMETRY_PERSIST:'0',MERIDIAN_NO_UPDATE_CHECK:'1'})
const report={mode,models:0,node:process.version,platform:process.platform,arch:process.arch,result:'RUNNING',root}
let handle,child,closed,first,second,closePromise
try{
 const api=await import(pathToFileURL(join(packageRoot,'dist/server.js')).href)
 handle=await api.initializeProxyBookkeeping()
 assert.equal(handle!==undefined,mode==='sqlite')
 if(handle)assert.deepEqual(Object.keys(handle),['close'])
 const initial=api.clearSessionCache();assert(initial instanceof Promise);await initial
 if(mode==='sqlite'){
  child=spawn(process.execPath,['--input-type=module','-e',`import{DatabaseSync}from'node:sqlite';const db=new DatabaseSync(process.argv[1]);db.exec('BEGIN IMMEDIATE');process.send('locked');process.on('message',()=>{db.exec('ROLLBACK');db.close();process.disconnect()});`,join(root,'sessions/session-bookkeeping.sqlite')],{stdio:['ignore','ignore','pipe','ipc']})
  const stderr=[];child.stderr.on('data',chunk=>stderr.push(String(chunk)))
  closed=once(child,'close')
  await Promise.race([once(child,'message').then(([v])=>assert.equal(v,'locked')),closed.then(()=>{throw new Error('writer exited before ready: '+stderr.join(''))})])
  first=api.clearSessionCache();second=api.clearSessionCache();assert(first instanceof Promise&&second instanceof Promise)
  let firstDone=false,secondDone=false,closeDone=false
  void first.then(()=>{firstDone=true});void second.then(()=>{secondDone=true})
  closePromise=handle.close();void closePromise.then(()=>{closeDone=true})
  await delay(25)
  assert.equal(firstDone,false);assert.equal(secondDone,false);assert.equal(closeDone,false)
  child.send('release')
  await Promise.all([first,second,closePromise])
  const [code,signal]=await closed;assert.equal(code,0);assert.equal(signal,null)
  assert.equal(child.stdout,null);assert(child.stderr.readableEnded)
  report.nativeWriterJoined=true;report.clearAndCloseWaited=true;report.opaqueHandle=true
 }
 report.completionPromise=true;report.result='PASS'
}finally{
 if(child&&child.exitCode===null&&child.signalCode===null){child.kill('SIGTERM');await closed}
 await Promise.allSettled([first,second,closePromise]);await handle?.close()
 rmSync(root,{recursive:true,force:true});report.fixtureRemoved=true
 writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report))
}
