import { clearSessionCache } from "./package/dist/proxy/server.js";
const completion: Promise<void> = clearSessionCache();
await completion;
