import {spyOn} from 'bun:test'
import * as fs from 'node:fs'
import * as cp from 'node:child_process'
const [candidate,baseline,output]=process.argv.slice(2)
const {snapshotSource}=await import(candidate+'/src/proxy/buildSnapshot.ts')
const records=[]
for(const [label,root]of [['candidate',candidate],['baseline',baseline],['candidate',candidate],['baseline',baseline]]){
 const spans=[];const spies=[]
 for(const [namespace,name]of [[fs,'lstatSync'],[fs,'openSync'],[fs,'fstatSync'],[fs,'readSync'],[cp,'spawnSync']]){
  const original=namespace[name]
  spies.push(spyOn(namespace,name).mockImplementation((...args)=>{
   const start=performance.now();try{return Reflect.apply(original,namespace,args)}finally{
    const elapsed=performance.now()-start
    spans.push({operation:name,ms:elapsed,...(name==='spawnSync'?{command:args[0],args:args[1]}:name==='openSync'||name==='lstatSync'?{path:String(args[0])}:{})})
   }
  }))
 }
 const start=performance.now();let result
 try{const snapshot=snapshotSource(root);result={result:'PASS',head:snapshot.sha,sourceHash:snapshot.sourceHash}}
 catch(error){result={result:'FAIL',error:error.name,message:error.message,reason:error.reason}}
 finally{for(const spy of spies.reverse())spy.mockRestore()}
 records.push({label,root,...result,totalMs:performance.now()-start,spans:spans.length,operationMs:Object.fromEntries([...new Set(spans.map(x=>x.operation))].map(op=>[op,spans.filter(x=>x.operation===op).reduce((a,b)=>a+b.ms,0)])),slowest:spans.sort((a,b)=>b.ms-a.ms).slice(0,12)})
}
fs.writeFileSync(output,JSON.stringify({records,scope:'Identical source fingerprint implementation; observe actual Git/filesystem calls, original 2-second budget unchanged, no model calls or dependency installs.'},null,2)+'\n');console.log(JSON.stringify(records.map(({slowest,...row})=>row)))
