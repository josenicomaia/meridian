from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-clear-completion-20261020');out=Path('/tmp/meridian-resume-20261020/heartbeat-cadence-933');p=root/'src/__tests__/fixtures/bookkeeping-heartbeat.ts';original=p.read_bytes();text=original.decode();bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');records=[]
cases=[('missing-gap',text.replace('  assert(sample.maxGapMs <= 25, `timer gap ${sample.maxGapMs} > 25 ms`)\n',''),'gap boundary|long pause'),('missing-deadline',text.replace('  assertAdmissionDeadline(sample)\n',''),'early-expiry|strict 50 ms'),('missing-callback',text.replace('  assert(sample.ticks.length > 0, "timer starved: no callbacks")\n',''),'silent timer|fully blocked')]
for name,mutant,pattern in cases:
 assert mutant!=text
 try:
  p.write_text(mutant)
  with(out/(name+'-negative.log')).open('w')as log:r=subprocess.run([bun,'test','--test-name-pattern',pattern,'src/__tests__/bookkeeping-heartbeat.test.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert r.returncode!=0,name
 finally:p.write_bytes(original)
 records.append({'name':name,'exit':r.returncode,'sourceRestored':p.read_bytes()==original})
(out/'negative-controls.json').write_text(json.dumps({'restoredSha256':hashlib.sha256(original).hexdigest(),'cases':records},indent=2)+'\n');print(json.dumps(records),flush=True)
with(out/'focused-corrected.log').open('w')as log:r=subprocess.run([bun,'test','--timeout','30000','src/__tests__/bookkeeping-heartbeat.test.ts','src/__tests__/bookkeeping-transactions.test.ts'],cwd=root,env=dict(env,BOOKKEEPING_ACCEPTANCE_OUT=str(out/'corrected-native')),stdout=log,stderr=subprocess.STDOUT)
print('Final focused',r.returncode,flush=True)
(out/'focused-result.json').write_text(json.dumps({'exit':r.returncode,'helperSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
