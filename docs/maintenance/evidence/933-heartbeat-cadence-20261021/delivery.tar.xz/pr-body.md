The three-writer admission test can report a starved timer while its deadline and responsiveness bounds pass. A captured Node run delivered 11–13 callbacks over 81.7–82.9 ms with maximum gaps of 10.0–11.1 ms. The old minimum of 13 callbacks would reject two of those samples even though every gap stayed below the existing 25 ms limit.

Require a real callback and retain the existing 25 ms maximum gap, no-early-expiry check and strict 50 ms expiry allowance. The sampler still requests a 5 ms interval; its acceptance check now uses the observed gaps. [Node timer scheduling depends on event-loop work](https://nodejs.org/api/timers.html#scheduling-timers).

Eight direct controls cover responsive jitter, the recorded eleven-tick schedule, the exact gap boundary, missing callbacks, a fully blocked observation, a long pause with a high callback count, early expiry and late expiry. The old helper fails three valid-schedule controls. Removing the callback, gap or deadline guard makes the corresponding negative controls fail; every mutation is restored.

Validation:

- 28 focused tests pass, including the actual three competing Node writers.
- Final-head `npm test`: 8,078 pass / 36 skip / 0 fail across all 26 isolated groups, with the verified published 1.84.0 compatibility tarball. Standalone typecheck and build pass. All eight executed final-head CI checks pass; changelog duplication is expected-skipped. The superseded push Nix run was cancelled; the same-head PR Nix run succeeded.
- No product code, dependency, timeout or model call changes. This corrects the heartbeat assertion related to #933; the broader issue stays open.

This independent main fix unblocks current verification of #1220. Its original Opus cache-prefix acceptance gate remains open.

[Captured Node schedules, controls and retained failures](https://github.com/rynfar/meridian/blob/ff7c09af328328915d748dd9c6f3341ea0c865de/docs/maintenance/evidence/933-heartbeat-cadence-20261021/README.md).
