from pathlib import Path
import subprocess,json,datetime
out=Path(__file__).parent;name='meridian-1303-byte-budget-r1'
bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve('/usr/bin/python3',['python3','/evidence/run-inside.py'],process.env)"
args=['docker','run','--rm','--init','--name',name,'--label','meridian.backlog=1303-budget-20261020','--tmpfs','/tmp:rw,exec,mode=1777,size=2g','-v',str(out)+':/evidence','-v','/Volumes/DevSSD/meridian/repo/node_modules:/shared-deps:ro','-v','/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime-linux/bun:/bun:ro','node:24.20.0-bookworm','node','-e',bootstrap]
record=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),container=name,models=0)
with(out/'docker.log').open('w')as log:
 child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);record['originalPID']=child.pid
 try:record['exit']=child.wait(timeout=780)
 except subprocess.TimeoutExpired:
  record['timeout']=True;subprocess.run(['docker','stop','-t','10',name],stdout=log,stderr=subprocess.STDOUT,timeout=30);record['exit']=child.wait(timeout=15)
record['containerRemoved']=subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'docker-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(0 if record['exit']==0 and record['containerRemoved']else 1)
