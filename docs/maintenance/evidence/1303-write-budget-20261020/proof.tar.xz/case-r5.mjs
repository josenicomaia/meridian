import assert from 'node:assert/strict'
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,statSync,statfsSync,existsSync,realpathSync,rmSync} from 'node:fs'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash,randomUUID} from 'node:crypto'
import cp from 'node:child_process'

const [source,backend,rawCount] = process.argv.slice(2), count=Number(rawCount)
assert(['json','sqlite'].includes(backend) && [100,900].includes(count))
assert.equal(process.platform,'linux')
let networkAttempts=0
globalThis.fetch=()=>{networkAttempts++;throw new Error('Metadata-only budget fixture denies network')}
const root=realpathSync(mkdtempSync('/tmp/meridian-1303-case-')),directory=join(root,'sessions'),configDir=join(root,'synthetic-config')
for(const p of [directory,configDir,join(root,'home')])mkdirSync(p,{mode:0o700})
assert.equal(statfsSync(root).type,0x01021994)
process.env.HOME=join(root,'home');process.env.CLAUDE_CONFIG_DIR=configDir
process.env.MERIDIAN_CREDENTIALS_READONLY='1'
const store=await import(pathToFileURL(join(source,'src/proxy/sessionStore.ts')).href)
const life=await import(pathToFileURL(join(source,'src/proxy/sessionLifecycle.ts')).href)
let handle
const report={sourceSHA:readFileSync(join(source,'SOURCE_SHA'),'utf8').trim(),backend,count,runtime:'Bun '+Bun.version,platform:process.platform,filesystem:'owned Linux TMPFS',models:0,networkAttempts:0,scope:'Synthetic Meridian mapping/ledger metadata only; no SDK transcript files or inference'}
const size=path=>existsSync(path)?statSync(path).size:0
const wal=join(directory,'session-bookkeeping.sqlite-wal'),storePath=join(directory,'sessions.json'),sidecar=join(directory,'session-gc.json')
function measure(path){return backend==='sqlite'?{bytes:size(wal),inode:existsSync(wal)?statSync(wal).ino:null}:{bytes:size(path),inode:statSync(path).ino}}
function cost(before,after){return backend==='sqlite'?Math.max(0,after.bytes-before.bytes):after.inode!==before.inode?after.bytes:0}
try{
 store.setSessionStoreDir(directory)
 store.storeSharedSession('bootstrap','bootstrap-sdk')
 const hashes=Array.from({length:128},(_,n)=>n.toString(16).padStart(64,'0')),fixture={},resources={}
 for(let i=0;i<count;i++){
  fixture['session-'+i]={claudeSessionId:'sdk-'+i,revision:1,generationId:'synthetic-generation-'+i,createdAt:1,lastUsedAt:1,messageCount:hashes.length,lineageHash:'a'.repeat(64),messageHashes:hashes,sdkMessageUuids:Array(hashes.length).fill(null)}
  const locator={sessionId:'ledger-'+i,configDir,projectDir:root},key=life.getTranscriptResourceKey(locator)
  resources[key]={key,locator,state:'live',createdAt:1,updatedAt:1,attempts:0}
 }
 writeFileSync(storePath,JSON.stringify(fixture),{mode:0o600})
 writeFileSync(sidecar,JSON.stringify({version:1,resources}),{mode:0o600})
 report.seedMappingBytes=size(storePath);report.seedLedgerBytes=size(sidecar)
 if(backend==='sqlite'){
  const migration=cp.spawnSync(process.execPath,['--no-install',join(source,'bin/session-bookkeeping.ts'),'migrate','--session-dir',directory,'--writers-stopped','--json'],{encoding:'utf8',timeout:30000,env:process.env})
  assert.equal(migration.error,undefined);assert.equal(migration.signal,null);assert.equal(migration.status,0,migration.stderr)
  report.migrationOriginalChildJoined=true
  const db=await import(pathToFileURL(join(source,'src/proxy/session/bookkeeping/database.ts')).href)
  handle=db.initializeSessionBookkeeping(directory)
  const {sqliteSessionStoreBackend}=await import(pathToFileURL(join(source,'src/proxy/session/bookkeeping/sqliteStoreBackend.ts')).href)
  const {sqliteLifecycleBackend}=await import(pathToFileURL(join(source,'src/proxy/session/bookkeeping/lifecycleSql.ts')).href)
  store.setSessionStoreBackendForTest(sqliteSessionStoreBackend)
  life.setSessionLifecycleBackendForTest(sqliteLifecycleBackend)
  const {bookkeepingEngineInfo}=await import(pathToFileURL(join(source,'src/proxy/session/bookkeeping/nativeDatabase.ts')).href)
  report.engine=bookkeepingEngineInfo()
 }
 let mappingPayloadBytes=0,mappingChanges=0
 for(let i=0;i<20;i++){
  const before=measure(storePath),generation=store.storeSharedSession('session-0','sdk-0'),after=measure(storePath)
  assert.notEqual(generation,false);mappingPayloadBytes+=cost(before,after);mappingChanges+=Number(before.inode!==after.inode)
 }
 const locator={sessionId:'sdk-0',configDir,projectDir:root}
 const generation=store.attachSharedTranscriptLocator('session-0','sdk-0',locator);assert.notEqual(generation,false)
 const beforeBytes=backend==='json'?readFileSync(storePath):null
 let noOpPayloadBytes=0,noOpReplacements=0
 for(let i=0;i<5;i++){
  const before=measure(storePath),same=store.attachSharedTranscriptLocator('session-0','sdk-0',locator,generation),after=measure(storePath)
  assert.equal(same,generation);noOpPayloadBytes+=cost(before,after);noOpReplacements+=Number(before.inode!==after.inode)
  if(beforeBytes)assert.deepEqual(readFileSync(storePath),beforeBytes)
 }
 const otherConfig=join(root,'other-synthetic-config');mkdirSync(otherConfig,{mode:0o700})
 const changed=store.attachSharedTranscriptLocator('session-0','sdk-0',{...locator,configDir:otherConfig},generation)
 assert.notEqual(changed,false);assert.notEqual(changed,generation)
 const beforeStale=measure(storePath)
 assert.equal(store.attachSharedTranscriptLocator('session-0','sdk-0',locator,generation),false)
 assert.equal(cost(beforeStale,measure(storePath)),0)
 assert.equal(store.lookupSharedSessionResult('session-0').generation,changed)
 let lifecyclePayloadBytes=0
 const ledgerLocator={sessionId:'ledger-0',configDir,projectDir:root},options={storeDir:directory,maxOwned:2000,maxPending:2000}
 const journaled=await life.ensureTranscriptJournaled(ledgerLocator,options)
 for(let i=0;i<20;i++){
  let before=measure(sidecar)
  const lease=await life.acquireActiveTranscriptLease([journaled],options)
  let after=measure(sidecar);lifecyclePayloadBytes+=cost(before,after);before=after
  await life.releaseActiveTranscriptLease(lease,options)
  after=measure(sidecar);lifecyclePayloadBytes+=cost(before,after)
 }
 const writeBytes=()=>Number(readFileSync('/proc/self/io','utf8').match(/^wchar:\s*(\d+)/m)[1])
 const gcOptions={...options,retiredGraceMs:0,preparedGraceMs:0,maxDeletesPerRun:1,maxTombstones:2000}
 let scriptedDeletionCalls=0
 gcOptions.deleter=async()=>{scriptedDeletionCalls++}
 const beforeGc=writeBytes()
 for(let i=0;i<20;i++){
  const target=await life.prepareFork({sessionId:randomUUID(),configDir,projectDir:root},gcOptions)
  await life.abandonFork(target,gcOptions)
  const result=await life.runGc(gcOptions)
  assert.equal(result.deleted,1,'Each GC round must update exactly one prepared/retired/deleted target')
 }
 const gcWriteSyscallBytes=writeBytes()-beforeGc
 assert.equal(scriptedDeletionCalls,20)
 report.gc={rounds:20,scriptedDeletionCalls,gcWriteSyscallBytes,metric:'Linux process wchar: bytes returned by write-family syscalls, including native SQLite WAL/checkpoint or JSON payload and lock records; not physical-device bytes',scope:'Real prepare/abandon/GC metadata paths with an explicit scripted deleter; actual SDK deletion custody is qualified separately in PR1219'}
 report.results={mappingMutations:20,mappingPayloadBytes,mappingChanges,noOpCalls:5,noOpPayloadBytes,noOpReplacements,noOpGenerationUnchanged:true,changedLocatorAdvancesGeneration:true,staleGenerationRejectedWithoutPublication:true,lifecycleLeaseMutations:40,lifecyclePayloadBytes}
 if(backend==='sqlite'){
  report.retainedMappings=handle.reader.get('SELECT count(*) n FROM mappings').n
  report.retainedResources=handle.reader.get('SELECT count(*) n FROM resources').n
  assert.equal(report.retainedMappings,count);assert(report.retainedResources>=count)
  assert.equal(noOpPayloadBytes,0)
 }else{
  report.retainedMappings=Object.keys(store.readSessionStoreSnapshot()).length
  report.retainedResources=Object.keys(JSON.parse(readFileSync(sidecar,'utf8')).resources).length
  assert.equal(report.retainedMappings,count);assert(report.retainedResources>=count)
 }
 assert.equal(networkAttempts,0);report.networkAttempts=networkAttempts;report.result='PASS'
}finally{
 if(backend==='sqlite'){
  store.setSessionStoreBackendForTest(null);life.setSessionLifecycleBackendForTest(null);handle?.close()
 }
 store.setSessionStoreDir(null)
 if(report.result==='PASS'){rmSync(root,{recursive:true,force:true});report.fixtureRemoved=true}
}
console.log(JSON.stringify(report))
