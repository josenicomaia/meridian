from pathlib import Path
import subprocess,json,os,datetime,hashlib,tempfile,shutil
out=Path('/evidence/r6');fixtures=out.parent;meta=json.loads((fixtures/'preparation.json').read_text())
owned=Path(tempfile.mkdtemp(prefix='meridian-1303-host-'));owned.chmod(0o700)
env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(HOME=str(owned),CLAUDE_CONFIG_DIR=str(owned/'no-owner-credentials'),MERIDIAN_CREDENTIALS_READONLY='1')
import urllib.request,base64,tarfile,io
metadataURL='https://registry.npmjs.org/@libsql%2flinux-arm64-gnu/0.5.29'
with urllib.request.urlopen(metadataURL,timeout=30)as response: package=json.load(response)
assert package['name']=='@libsql/linux-arm64-gnu'and package['version']=='0.5.29'
assert package['dist']['tarball'].startswith('https://registry.npmjs.org/')and package['dist']['integrity'].startswith('sha512-')
with urllib.request.urlopen(package['dist']['tarball'],timeout=30)as response: payload=response.read()
assert hashlib.sha512(payload).digest()==base64.b64decode(package['dist']['integrity'].split('-',1)[1])
platform=owned/'node_modules/@libsql/linux-arm64-gnu';platform.mkdir(parents=True)
with tarfile.open(fileobj=io.BytesIO(payload))as archive:
 for member in archive.getmembers():
  assert member.name.startswith('package/')
  member.name=member.name.removeprefix('package/')
  if member.name:
   destination=(platform/member.name).resolve();assert destination.is_relative_to(platform.resolve())
   if member.isdir():destination.mkdir(parents=True,exist_ok=True)
   else:
    assert member.isfile()and member.size<64*1024**2
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(archive.extractfile(member).read());destination.chmod(0o600)
env['NODE_PATH']=str(owned/'node_modules')
library={'name':package['name'],'version':package['version'],'metadataURL':metadataURL,'tarball':package['dist']['tarball'],'integrity':package['dist']['integrity'],'sha256':hashlib.sha256(payload).hexdigest(),'scope':'Matching Linux optional native package only, extracted in disposable TMPFS; existing Mac dependency tree remains read-only; no install scripts'}
(out/'linux-library.json').write_text(json.dumps(library,indent=2)+'\n')
record=dict(result='RUNNING',models=0,cases=[],heads=meta['heads'],started=datetime.datetime.now(datetime.timezone.utc).isoformat(),harnessSHA256=hashlib.sha256((fixtures/'case-r6.mjs').read_bytes()).hexdigest(),resourcePolicy='Source snapshots/read-only existing dependencies; one owned TMPFS case at a time; no installs or new worktrees')
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 for label,backend in [('baseline','json'),('candidate','json'),('candidate','sqlite')]:
  for count in [100,900]:
   name=label+'-'+backend+'-'+str(count)
   with(out/(name+'.log')).open('w')as log:
    child=subprocess.Popen(['/bun','--no-install',str(fixtures/'case-r6.mjs'),str(fixtures/('source-'+label)),backend,str(count)],env=env,stdout=log,stderr=subprocess.STDOUT)
    try:code=child.wait(timeout=120)
    except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=10)
   lines=(out/(name+'.log')).read_text().splitlines();report=next((json.loads(line)for line in reversed(lines)if line.startswith('{"sourceSHA":')),None)
   case=dict(case=name,exit=code,originalPID=child.pid,originalJoined=True,report=report);record['cases'].append(case);save()
   assert code==0 and report and report['result']=='PASS'and report['fixtureRemoved']and report['networkAttempts']==0
   assert report['sourceSHA']==meta['heads'][label]
   print(json.dumps({key:report[key]for key in ['sourceSHA','backend','count','results','retainedMappings','fixtureRemoved']}),flush=True)
 rows={row['case']:row['report']for row in record['cases']}
 small=rows['candidate-sqlite-100']['results'];large=rows['candidate-sqlite-900']['results']
 assert small['mappingPayloadBytes']>0 and small['lifecyclePayloadBytes']>0
 ratios={key:large[key]/small[key]for key in ['mappingPayloadBytes','lifecyclePayloadBytes']}
 ratios['gcWriteSyscallBytes']=rows['candidate-sqlite-900']['gc']['gcWriteSyscallBytes']/rows['candidate-sqlite-100']['gc']['gcWriteSyscallBytes']
 assert all(value<2 for value in ratios.values()),ratios
 assert all(rows['candidate-'+backend+'-'+str(n)]['results']['noOpPayloadBytes']==0 for backend in ['json','sqlite']for n in [100,900])
 record.update(result='PASS',sqlGrowthRatiosForNinefoldUnrelatedHistory=ratios,defaultJSONStillFullDocument=True,metric='JSON replacement payload bytes versus appended SQLite WAL bytes; not physical device writes or an SSD benchmark')
 shutil.rmtree(owned);record['runnerHomeRemoved']=True
except BaseException as error:record.update(result='FAIL',failure=type(error).__name__+': '+str(error)[:500])
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({key:record.get(key)for key in ['result','failure','sqlGrowthRatiosForNinefoldUnrelatedHistory','models','runnerHomeRemoved']}),flush=True)
raise SystemExit(0 if record['result']=='PASS'else 1)
