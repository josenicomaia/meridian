from pathlib import Path
import subprocess,json,datetime,os
r=Path('/tmp/meridian-resume-20261020');source=Path('/private/tmp/meridian-pr1397-20261020');head=json.loads((r/'1397-final-source.json').read_text())['head'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();receipt=r/'1397-final-current-local-exit.json';old=r/'1397-pre-harness-current-local-exit.json';assert not old.exists();old.write_bytes(receipt.read_bytes());record={'head':head,'base':'3667a1555e104d0d82fee180eedfde68ab218390','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'exit':None};env=dict(os.environ,PATH='/tmp/meridian-1399-tooling/node_modules/.bin:'+os.environ['PATH'])
for label,args in [('focused',['bun','test','src/__tests__/priority-client-cancel.test.ts']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build']),('full',['npm','test'])]:
 receipt.write_text(json.dumps(record,indent=2)+'\n')
 with(r/('1397-harness-final-'+label+'.log')).open('w')as log:code=subprocess.run(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 record['commands'].append({'label':label,'exit':code});receipt.write_text(json.dumps(record,indent=2)+'\n');print(label,code,flush=True)
 if code:record['exit']=code;break
else:record['exit']=0
record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(record['exit'])
