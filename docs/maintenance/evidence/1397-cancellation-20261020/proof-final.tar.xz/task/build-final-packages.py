from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';source=Path('/private/tmp/meridian-pr1397-20261020');baseline=Path('/private/tmp/meridian-main-priority-final-20261020');stage=out/'packages-final';stage.mkdir();base='3667a1555e104d0d82fee180eedfde68ab218390';head='acbe1b56c9c8409becc04340189e0d37aec33041';local=json.loads((r/'1397-final-current-local-exit.json').read_text());assert all(any(c['label']==name and c['exit']==0 for c in local['commands']) for name in ['focused','typecheck','build']);assert not baseline.exists();subprocess.run(['git','worktree','add','--detach',str(baseline),base],cwd=source,check=True,stdout=subprocess.DEVNULL);(baseline/'node_modules').symlink_to(source/'node_modules',target_is_directory=True);env=dict(os.environ,PATH='/tmp/meridian-1399-tooling/node_modules/.bin:'+os.environ['PATH']);record={'heads':{'baseline':base,'candidate':head},'steps':[],'result':'RUNNING'}
def save():(stage/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,cwd):
 with(stage/(label+'.log')).open('w')as f:p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 record['steps'].append({'label':label,'exit':p.returncode});save();print(label,p.returncode,flush=True);assert p.returncode==0
try:
 for label,path in [('baseline',baseline),('candidate',source)]:
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==record['heads'][label];assert not subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).strip()
  if label=='baseline':run('baseline-build',['npm','run','build'],path)
  pack=stage/(label+'-pack');pack.mkdir();run(label+'-pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(pack)],path);tar=next(pack.glob('*.tgz'));record[label+'Package']={'tarball':str(tar),'sha256':hashlib.sha256(tar.read_bytes()).hexdigest()};save()
  mac=stage/(label+'-mac');mac.mkdir();(mac/'package.json').write_text('{"private":true,"type":"module"}\n');run(label+'-mac-install',['npm','install','--ignore-scripts','--no-audit','--no-fund','--cache',str(r/'npm-cache'),str(tar)],mac)
  linux=stage/(label+'-linux');linux.mkdir();(linux/'package.json').write_text('{"private":true,"type":"module"}\n');run(label+'-linux-install',['docker','run','--rm','--platform','linux/arm64','-v',str(pack)+':/package:ro','-v',str(linux)+':/artifact','-v',str(r/'npm-cache')+':/npm-cache','-w','/artifact','node:24.20.0-bookworm','npm','install','--ignore-scripts','--no-audit','--no-fund','--cache','/npm-cache','/package/'+tar.name],source)
  for artifact in [mac,linux]:
   versions={name:json.loads((artifact/'node_modules'/name/'package.json').read_text())['version']for name in ['@anthropic-ai/claude-agent-sdk','libsql']};assert versions=={'@anthropic-ai/claude-agent-sdk':'0.2.141','libsql':'0.5.29'}
 record['result']='PASS_PACKAGES_READY'
finally:save();print(record['result'],flush=True)
