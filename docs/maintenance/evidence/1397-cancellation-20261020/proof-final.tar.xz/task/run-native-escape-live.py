from pathlib import Path
import subprocess,json,hashlib,os,signal,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';source=Path('/private/tmp/meridian-pr1397-20261020');stage=out/'packages-final';phase='native-escape';task='1397-'+phase+'-sonnet55';scenarios=['mac','linux'];grant=r/('private/1397-'+phase+'-pool-grant.json');guard=r/('private/1397-'+phase+'-admission.json');attempt=out/(phase+'-MODEL_ATTEMPT.json');hold=r/'LIVE_MODEL_HOLD.json';holdSHA=hashlib.sha256(hold.read_bytes()).hexdigest();heads=json.loads((r/'1397-final-source.json').read_text());head=heads['head'];assert not attempt.exists()and not grant.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();local=json.loads((r/'1397-final-current-local-exit.json').read_text());assert local['head']==head and all(any(x['label']==label and x['exit']==0 for x in local['commands'])for label in ['focused','typecheck','build']);packages=json.loads((stage/'summary.json').read_text());assert packages['result']=='PASS_PACKAGES_READY'and packages['heads']=={'baseline':heads['base'],'candidate':head};assert json.loads((out/'linux-offline-summary-r2.json').read_text())['result']=='PASS';smoke=json.loads((out/'portable-final-smoke.json').read_text());assert smoke['result']=='PASS'and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in smoke['scriptSHA256'].items()if p.endswith('.mjs'));core=json.loads((out/'first-core-live-task.json').read_text());assert core['result']=='PASS'and core['grantRemoved']and core['olderHoldsUnchanged']
for other in ['linux-core','mac-relations','linux-relations']:
 receipt=out/(other+'-live-task.json')
 if receipt.exists():assert json.loads(receipt.read_text())['result']=='PASS','Earlier continuation failure stops dependent actual tasks'
assert json.loads((out/'native-escape-offline-summary.json').read_text())['result']=='PASS';driver=out/'native-escape-client.py';host=source/'scripts/lib/priorityCancellationHost.mjs';creator=out/'create-continuation-pool-grant.mjs';nativeLinux=Path('/tmp/meridian-issue-r2-evidence/linux-runtime/node_modules/@anthropic-ai/claude-code-linux-arm64');seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [driver,host,creator,Path(__file__)]};record={'task':task,'phase':phase,'head':head,'baseline':heads['base'],'cases':[],'result':'RUNNING','scriptSHA256':seal,'platforms':['mac','linux'],'model':'claude-sonnet-5-5','poolScope':'Real distinct paid-disabled Team and exhausted personal spare; only Team may forward. No twohealthyaccount/failover/quota recovery claim.','resourcePolicy':'Existing three worktrees and four current installs reused. One --rm container per Linux case. Original processes/pipes join; fixture homes removed by committed harness.'}
def save():(out/(phase+'-live-task.json')).write_text(json.dumps(record,indent=2)+'\n')
def check():
 assert hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in seal.items())
def members(group):return[int(x.split()[0])for x in subprocess.check_output(['ps','-axo','pid=,pgid='],text=True).splitlines()if len(x.split())==2 and int(x.split()[1])==group]
def stop(process,row,container,log):
 if container:subprocess.run(['docker','stop','-t','10',container],stdout=log,stderr=subprocess.STDOUT,timeout=20)
 if members(process.pid):
  row['ownedProcessGroupCleanup']=members(process.pid)
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:row['ownedGroupGoneBeforeTERM']=True
 try:process.wait(timeout=10)
 except subprocess.TimeoutExpired:
  try:os.killpg(process.pid,signal.SIGKILL)
  except ProcessLookupError:row['ownedGroupGoneBeforeKILL']=True
  process.wait(timeout=5)
try:
 for platform in scenarios:
  scenario='escape'
  for label in ['baseline','candidate']:
   assert len(record['cases'])<4;check();name='live-native-'+platform+'-'+scenario+'-'+label+'-r2';target=out/name;assert not target.exists()
   subprocess.run(['/tmp/meridian-1399-tooling/node_modules/.bin/bun',str(creator)],cwd=source,env=dict(os.environ,E2E_PHASE=phase,E2E_NEW_TASK=task,E2E_ALLOW_LIVE_MODEL='1'),check=True)
   admission=json.loads(guard.read_text());assert admission['maximumCases']==4 and admission['includedCapacityKnown']is False
   if not attempt.exists():attempt.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':task,'head':head,'baseline':heads['base'],'scripts':seal,'firstAdmission':admission,'olderHoldsSHA256':holdSHA},indent=2)+'\n')
   row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admission':admission};record['cases'].append(row);save();values={'E2E_MERIDIAN_ROOT':str(stage/(label+'-'+platform+'/node_modules/@rynfar/meridian')),'E2E_NATIVE_BIN':'/native-linux/claude'if platform=='linux'else'/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302','E2E_EVIDENCE_DIR':str(target),'E2E_FRONT_NATIVE_BIN':'/native-linux/claude'if platform=='linux'else'/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302','E2E_ALLOW_LIVE_MODEL':'1','E2E_LIVE_PROFILE_FILE':str(grant),'E2E_USAGE_GUARD_FILE':str(guard)}
   if scenario=='watchdog':values['E2E_WATCHDOG_MS']='8000'
   flags=[];container=None;env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']}
   if platform=='linux':
    container='meridian-1397-'+name;row['container']=container;args=['docker','run','--rm','--init','--name',container,'--label','meridian.backlog=1397-cancel-20261020','-v',str(r)+':'+str(r),'-v',str(source)+':'+str(source)+':ro','-v',str(nativeLinux)+':/native-linux:ro']
    for k,v in values.items():args+=['-e',k+'='+v]
    bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve('/usr/bin/python3',['python3',"+json.dumps(str(driver))+"],process.env)";args+=['node:24.20.0-bookworm','node','-e',bootstrap]
   else:env.update(values);args=['python3',str(driver)]
   with(out/(name+'.log')).open('w')as log:
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['originalControllerPID']=process.pid;save()
    try:code=process.wait(timeout=150)
    except subprocess.TimeoutExpired:row['timeout']=True;stop(process,row,container,log);code=process.returncode
    remaining=members(process.pid)
    if remaining:stop(process,row,container,log)
   removed=not container or subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
   if not removed:subprocess.run(['docker','rm','-f',container],stdout=subprocess.DEVNULL,check=True);row['unexpectedForcedContainerCleanup']=True
   client=json.loads((target/'client-witness.json').read_text())if(target/'client-witness.json').exists()else{};report=json.loads((target/'report.json').read_text())if(target/'report.json').exists()else{};expected='PASS'
   row.update(exit=code,result=client.get('result'),failure=client.get('failure'),hostResult=report.get('result'),generations=len(report.get('provider',[])),officialForwards=report.get('officialForwards',0),joined=client.get('joined')and report.get('joined'),correlated=report.get('providerOriginalNativeCorrelated'),fixtureRemoved=report.get('fixtureRemoved'),containerRemoved=removed,profiles=sorted(set(p.get('profileId')for p in report.get('provider',[]))))
   row['qualified']=code==0 and client.get('result')==expected and report.get('result')=='CLOSED'and row['joined']and row['correlated']and row['fixtureRemoved']and removed and not remaining and row['officialForwards']>=row['generations']>0 and all(p.get('profileId')=='pool-a'and p.get('responseModel')=='claude-sonnet-5-5'and not p.get('scripted')for p in report.get('provider',[]))
   save();print(json.dumps({k:v for k,v in row.items()if k!='admission'}),flush=True);check();assert row['qualified'],'Actual failure/inconclusive case retained; stop dependent work with no model/account/workload retry'
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['olderHoldsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'phase':phase,'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'olderHoldsUnchanged':record['olderHoldsUnchanged']}),flush=True)
