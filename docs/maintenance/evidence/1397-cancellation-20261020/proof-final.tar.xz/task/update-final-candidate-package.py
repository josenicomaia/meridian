from pathlib import Path
import subprocess,json,hashlib,os,shutil,tarfile
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';stage=out/'packages-final';source=Path('/private/tmp/meridian-pr1397-20261020');heads=json.loads((r/'1397-final-source.json').read_text());head=heads['head'];local=json.loads((r/'1397-final-current-local-exit.json').read_text());assert local['head']==head and any(x['label']=='build'and x['exit']==0 for x in local['commands']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head;assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();summary=stage/'summary.json';prior=stage/'summary-acbe.json';assert not prior.exists();prior.write_bytes(summary.read_bytes());record=json.loads(summary.read_text());assert record['heads']['candidate']==heads['previous'];record['previousCandidate']=record['heads']['candidate'];record['heads']['candidate']=head;record['result']='RUNNING_CANDIDATE_UPDATE';pack=stage/'candidate-pack-f60';pack.mkdir();cache=stage/'transient-npm-cache';env=dict(os.environ)
def save():summary.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,cwd=source):
 with(stage/(label+'.log')).open('w')as log:code=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
 record['steps'].append({'label':label,'exit':code});save();print(label,code,flush=True);assert code==0
try:
 run('harness-final-pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(pack)]);tar=next(pack.glob('*.tgz'));record['candidatePackage']={'tarball':str(tar),'sha256':hashlib.sha256(tar.read_bytes()).hexdigest()};save()
 run('harness-final-mac-update',['npm','install','--ignore-scripts','--no-audit','--no-fund','--cache',str(cache),str(tar)],stage/'candidate-mac')
 run('harness-final-linux-update',['docker','run','--rm','--init','--name','meridian-1397-candidate-package-update','--label','meridian.backlog=1397-cancel-20261020','-v',str(pack)+':/package:ro','-v',str(stage/'candidate-linux')+':/artifact','-w','/artifact','node:24.20.0-bookworm','npm','install','--ignore-scripts','--no-audit','--no-fund','/package/'+tar.name])
 with tarfile.open(tar)as archive:packed={x.name.removeprefix('package/'):hashlib.sha256(archive.extractfile(x).read()).hexdigest()for x in archive.getmembers()if x.isfile()}
 record['candidateInstalledVerification']={}
 for platform in ['mac','linux']:
  root=stage/('candidate-'+platform)/'node_modules';versions={name:json.loads((root/name/'package.json').read_text())['version']for name in ['@anthropic-ai/claude-agent-sdk','libsql']};assert versions=={'@anthropic-ai/claude-agent-sdk':'0.2.141','libsql':'0.5.29'};assert all(hashlib.sha256((root/'@rynfar/meridian'/name).read_bytes()).hexdigest()==digest for name,digest in packed.items());record['candidateInstalledVerification'][platform]={'allPackedFileBytesMatch':True,'packedFiles':len(packed),'versions':versions}
 record['result']='PASS_PACKAGES_READY'
finally:
 if cache.exists():shutil.rmtree(cache)
 record['transientCacheRemoved']=not cache.exists();save();print(record['result'],flush=True)
