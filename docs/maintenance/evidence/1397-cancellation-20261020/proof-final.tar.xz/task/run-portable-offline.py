from pathlib import Path
import subprocess,json,os,hashlib,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';stage=out/'packages-final';source=Path('/private/tmp/meridian-pr1397-20261020');nativeLinux=Path('/tmp/meridian-issue-r2-evidence/linux-runtime/node_modules/@anthropic-ai/claude-code-linux-arm64');driver=source/'scripts/e2e-priority-cancellation.mjs';host=source/'scripts/lib/priorityCancellationHost.mjs'
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [driver,host,Path(__file__)]};summary={'scope':'Portable repository harness; actual SDK/native with scripted API, ZERO real inference; path and cleanup controls','scriptSHA256':seal,'cases':[],'result':'RUNNING'}
def save():(out/'portable-offline-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for platform,scenario,label in [('mac','nonstream','baseline'),('mac','nonstream','candidate'),('mac','subtree','candidate'),('mac','queued','baseline'),('linux','watchdog','baseline'),('linux','watchdog','candidate')]:
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items());name='portable-'+platform+'-'+scenario+'-'+label+'-r1';target=out/name;assert not target.exists();flags=['--baseline']if label=='baseline'else[]
 env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};values={'E2E_MERIDIAN_ROOT':str(stage/(label+'-'+platform+'/node_modules/@rynfar/meridian')),'E2E_EVIDENCE_DIR':str(target),'E2E_CANCEL_CASE':scenario,'E2E_NATIVE_BIN':'/native-linux/claude'if platform=='linux'else'/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302'}
 if scenario=='watchdog':values['E2E_WATCHDOG_MS']='8000'
 container=None
 if platform=='linux':
  container='meridian-1397-'+name;args=['docker','run','--rm','--init','--name',container,'--label','meridian.backlog=1397-cancel-20261020','-v',str(r)+':'+str(r),'-v',str(source)+':'+str(source)+':ro','-v',str(nativeLinux)+':/native-linux:ro']
  for k,v in values.items():args+=['-e',k+'='+v]
  bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve(process.execPath,[process.execPath,"+json.dumps(str(driver))+",..."+json.dumps(flags)+"],process.env)";args+=['node:24.20.0-bookworm','node','-e',bootstrap]
 else:env.update(values);args=['node',str(driver)]+flags
 row={'case':name,'platform':platform,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};summary['cases'].append(row);save()
 with(out/(name+'.log')).open('w')as log:
  process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=process.wait(timeout=150)
  except subprocess.TimeoutExpired:
   if container:subprocess.run(['docker','stop','-t','10',container],stdout=log,stderr=subprocess.STDOUT,timeout=20)
   else:process.terminate()
   code=process.wait(timeout=15);row['timeout']=True
 removed=not container or subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 client=json.loads((target/'client-witness.json').read_text())if(target/'client-witness.json').exists()else{};report=json.loads((target/'report.json').read_text())if(target/'report.json').exists()else{};expected='EXPECTED_BASELINE_FAILURE'if label=='baseline'and scenario!='queued'else'PASS'
 row.update(exit=code,result=client.get('result'),failure=client.get('failure'),hostResult=report.get('result'),joined=client.get('joined')and report.get('joined'),nativeCorrelated=report.get('providerOriginalNativeCorrelated'),fixtureRemoved=report.get('fixtureRemoved'),containerRemoved=removed,realGenerations=0)
 row['qualified']=code==0 and client.get('result')==expected and row['joined']and row['nativeCorrelated']and row['fixtureRemoved']and removed and report.get('result')=='CLOSED'and all(p.get('scripted')for p in report.get('provider',[]))
 save();print(json.dumps(row),flush=True);assert row['qualified'],'Keep original failure, no dependent live attempts'
summary['result']='PASS';save();print('PASS_PORTABLE_PATHS_AND_FIXTURE_CLEANUP',flush=True)
