from pathlib import Path
import subprocess,json,os,hashlib,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';source=Path('/private/tmp/meridian-pr1397-20261020');nativeLinux=Path('/tmp/meridian-issue-r2-evidence/linux-runtime/node_modules/@anthropic-ai/claude-code-linux-arm64');driver=out/'native-escape-client.py';seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [driver,source/'scripts/lib/priorityCancellationHost.mjs',Path(__file__)]};record={'scope':'Literal native Escape against exact baseline/candidate, Mac2.1.302 and Linux2.1.301; ZERO real models, scripted API','scriptSHA256':seal,'cases':[],'result':'RUNNING'}
def save():(out/'native-escape-offline-summary.json').write_text(json.dumps(record,indent=2)+'\n')
existing=out/'native-escape-mac-candidate-offline-r2';client=json.loads((existing/'client-witness.json').read_text());assert client['result']=='PASS'and client['joined'];record['cases'].append({'case':existing.name,'adoptedCompletedExactSameScript':True,'result':'PASS','joined':True,'realGenerations':0})
for platform,label in [('mac','baseline'),('linux','baseline'),('linux','candidate')]:
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in seal.items());name='native-escape-'+platform+'-'+label+'-offline-r2';target=out/name;assert not target.exists();native='/native-linux/claude'if platform=='linux'else'/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302';values={'E2E_MERIDIAN_ROOT':str(out/('packages-final/'+label+'-'+platform+'/node_modules/@rynfar/meridian')),'E2E_EVIDENCE_DIR':str(target),'E2E_NATIVE_BIN':native,'E2E_FRONT_NATIVE_BIN':native};env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};container=None
 if platform=='linux':
  container='meridian-1397-'+name;args=['docker','run','--rm','--init','--name',container,'--label','meridian.backlog=1397-cancel-20261020','-v',str(r)+':'+str(r),'-v',str(source)+':'+str(source)+':ro','-v',str(nativeLinux)+':/native-linux:ro']
  for k,v in values.items():args+=['-e',k+'='+v]
  bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve('/usr/bin/python3',['python3',"+json.dumps(str(driver))+"],process.env)";args+=['node:24.20.0-bookworm','node','-e',bootstrap]
 else:env.update(values);args=['python3',str(driver)]
 row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['cases'].append(row);save()
 with(out/(name+'.log')).open('w')as log:
  process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=process.wait(timeout=180)
  except subprocess.TimeoutExpired:
   row['timeout']=True
   if container:subprocess.run(['docker','stop','-t','10',container],stdout=log,stderr=subprocess.STDOUT,timeout=20)
   else:process.terminate()
   code=process.wait(timeout=10)
 client=json.loads((target/'client-witness.json').read_text())if(target/'client-witness.json').exists()else{};report=json.loads((target/'report.json').read_text())if(target/'report.json').exists()else{};removed=not container or subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 row.update(exit=code,result=client.get('result'),failure=client.get('failure'),joined=client.get('joined')and report.get('joined'),nativeCorrelated=report.get('providerOriginalNativeCorrelated'),fixtureRemoved=report.get('fixtureRemoved'),frontendFixtureRemoved=client.get('frontendFixtureRemoved'),containerRemoved=removed,providerCalls=len(report.get('provider',[])),realGenerations=0)
 row['qualified']=code==0 and row['result']=='PASS'and row['joined']and row['nativeCorrelated']and row['fixtureRemoved']and row['frontendFixtureRemoved']and removed and all(x.get('scripted')for x in report.get('provider',[]));save();print(json.dumps(row),flush=True);assert row['qualified'],'Retain exact failure; no dependent live attempts'
record['result']='PASS';save();print('PASS_LITERAL_ESCAPE_ALL_FOUR_ZERO_MODEL_CASES',flush=True)
