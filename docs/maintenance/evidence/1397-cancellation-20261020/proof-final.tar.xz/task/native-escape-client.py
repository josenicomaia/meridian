from pathlib import Path
import os,pty,subprocess,json,select,time,fcntl,termios,struct,urllib.request,signal,re,selectors,errno,shutil
out=Path(os.environ['E2E_EVIDENCE_DIR']);out.mkdir();source=Path(os.environ.get('E2E_HARNESS_ROOT','/private/tmp/meridian-pr1397-20261020'));live=os.environ.get('E2E_ALLOW_LIVE_MODEL')=='1';env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']or k.startswith('E2E_')};env['E2E_OUTPUT_FILE']=str(out/'report.json');env['E2E_ROUTING']='active+priority';host=subprocess.Popen(['node',str(source/'scripts/lib/priorityCancellationHost.mjs')]+(['--live']if live else[]),env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);selector=selectors.DefaultSelector();buffers={'stdout':bytearray(),'stderr':bytearray()};eof={'stdout':False,'stderr':False}
for key,pipe in [('stdout',host.stdout),('stderr',host.stderr)]:os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,key)
witness={'scope':'Literal native interactive Escape; actual SDK/native and '+('real Sonnet5.5'if live else'scripted API, ZERO real inference'),'live':live,'hostPID':host.pid,'promptSent':False,'escSent':False,'result':'RUNNING'};ready=None;client=None;master=None;terminalEOF=False;terminal=bytearray();originalGroup=None

def save():(out/'client-witness.json').write_text(json.dumps(witness,indent=2)+'\n')
def pump(timeout=.05):
 global ready
 for key,event in selector.select(timeout):
  data=os.read(key.fileobj.fileno(),65536)
  if not data:eof[key.data]=True;selector.unregister(key.fileobj);continue
  buffers[key.data].extend(data);assert len(buffers[key.data])<4194304,'Bound host diagnostics'
 for line in bytes(buffers['stdout']).decode('utf8','replace').splitlines():
  if line.startswith('{"ready":'):ready=json.loads(line);break
def control(path=''):
 with urllib.request.urlopen(ready['control']+path,timeout=3)as response:return json.load(response)
def status():
 s=control();assert not any(s.get(k)for k in ['refusal','nativeModelMismatch','stopped','includedCapacityRejected']),'Provider/native boundary stopped; preserve original failure with no retry';return s
def pump_terminal(wait=.05):
 global terminalEOF
 if master is None or terminalEOF:return
 if select.select([master],[],[],wait)[0]:
  try:data=os.read(master,65536)
  except OSError as error:
   if error.errno!=errno.EIO:raise
   terminalEOF=True;return
  if not data:terminalEOF=True;return
  terminal.extend(data);assert len(terminal)<4194304,'Bound native terminal output'
  if b'\x1b[6n'in data:os.write(master,b'\x1b[1;1R')
def group_members(group):return[int(x.split()[0])for x in subprocess.check_output(['ps','-axo','pid=,pgid='],text=True).splitlines()if len(x.split())==2 and int(x.split()[1])==group]
def stop_group(process,group):
 if group_members(group):
  try:os.killpg(group,signal.SIGTERM)
  except ProcessLookupError:witness['groupGoneBeforeTERM']=True
 try:process.wait(timeout=5)
 except subprocess.TimeoutExpired:
  try:os.killpg(group,signal.SIGKILL)
  except ProcessLookupError:witness['groupGoneBeforeKILL']=True
  process.wait(timeout=5)
try:
 deadline=time.monotonic()+30
 while ready is None and time.monotonic()<deadline:
  pump();assert host.poll()is None,'Host exited before readiness'
 assert ready,'Host readiness timeout'
 home=out/'client-home';config=out/'client-config';home.mkdir(mode=0o700);config.mkdir(mode=0o700);settings={'hasCompletedOnboarding':True,'theme':'dark','numStartups':1,'projects':{ready['work']:{'hasTrustDialogAccepted':True,'allowedTools':[],'mcpServers':{}}}}
 for path in [home/'.claude.json',config/'.claude.json']:path.write_text(json.dumps(settings));path.chmod(0o600)
 clientEnv={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TMPDIR']};clientEnv.update(HOME=str(home),CLAUDE_CONFIG_DIR=str(config),ANTHROPIC_BASE_URL=ready['proxy'],ANTHROPIC_AUTH_TOKEN='owned-loopback',DISABLE_AUTOUPDATER='1',TERM='xterm-256color')
 master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',32,120,0,0));client=subprocess.Popen([os.environ['E2E_FRONT_NATIVE_BIN'],'--model','claude-sonnet-5-5','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--setting-sources',''],cwd=ready['work'],env=clientEnv,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);originalGroup=client.pid;os.close(slave);witness['originalFrontendPID']=client.pid;trusted=False;deadline=time.monotonic()+90;lastStatus=0
 while time.monotonic()<deadline:
  pump(0);pump_terminal();assert client.poll()is None,'Native frontend exited before Escape observation';clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',terminal.decode('utf8','replace'));compact=clean.replace(' ','').lower()
  if not trusted and 'yes,itrustthisfolder'in compact:os.write(master,b'\x1b[B\r');trusted=True;terminal.clear();continue
  if not witness['promptSent']and ('?forshortcuts'in compact or'Sonnet'in clean)and'entertoconfirm'not in compact:
   os.write(master,b'Derive the complete parametrization and uniqueness theorem for primitive Pythagorean triples, prove all parity, sign and coprimality conditions, and verify twenty examples with full arithmetic. Think carefully through every case. Do not use tools.');time.sleep(.2);os.write(master,b'\r');witness['promptSent']=True;save()
  if not witness['promptSent']or time.monotonic()-lastStatus<.08:continue
  lastStatus=time.monotonic();s=status();foreground=[row for row in s['calls']if row.get('role')=='foreground']
  if not witness['escSent']and any(row.get('thinkingAt')and not row.get('closedAt')for row in foreground):
   control('/cancel');witness['escSentAt']=int(time.time()*1000);os.write(master,b'\x1b');witness['escSent']=True;deadline=time.monotonic()+5;save()
  if witness['escSent']and foreground and all(row.get('closedAt')and row['closedAt']-witness['escSentAt']<=5000 for row in foreground):
   witness['providerBeforeTeardown']=s['calls'];witness['foregroundClosedBeforeTeardown']=True;witness['frontendAliveBeforeTeardown']=client.poll()is None;witness['observationBeforeTeardown']=int(time.time()*1000);break
 assert witness['promptSent']and witness['escSent']and witness.get('foregroundClosedBeforeTeardown')and witness.get('frontendAliveBeforeTeardown'),'Literal Escape did not close foreground provider work before teardown';witness['result']='PASS';save()
except Exception as error:witness['result']='FAIL';witness['failure']=str(error);save()
finally:
 if client is not None:
  stop_group(client,originalGroup);witness['frontendExit']=client.returncode;deadline=time.monotonic()+5
  while not terminalEOF and time.monotonic()<deadline:pump_terminal()
  witness['originalFrontendExited']=client.poll()is not None;witness['originalPtyEOF']=terminalEOF;witness['frontendGroupEmpty']=not group_members(originalGroup)
 if master is not None:os.close(master)
 if ready is not None:
  try:control('/close')
  except Exception as error:witness['hostCloseRequestError']=str(error)
 deadline=time.monotonic()+30
 while time.monotonic()<deadline and(host.poll()is None or not all(eof.values())):pump()
 if host.poll()is None:stop_group(host,host.pid);witness['forcedHostStop']=True
 host.wait(timeout=5);pump(0);witness['hostExit']=host.returncode;witness['originalHostPipesEOF']=all(eof.values());witness['hostGroupEmpty']=not group_members(host.pid);witness['joined']=bool(witness.get('originalFrontendExited')and witness.get('originalPtyEOF')and witness.get('frontendGroupEmpty')and witness['originalHostPipesEOF']and witness['hostGroupEmpty'])
 report=json.loads((out/'report.json').read_text())if(out/'report.json').exists()else{};witness['hostResult']=report.get('result');witness['nativeCorrelated']=report.get('providerOriginalNativeCorrelated');witness['fixtureRemoved']=report.get('fixtureRemoved')
 if not witness['joined']or host.returncode!=0 or report.get('result')!='CLOSED'or not report.get('fixtureRemoved')or(live and not report.get('providerOriginalNativeCorrelated')):witness['result']='FAIL'
 if witness['joined']:
  for name in ['client-home','client-config']:
   path=out/name
   if path.exists():shutil.rmtree(path)
  witness['frontendFixtureRemoved']=True
 (out/'terminal.log').write_bytes(terminal);(out/'host.log').write_bytes(bytes(buffers['stdout'])+b'\n'+bytes(buffers['stderr']));save();print(json.dumps(witness),flush=True)
raise SystemExit(0 if witness['result']=='PASS'else 1)
