from pathlib import Path
import subprocess,json,os,hashlib,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';stage=out/'packages-final';source=Path('/private/tmp/meridian-pr1397-20261020');native=Path('/tmp/meridian-issue-r2-evidence/linux-runtime/node_modules/@anthropic-ai/claude-code-linux-arm64');image='node:24.20.0-bookworm'
assert json.loads((stage/'summary.json').read_text())['result']=='PASS_PACKAGES_READY'
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [out/'qualified-native-host.mjs',out/'cancellation-client.mjs',Path(__file__)]};summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scriptSHA256':seal,'scope':'Actual Linux arm64 Node24/native2.1.301/SDK0.2.141 with owned scripted API; ZERO real inference and no grants','cases':[],'result':'RUNNING','image':image,'nativeSHA256':hashlib.sha256((native/'claude').read_bytes()).hexdigest(),'resourcePolicy':'One owned --rm container per case; no new worktrees or dependency installs. Container tmp fixtures removed on exit.'}
def save():(out/'linux-offline-summary-r2.json').write_text(json.dumps(summary,indent=2)+'\n')
for scenario in ['nonstream','watchdog','subtree','queued']:
 for label in ['baseline','candidate']:
  assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items())
  name='offline-linux-'+scenario+'-'+label+'-r2';target=out/name;assert not target.exists();container='meridian-1397-'+name
  args=['docker','run','--rm','--init','--name',container,'--label','meridian.backlog=1397-cancel-20261020','-v',str(r)+':'+str(r),'-v',str(source)+':'+str(source)+':ro','-v',str(native)+':/native-linux:ro','-e','E2E_MERIDIAN_ROOT='+str(stage/(label+'-linux/node_modules/@rynfar/meridian')),'-e','E2E_HARNESS_ROOT='+str(source),'-e','E2E_NATIVE_BIN=/native-linux/claude','-e','E2E_EVIDENCE_DIR='+str(target),'-e','E2E_CANCEL_CASE='+scenario]
  if scenario=='watchdog':args+=['-e','E2E_WATCHDOG_MS=8000']
  flags=['--baseline']if label=='baseline'else[]
  bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+String.fromCharCode(10));process.execve(process.execPath,[process.execPath,"+json.dumps(str(out/'cancellation-client.mjs'))+",..."+json.dumps(flags)+"],process.env)"
  args+=[image,'node','-e',bootstrap]
  row={'case':name,'container':container,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};summary['cases'].append(row);save()
  with(out/(name+'.log')).open('w')as log:
   process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);row['originalDockerCliPID']=process.pid;save()
   try:code=process.wait(timeout=150)
   except subprocess.TimeoutExpired:
    row['timeout']=True;subprocess.run(['docker','stop','-t','10',container],stdout=log,stderr=subprocess.STDOUT,timeout=20);process.wait(timeout=10);code=process.returncode
  removed=subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE).returncode!=0
  if not removed:subprocess.run(['docker','rm','-f',container],check=True,stdout=subprocess.DEVNULL);row['unexpectedForcedContainerCleanup']=True
  client=json.loads((target/'client-witness.json').read_text())if(target/'client-witness.json').exists()else{};host=json.loads((target/'report.json').read_text())if(target/'report.json').exists()else{};expected='EXPECTED_BASELINE_FAILURE'if label=='baseline'and scenario!='queued'else'PASS'
  row.update(exit=code,result=client.get('result'),failure=client.get('failure'),hostResult=host.get('result'),nativeCorrelated=host.get('providerOriginalNativeCorrelated'),joined=client.get('joined')and host.get('joined'),providerCalls=len(host.get('provider',[])),realGenerations=0,containerRemoved=removed)
  row['qualified']=code==0 and client.get('result')==expected and row['joined'] and host.get('result')=='CLOSED'and row['nativeCorrelated']and removed and all(x.get('scripted')for x in host.get('provider',[]))
  save();print(json.dumps(row),flush=True);assert row['qualified'],'Zero-model failure retained; no dependent live attempts'
summary['result']='PASS';save();print('PASS_ALL_8_ZERO_MODEL_LINUX_CASES',flush=True)
