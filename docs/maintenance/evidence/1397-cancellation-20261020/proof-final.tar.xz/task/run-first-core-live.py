from pathlib import Path
import subprocess,json,hashlib,os,signal,datetime,shutil
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';stage=out/'packages-final';source=Path('/private/tmp/meridian-pr1397-20261020');bun='/tmp/meridian-1399-tooling/node_modules/.bin/bun';grant=r/'private/1397-core-pool-grant.json';guard=r/'private/1397-core-admission.json';attempt=out/'CORE_MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json';holdSHA=hashlib.sha256(hold.read_bytes()).hexdigest();heads=json.loads((r/'1397-final-source.json').read_text());head=heads['head'];assert not attempt.exists() and not grant.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();local=json.loads((r/'1397-final-current-local-exit.json').read_text());assert local['head']==head and all(any(x['label']==name and x['exit']==0 for x in local['commands']) for name in ['focused','typecheck','build']);packages=json.loads((stage/'summary.json').read_text());assert packages['result']=='PASS_PACKAGES_READY' and packages['heads']=={'baseline':heads['base'],'candidate':head};offline=json.loads((out/'qualified-offline-summary.json').read_text());assert offline['result']=='PASS' and len(offline['cases'])==8;assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in offline['scriptSHA256'].items())
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'qualified-native-host.mjs',out/'cancellation-client.mjs',out/'create-core-pool-grant.mjs',Path(__file__)]};record={'task':'1397-core-cancellation-sonnet55','head':head,'baseline':heads['base'],'cases':[],'result':'RUNNING','scriptSHA256':seal,'historicalAttempt':'OriginaloldrecordercrashretainsUNKNOWNmodelcount/upstreammethod. ExactabortedHEAD0modelcausalcontrolpassed. Thisnewstrictcontrolledbaseline/candidatecomparison doesnotclaimoldexternalrefusal/quota/modelcausefixed.','poolScope':'Two distinct realpaid-disabledownedaccounts; onlyTeamAcanforwardinference. WeeklyspentpersonalsparedeniedbeforeAPI. No twohealthyaccount/failover/recoveryclaim.'}
def save():(out/'first-core-live-task.json').write_text(json.dumps(record,indent=2)+'\n')
def check_seal():
 assert hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items())
def group_members(group):
 rows=subprocess.check_output(['ps','-axo','pid=,pgid='],text=True).splitlines();return[int(x.split()[0])for x in rows if len(x.split())==2 and int(x.split()[1])==group]
def stop_group(process,row):
 members=group_members(process.pid)
 if members:
  row['ownedProcessGroupCleanup']=members
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:row['ownedGroupGoneBeforeTERM']=True
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:row['ownedGroupGoneBeforeKILL']=True
   process.wait(timeout=5)
try:
 for scenario in ['nonstream','watchdog']:
  for label in ['baseline','candidate']:
   assert len(record['cases'])<4;check_seal();name='live-mac-'+scenario+'-'+label+'-r1';target=out/name;assert not target.exists()
   subprocess.run([bun,str(out/'create-core-pool-grant.mjs')],cwd=source,env=dict(os.environ,E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1'),check=True)
   admission=json.loads(guard.read_text());assert admission['includedCapacityKnown']is False and admission['maximumCases']==4
   if not attempt.exists():attempt.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':record['task'],'head':head,'baseline':heads['base'],'scripts':seal,'firstAdmission':admission,'olderHoldsSHA256':holdSHA},indent=2)+'\n')
   row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admission':admission};record['cases'].append(row);save()
   env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(E2E_MERIDIAN_ROOT=str(stage/(label+'-mac/node_modules/@rynfar/meridian')),E2E_HARNESS_ROOT=str(source),E2E_NATIVE_BIN='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302',E2E_EVIDENCE_DIR=str(target),E2E_CANCEL_CASE=scenario,E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard))
   if scenario=='watchdog':env['E2E_WATCHDOG_MS']='8000'
   args=['node',str(out/'cancellation-client.mjs'),'--live']+(['--baseline']if label=='baseline'else[])
   with(out/(name+'.log')).open('w')as log:
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['originalControllerPID']=process.pid;save()
    try:code=process.wait(timeout=150)
    except subprocess.TimeoutExpired:row['timeout']=True;stop_group(process,row);code=process.returncode
   client=json.loads((target/'client-witness.json').read_text())if(target/'client-witness.json').exists()else{};host=json.loads((target/'report.json').read_text())if(target/'report.json').exists()else{};members=group_members(process.pid)
   if members:stop_group(process,row)
   row.update(exit=code,result=client.get('result'),failure=client.get('failure'),hostResult=host.get('result'),generations=len(host.get('provider',[])),officialForwards=host.get('officialForwards',0),joined=client.get('joined')and host.get('joined'),correlated=host.get('providerOriginalNativeCorrelated'),profiles=sorted(set(p.get('profileId')for p in host.get('provider',[]))),qualified=code==0 and client.get('result')==('EXPECTED_BASELINE_FAILURE'if label=='baseline'else'PASS') and host.get('result')=='CLOSED' and client.get('joined') and host.get('joined') and host.get('providerOriginalNativeCorrelated') and host.get('officialForwards',0)>=len(host.get('provider',[]))>0 and all(p.get('profileId')=='pool-a'and p.get('responseModel')=='claude-sonnet-5-5'and not p.get('scripted')for p in host.get('provider',[])) and not members)
   save();print(json.dumps({k:v for k,v in row.items() if k!='admission'}),flush=True);check_seal();assert row['qualified'],'Actual failure/inconclusive case retained; stop dependent work, no blind model/account/workload retry'
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['olderHoldsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'olderHoldsUnchanged':record['olderHoldsUnchanged']}),flush=True)
