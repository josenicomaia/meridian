from pathlib import Path
r=Path('/tmp/meridian-resume-20261020');d=r/'1397-live-r2';s=(r/'priority-cancel/native-live-host.mjs').read_text()
def replace(old,new):
 global s
 assert old in s,old[:100];s=s.replace(old,new)
replace("{syncBuiltinESMExports} from 'node:module'","{syncBuiltinESMExports,createRequire} from 'node:module'")
replace("const report={scope:","const harnessRoot=resolve(process.env.E2E_HARNESS_ROOT??repo);const {validateProfileHistoryAdmission}=await import(pathToFileURL(join(harnessRoot,'scripts/lib/profileHistoryAdmission.mjs')));\nconst report={scope:")
replace("let stopped=false,profiles;","let stopped=false,profiles,admission;const persist=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\\n');")
start=s.index('if(live){assert.equal(');end=s.index('\nconst watchdog=',start)
s=s[:start]+'''if(live){
 assert.equal(process.env.E2E_ALLOW_LIVE_MODEL,'1');const grant=process.env.E2E_LIVE_PROFILE_FILE;assert.equal(statSync(grant).mode&0o077,0);profiles=JSON.parse(readFileSync(grant));assert(profiles.length===2&&profiles.every(p=>p.type==='oauth-token'&&p.oauthToken&&!p.refreshToken));assert.notEqual(profiles[0].oauthToken,profiles[1].oauthToken);
 admission=JSON.parse(readFileSync(process.env.E2E_USAGE_GUARD_FILE));report.admission=validateProfileHistoryAdmission(admission);assert.equal(admission.distinctAccounts,2);assert.deepEqual(admission.permittedInferenceProfileIds,['pool-a']);assert.equal(admission.knownSpentSpareProfileId,'pool-b');report.pool={distinctRealAccounts:2,permittedInferenceProfileIds:admission.permittedInferenceProfileIds,knownSpentSpareProfileId:'pool-b',scope:'OnlyTeamactualinference; exhaustedpersonalsparecannotforward. No twohealthyaccount/failover/quota-recovery claim.'};
}
''' +s[end:]
replace("MERIDIAN_SHUTDOWN_GRACE_MS:'3000'","MERIDIAN_SHUTDOWN_GRACE_MS:'3000',MERIDIAN_SONNET_MODEL:'sonnet'")
replace("const row={pid:child.pid,closed:false,stdoutClosed:!child.stdout,stderrClosed:!child.stderr};report.actors.push(row)","const options=Array.isArray(args[1])?args[2]:args[1];const row={pid:child.pid,closed:false,stdoutClosed:!child.stdout,stderrClosed:!child.stderr,nativeNamespace:options?.env?.CLAUDE_CONFIG_DIR??null};report.actors.push(row);persist()")
replace("if(entry){report.nativeModels.push({...entry,pid:child.pid,session:value.session_id});if(typeof entry.model==='string'&&entry.model.replace(/\\[1m\\]$/,'')!==model){report.nativeModelMismatch=true;stopped=true}}","if(entry){entry.synthetic=entry.model==='<synthetic>';report.nativeModels.push({...entry,pid:child.pid,session:value.session_id});if(typeof entry.model==='string'&&!entry.synthetic&&entry.model.replace(/\\[1m\\]$/,'')!==model){report.nativeModelMismatch=true;stopped=true;for(const c of upstreamControllers)c.abort()}persist()}")
replace("if(info.isUsingOverage===true){stopped=true;report.overageObserved=true;for(const controller of upstreamControllers)controller.abort()}","if(info.isUsingOverage===true||info.status==='rejected'){stopped=true;report.overageObserved=info.isUsingOverage===true;report.includedCapacityRejected=info.status==='rejected';for(const controller of upstreamControllers)controller.abort()}persist()")
replace("const chunks=[];for await(const chunk of req)chunks.push(chunk)","transport={method:req.method,localPath:req.url,receivedAt:Date.now()};report.upstreamRequests.push(transport);persist();const chunks=[];for await(const chunk of req)chunks.push(chunk)")
replace("assert.equal(url.origin,'https://api.anthropic.com')\n  transport={method:req.method,path:url.pathname};report.upstreamRequests.push(transport)","assert.equal(url.origin,'https://api.anthropic.com');const channel=url.pathname.match(/^\\/native\\/(\\d+)(\\/.*)$/);if(channel){transport.nativePID=Number(channel[1]);url.pathname=channel[2]}transport.path=url.pathname;persist()")
replace("row={turn:turns.length?Math.max(...turns):null,role:text.includes('Write the title in')?'title':'foreground'", "row={nativePID:transport.nativePID,turn:turns.length?Math.max(...turns):null,role:text.includes('Write the title in')?'title':text.includes('OWNED_CHILD_')?'child':text.includes('OWNED_PARENT_')?'parent':'foreground'")
replace("report.provider.length>=4","report.provider.length>=(report.admission?.maximumGenerations??4)")
replace("report.provider.push(row)","assert(report.actors.some(actor=>actor.pid===row.nativePID),'Generation did not come from an original observed native process');if(live&&!admission.permittedInferenceProfileIds.includes(row.profileId)){stopped=true;report.spentSpareSelectionDenied=true;transport.deniedBeforeOfficialForward=true;persist();res.writeHead(400);res.end('Owned known-spent-spare inference boundary');return}report.provider.push(row);persist()")
replace("Object.assign(row,{responseId:message.id,responseModel:message.model,thinkingAt:Date.now()});","Object.assign(row,{status:200,responseId:message.id,responseModel:message.model,thinkingAt:Date.now(),scripted:true});persist();")
replace("const response=await fetch(url,", "if(row){row.forwardedAt=Date.now();report.officialForwards=(report.officialForwards??0)+1;persist()}const response=await fetch(url,")
replace("row&&(row.status=response.status)","row&&(Object.assign(row,{status:response.status,providerRequestId:response.headers.get('request-id')??response.headers.get('x-request-id')}));persist()")
replace("row.responseId=event.message?.id;assert.equal(row.responseModel,model)","row.responseId=event.message?.id;assert.equal(row.responseModel,model);persist()")
replace("answer+=event.delta.text;assert(answer.length<1048576)","answer+=event.delta.text;assert(answer.length<1048576);row.textBytes=(row.textBytes??0)+Buffer.byteLength(event.delta.text);row.lastTextAt=Date.now();persist()")
replace("if(event.type==='message_delta'&&event.delta?.stop_reason)","persist();if(event.type==='error'){stopped=true;report.providerInBandError=event.error?.type??'unknown'}if(event.type==='message_delta'&&event.delta?.stop_reason)")
replace("if(row)row.answerHasCanary=answer.includes(nonce);res.end()","if(row)row.answerHasCanary=answer.includes(nonce);persist();res.end()")
replace("row.closedAt=Date.now();row.cancelled=!res.writableFinished","row.closedAt=Date.now();row.cancelled=!res.writableFinished;persist()")
replace("row.expectedOwnedAbort=true;return","row.expectedOwnedAbort=true;persist();return")
replace("if(transport)transport.clientCancelled=true;return","if(transport)transport.clientCancelled=true;persist();return")
replace("if(transport)transport.failed=true;if(!res.headersSent)","if(transport)transport.failed=true;persist();if(!res.headersSent)")
replace("ANTHROPIC_BASE_URL:'+JSON.stringify(`http://127.0.0.1:${upstream.address().port}`)+'}","ANTHROPIC_BASE_URL:'+JSON.stringify(`http://127.0.0.1:${upstream.address().port}`)+'+\"/native/\"+process.pid}")
replace("defaultProfile:profiles[0].id}","defaultProfile:profiles[0].id,maxConcurrent:Number(process.env.E2E_MAX_CONCURRENT??4)}")
replace("if(req.url==='/close'){res.end('{}');await close();return}","if(req.url==='/close'){res.end('{}');await close();return}if(req.url==='/inflight'){res.end(JSON.stringify(await(await fetch(proxyURL+'/inflight',{signal:AbortSignal.timeout(3000)})).json()));return}")
replace("nativeModelMismatch:report.nativeModelMismatch??false}","nativeModelMismatch:report.nativeModelMismatch??false,haltReason:report.upstreamFailure??null,includedCapacityRejected:report.includedCapacityRejected??false}")
replace("report.joined=report.actors.every",'''report.publicSdkHistory=[];
 try{
  const require=createRequire(join(repo,'package.json')),sdk=await import(pathToFileURL(require.resolve('@anthropic-ai/claude-agent-sdk')));const previous=process.env.CLAUDE_CONFIG_DIR;
  try{for(const nativeRow of report.nativeModels.filter(row=>row.type==='init'&&row.session)){
   const actor=report.actors.find(row=>row.pid===nativeRow.pid);if(!actor?.nativeNamespace)continue;assert(resolve(actor.nativeNamespace).startsWith(root+'/'));process.env.CLAUDE_CONFIG_DIR=actor.nativeNamespace;
   const info=await sdk.getSessionInfo(nativeRow.session);const metadata={nativePID:nativeRow.pid,session:nativeRow.session,exists:!!info,rows:[]};
   if(info?.cwd){assert(resolve(info.cwd).startsWith(root+'/'));metadata.rows=(await sdk.getSessionMessages(nativeRow.session,{dir:info.cwd})).map(row=>({type:row.type,id:row.message?.id,model:row.message?.model,synthetic:row.message?.model==='<synthetic>'}))}report.publicSdkHistory.push(metadata)
  }}finally{if(previous===undefined)delete process.env.CLAUDE_CONFIG_DIR;else process.env.CLAUDE_CONFIG_DIR=previous}
 }catch(error){report.publicSdkHistoryFailure={name:error.name,message:String(error.message).slice(0,300)}}
 report.providerOriginalNativeCorrelated=report.provider.every(row=>row.status===200&&row.responseModel===model&&typeof row.responseId==='string'&&report.nativeModels.some(nativeRow=>nativeRow.pid===row.nativePID&&nativeRow.type==='init'&&nativeRow.model?.replace(/\\[1m\\]$/,'')===model));
 report.cancelledMessageLimit='Interrupted SDK sessions may have no completed public assistant record. Provider response/model and exact original nativePID/init are required; public SDK history is retained where available. No synthetic assistant is model evidence.';
 report.joined=report.actors.every''')
replace("!report.credentialMismatch?'CLOSED':'FAIL'","!report.credentialMismatch&&!report.upstreamFailure&&!report.includedCapacityRejected&&!report.spentSpareSelectionDenied&&!report.providerInBandError&&(!live||report.providerOriginalNativeCorrelated)?'CLOSED':'FAIL'")
(d/'qualified-native-host.mjs').write_text(s)
print('Prepared qualified host with original-PID channels, continuous metadata journal, paid-disabled truthful admission and exhausted-spare deny-before-forward')
