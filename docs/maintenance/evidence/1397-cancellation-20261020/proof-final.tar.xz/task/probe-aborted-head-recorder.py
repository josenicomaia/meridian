from pathlib import Path
import os,subprocess,json,socket,select,re,time,urllib.request,datetime
r=Path('/tmp/meridian-resume-20261020');out=r/'1397-live-r2';summary={'scope':'Exact supplemental recorder aborted-HEAD causal control; ZERO model calls, no grants or credentials','cases':[],'result':'RUNNING'}
for mode,file in [('old','native-live-host.before-scope-fix.mjs'),('fixed','native-live-host.mjs')]:
 target=out/('head-abort-'+mode+'-r1');target.mkdir();env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(E2E_OUTPUT_FILE=str(target/'report.json'),E2E_MERIDIAN_ROOT='/private/tmp/meridian-main-1401-post1406-20261020',E2E_NATIVE_BIN='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302',E2E_ROUTING='active+priority');ready=None;errors=[]
 with(target/'host.log').open('w')as log:
  host=subprocess.Popen(['node',str(r/'priority-cancel'/file)],env=env,stdout=subprocess.PIPE,stderr=log,text=True)
  try:
   deadline=time.monotonic()+20
   while time.monotonic()<deadline:
    if select.select([host.stdout],[],[],.2)[0]:
     line=host.stdout.readline()
     if line.startswith('{"ready":'):ready=json.loads(line);break
    assert host.poll() is None,'Host exited before readiness'
   assert ready,'Bounded host readiness failed'
   relay=(Path(ready['root'])/'native-relay.cjs').read_text();match=re.search(r'ANTHROPIC_BASE_URL:"(http://127\.0\.0\.1:(\d+))"',relay);assert match
   peer=socket.create_connection(('127.0.0.1',int(match[2])),timeout=3);peer.sendall(b'HEAD /api/hello HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: 100\r\n\r\nx');time.sleep(.05);peer.shutdown(socket.SHUT_RDWR);peer.close();time.sleep(.2)
   if mode=='old':host.wait(timeout=5);assert host.returncode!=0
   else:
    current=json.load(urllib.request.urlopen(ready['control'],timeout=3));assert current['calls']==[] and current['stopped'] is False;urllib.request.urlopen(ready['control']+'/close',timeout=10).read();host.wait(timeout=10);assert host.returncode==0
  finally:
   if host.poll() is None:
    host.terminate()
    try:host.wait(timeout=10)
    except subprocess.TimeoutExpired:host.kill();host.wait(timeout=5);errors.append('forcedOwnHostStop')
   residual=host.stdout.read();host.stdout.close()
 logtext=(target/'host.log').read_text();row={'mode':mode,'ownHostPID':host.pid,'exit':host.returncode,'hostAndPipesJoined':True,'realModelCalls':0,'errors':errors,'upstream':'OwnedpartialHEADthenpeerclose, no external forwarding or SDKquery'}
 if mode=='old':assert 'ReferenceError: row is not defined'in logtext;row['causalRed']='Aborted local HEAD enters catch then out-of-scope row crashes recorder before HEAD cancellation handling'
 else:
  report=json.loads((target/'report.json').read_text());assert report['joined'] and not report['provider'] and report['result']=='CLOSED';row['causalGreen']='Same original aborted HEAD handled, control remains responsive, original proxy closes with no SDK/model actors'
 summary['cases'].append(row);(out/'aborted-head-recorder-control.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(row),flush=True)
summary['result']='PASS';summary['historicalLimit']='Original failed live attempt did not persist its upstream method/status/completion. Its model-call count remains UNKNOWN. This reproduces the exact recorder crash branch without inference; does not claim original external quota/model behavior recovered.';(out/'aborted-head-recorder-control.json').write_text(json.dumps(summary,indent=2)+'\n')
