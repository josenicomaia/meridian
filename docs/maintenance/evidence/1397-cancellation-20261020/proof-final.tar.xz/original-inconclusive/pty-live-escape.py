import re,os,pty,subprocess,json,pathlib,select,time,fcntl,termios,struct,urllib.request,sys,signal
r=pathlib.Path('/tmp/meridian-resume-20261020');out=r/'1397-native-live-escape-mac-r1';out.mkdir();env={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','TERM','TMPDIR')};env.update(E2E_OUTPUT_FILE=str(out/'report.json'),E2E_MERIDIAN_ROOT='/private/tmp/meridian-pr1397-20261020',E2E_NATIVE_BIN='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302',E2E_ROUTING='active+priority',E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(r/'private/grant-pool.json'),E2E_USAGE_GUARD_FILE=str(r/'private/pool-usage-guard.json'))
log=(out/'host.log').open('w');host=subprocess.Popen(['node',str(r/'priority-cancel/native-live-host.mjs'),'--live'],env=env,stdout=subprocess.PIPE,stderr=log,text=True);ready=None;client=None;master=None
try:
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  line=host.stdout.readline()
  if line.startswith('{"ready":'):ready=json.loads(line);break
  if host.poll() is not None:raise RuntimeError('Host exited before ready')
 assert ready
 home=out/'client-home';config=out/'client-config';home.mkdir();config.mkdir()
 settings={'hasCompletedOnboarding':True,'theme':'dark','numStartups':1,'projects':{ready['work']:{'hasTrustDialogAccepted':True,'allowedTools':[],'mcpServers':{}}}}
 for p in (home/'.claude.json',config/'.claude.json'):p.write_text(json.dumps(settings))
 client_env={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','TMPDIR')};client_env.update(HOME=str(home),CLAUDE_CONFIG_DIR=str(config),ANTHROPIC_BASE_URL=ready['proxy'],ANTHROPIC_AUTH_TOKEN='owned-loopback',DISABLE_AUTOUPDATER='1',TERM='xterm-256color')
 master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',32,120,0,0))
 client=subprocess.Popen(['/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302','--model','claude-sonnet-5-5','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--setting-sources',''],cwd=ready['work'],env=client_env,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave);data=b'';deadline=time.monotonic()+90;sent=False;esc=False;trusted=False
 with (out/'terminal.log').open('wb') as terminal:
  while time.monotonic()<deadline and client.poll() is None:
   if select.select([master],[],[],.1)[0]:
    try:b=os.read(master,65536)
    except OSError:break
    data+=b;terminal.write(b);terminal.flush()
    if b'\x1b[6n' in b:os.write(master,b'\x1b[1;1R')
   clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',data.decode('utf8','replace'));compact=clean.replace(' ','').lower()
   if not trusted and 'yes,itrustthisfolder' in compact:
    os.write(master,b'\x1b[B\r');trusted=True;data=b'';continue
   if not sent and ('?forshortcuts' in compact or 'Sonnet' in clean) and 'entertoconfirm' not in compact:
    os.write(master,b'Analyze the integer equation x squared plus y squared equals z squared carefully. Give a detailed proof of the complete parametrization of primitive Pythagorean triples, including necessity, uniqueness and six verified examples. Think carefully through every edge case. Do not use tools.');time.sleep(.2);os.write(master,b'\r');sent=True
   if sent and not esc:
    status=json.load(urllib.request.urlopen(ready['control']));
    assert not status.get('refusal') and not status.get('nativeModelMismatch') and not status.get('stopped'),'Model boundary stopped; no retry'
    if any(row.get('role')=='foreground' and row.get('thinkingAt') for row in status['calls']):
     urllib.request.urlopen(ready['control']+'/cancel').read();os.write(master,b'\x1b');esc=True;deadline=time.monotonic()+8
   if esc:
    status=json.load(urllib.request.urlopen(ready['control']))
    if any(x.get('role')=='foreground' for x in status['calls']) and all(x.get('closedAt') is not None for x in status['calls'] if x.get('role')=='foreground'):break
 print(json.dumps({'promptSent':sent,'escSent':esc,'clientExit':client.poll(),'terminalBytes':len(data)}))
finally:
 if client and client.poll() is None:
  client.send_signal(signal.SIGTERM)
  try:client.wait(timeout=5)
  except subprocess.TimeoutExpired:client.kill();client.wait()
 if master is not None:os.close(master)
 if ready:
  try:urllib.request.urlopen(ready['control']+'/close',timeout=15).read()
  except Exception:pass
 try:host.wait(timeout=20)
 except subprocess.TimeoutExpired:host.terminate();host.wait(timeout=10)
 log.close()
 (r/'private/grant-pool.json').unlink(missing_ok=True)

d=json.loads((out/'report.json').read_text());foreground=[row for row in d['provider'] if row.get('role')=='foreground'];assert foreground and d['cancelSentAt'] and all(row['closedAt'] is not None and row['closedAt']-d['cancelSentAt']<=5000 for row in foreground);assert d['joined'];print(json.dumps({'result':'PASS','scope':'interactive Escape stops foreground turn; native title request is independent','foregroundClosedAfterMs':[row['closedAt']-d['cancelSentAt'] for row in foreground],'joined':d['joined']}))
