from pathlib import Path
import subprocess,json,hashlib,os,datetime,socket,shutil,signal
r=Path('/tmp/meridian-resume-20261020');out=Path('/tmp/meridian-release185-evidence-20261021');source=Path('/private/tmp/meridian-release185-20261021');qualified=out/'qualified-e41';grant=r/'private/release185-e41-r2-pool-grant.json';guard=r/'private/release185-e41-r2-admission.json';attempt=out/'e41-r2-MODEL_ATTEMPT.json';creator=out/'create-e41-r2-pool-grant.mjs';hold=r/'LIVE_MODEL_HOLD.json';holdSHA=hashlib.sha256(hold.read_bytes()).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert not attempt.exists()and not grant.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
local=json.loads((out/'final-r3-local.json').read_text());assert local['head']==head and all(any(x['name']==label and x['exit']==0 for x in local['commands'])for label in ['typecheck','build']);seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [*qualified.glob('*.mjs'),creator,Path(__file__)]};record={'task':'release185-e41-sonnet55-after-scheduled-reset','head':head,'base':'8914cfad05dc274e78313cd9cbe3a2bb14923231','scriptSHA256':seal,'cases':[],'result':'RUNNING','scope':'Explicit SQL backend plus all four original E41 assertions, actual Sonnet5.5/SDK0.2.141/native2.1.302, V1 client plugin and scrub0.2.3, Macarm64; protocol host, not OpenCode executable','localFullStatusAtStart':local.get('exit'), 'localFullIsStillMergeGate':True,'resourcePolicy':'Current source/deps reused, no new installs/worktrees. Only sanitized report/model metadata retained; all joined fixture homes removed.'}
def save():(out/'e41-source-r2-task.json').write_text(json.dumps(record,indent=2)+'\n')
def check():
 assert hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in seal.items())
def wait_host(process,row):
 try: return process.wait(timeout=240)
 except subprocess.TimeoutExpired:
  row['timeout']=True
  try: os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError: row['groupGoneBeforeTERM']=True
  try: return process.wait(timeout=10)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL)
   return process.wait(timeout=10)
try:
 for mode in ['chain-json','chain-stream','parallel-json','parallel-stream']:
  check();assert len(record['cases'])<4;name='e41-'+mode+'-release-sonnet55-r2';target=out/name;assert not target.exists();target.mkdir()
  for directory in ['home','native-config']:(target/directory).mkdir(mode=0o700)
  subprocess.run(['/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun',str(creator)],cwd=source,env=dict(os.environ,E2E_PHASE='e41',E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1'),check=True);admission=json.loads(guard.read_text());assert admission['maximumCases']==6 and admission['maximumGenerationsPerCase']==12 and admission['distinctAccounts']==1
  if not attempt.exists():attempt.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':record['task'],'head':head,'scripts':seal,'firstAdmission':admission,'olderHoldsSHA256':holdSHA},indent=2)+'\n')
  sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(BOOKKEEPING_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',HOME=str(target/'home'),CLAUDE_CONFIG_DIR=str(target/'native-config'),MERIDIAN_CLAUDE_PATH='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302',MERIDIAN_CREDENTIALS_READONLY='1',MERIDIAN_NO_UPDATE_CHECK='1',E2E_MERIDIAN_ROOT=str(source),E2E_MODEL_WITNESS=str(target/'model-witness.json'),E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard),E2E_PLUGIN_PATH='/tmp/meridian-issue-r2-evidence/linux-runtime/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js',E2E_SCRUB_VERSION='0.2.3',E2E_CLIENT_PLUGIN_PATH=str(source/'dist/meridian/index.js'),E2E_CLIENT_VERSION='1.85.0',PROBE_MODEL='claude-sonnet-5-5',PROBE_PARALLEL='1'if mode.startswith('parallel')else'0',PROBE_TURNS='6',PROBE_PORT=str(port))
  row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admission':admission};record['cases'].append(row);save()
  with(target/'run.log').open('w')as log:process=subprocess.Popen(['/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun','--preload',str(source/'src/__tests__/fixtures/bookkeeping-engine-preload.mjs'),str(qualified/'run-e41.mjs')]+(['--stream']if mode.endswith('stream')else[]),cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['originalControllerPID']=process.pid;save();code=wait_host(process,row)
  lines=(target/'run.log').read_text().splitlines();result=next((json.loads(line)for line in reversed(lines)if line.startswith('{"root":')),None);report={}
  if result:report=json.loads((Path(result['root'])/'qualified-e41-report.json').read_text());(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  witness=json.loads((target/'model-witness.json').read_text())if(target/'model-witness.json').exists()else{};identities=[]
  for provider in witness.get('provider',[]):
   for event in provider.get('events',[]):
    if event.get('type')!='message_start':continue
    query=provider['query'];model=event.get('model');identity={'query':query,'providerID':event.get('id'),'model':model,'status':provider.get('status'),'child':any(c['query']==query and c.get('closed')and isinstance(c.get('pid'),int)for c in witness['children']),'nativeInit':any(n['query']==query and n.get('type')=='init'and n.get('model','').replace('[1m]','')==model for n in witness['native']),'nativeMessage':any(n['query']==query and n.get('id')==event.get('id')and n.get('model')==model for n in witness['native']),'publicStored':any(n.get('id')==event.get('id')and n.get('model')==model for store in witness['stored']for n in store['rows'])};identities.append(identity)
  (target/'identity-correlation.json').write_text(json.dumps(identities,indent=2)+'\n');generations=witness.get('generationCount',0);correlated=len(identities)==generations>0 and all(x['status']==200 and x['model']=='claude-sonnet-5-5'and x['child']and x['nativeInit']and x['nativeMessage']and x['publicStored']for x in identities)
  row.update(cacheClear=report.get('cacheClear'),bookkeeping=report.get('bookkeeping'),exit=code,result=result,originalAssertions=report.get('result'),generations=generations,realForwards=witness.get('realForwards',0),joined=report.get('joined'),correlated=correlated,stopped=witness.get('stopped'))
  row['qualified']=all(report.get('cacheClear',{}).get(k) is True for k in ['completionPromise','durableMappingsCleared','freshSession','originalHistoryUnchanged']) and report.get('bookkeeping',{}).get('backend')=='sqlite' and report.get('bookkeeping',{}).get('engine',{}).get('version')=='3.53.4' and code==0 and result and result.get('result')=='PASS'and report.get('result')=='PASS'and row['joined']and correlated and witness.get('closed')and not witness.get('stopped')and witness.get('realForwards')==generations and 0<generations<=12
  save();print(json.dumps({k:v for k,v in row.items()if k!='admission'}),flush=True);check();assert row['qualified'],'Retain exact failure; no further models/account/workload retry'
  root=Path(result['root']);assert root.name.startswith('meridian-probe-proxy-')and root.is_dir()and not root.is_symlink();shutil.rmtree(root)
  for directory in ['home','native-config']:shutil.rmtree(target/directory)
  row['fixtureRemoved']=not root.exists();save()
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['olderHoldsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==holdSHA
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'olderHoldsUnchanged':record['olderHoldsUnchanged']}),flush=True)
