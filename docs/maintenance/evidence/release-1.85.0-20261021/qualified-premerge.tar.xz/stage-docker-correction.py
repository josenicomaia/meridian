from pathlib import Path
import subprocess,os,json,hashlib
r=Path('/private/tmp/meridian-release185-20261021');o=Path('/tmp/meridian-release185-evidence-20261021');base='71c4258df0e1b140264c300906c1b48330d7d725';branch='release-please--branches--main--components--meridian'
def git(*args,input=None,env=None):return subprocess.check_output(['git',*args],cwd=r,input=input,env=env)
assert git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain')
assert git('ls-remote','origin','refs/heads/'+branch).decode().split()[0]==base
config=(r/'docs/configuration.md').read_text();needle='The npm entry is `dist/session-bookkeeping.js`; this is not a proxy request endpoint.';assert needle in config;config=config.replace(needle,needle+'\nDocker images include `/app/dist/session-bookkeeping.js`; invoke it with\n`--entrypoint node` and the same private session-directory mount while writers\nare stopped. Use a supported local filesystem for that mount; the container\nwritable overlay is not a supported SQLite data directory.');(o/'configuration-with-docker-cli.md').write_text(config)
changelog=(r/'CHANGELOG.md').read_text();needle='### Bug Fixes\n\n';assert needle in changelog;changelog=changelog.replace(needle,needle+'* **docker:** include the session bookkeeping maintenance CLI and verify migration, awaited cleanup and export in the runtime image.\n',1);(o/'CHANGELOG-with-docker-cli.md').write_text(changelog)
mapping={'Dockerfile':o/'Dockerfile-qualified','.github/workflows/docker.yml':o/'docker-workflow-with-gate.yml','scripts/fixtures/docker-bookkeeping-smoke.mjs':o/'docker-bookkeeping-smoke.mjs','docs/configuration.md':o/'configuration-with-docker-cli.md','CHANGELOG.md':o/'CHANGELOG-with-docker-cli.md'}
index=o/'docker-correction-index';assert not index.exists();env=dict(os.environ,GIT_INDEX_FILE=str(index));git('read-tree',base,env=env);rows=[]
try:
 for name,path in mapping.items():
  data=path.read_bytes();blob=git('hash-object','-w','--stdin',input=data).decode().strip();git('update-index','--add','--cacheinfo','100644,'+blob+','+name,env=env);rows.append({'path':name,'blob':blob,'sha256':hashlib.sha256(data).hexdigest()})
 tree=git('write-tree',env=env).decode().strip();message=o/'docker-correction-message.txt';message.write_text('fix(docker): include the bookkeeping maintenance CLI\n');commit=git('commit-tree','-S',tree,'-p',base,'-F',str(message)).decode().strip();git('push','origin',commit+':refs/heads/'+branch);assert git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain');(o/'docker-correction-push.json').write_text(json.dumps({'base':base,'head':commit,'files':rows,'frozenLocalHeadUnchanged':True},indent=2)+'\n');print(json.dumps({'base':base,'newReleaseHead':commit,'frozenLocalHeadUnchanged':True}))
finally:index.unlink(missing_ok=True)
