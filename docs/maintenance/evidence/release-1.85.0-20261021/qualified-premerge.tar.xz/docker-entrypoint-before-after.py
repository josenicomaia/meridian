from pathlib import Path
import subprocess,json,os
r=Path('/private/tmp/meridian-release185-20261021');o=Path('/tmp/meridian-release185-evidence-20261021');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
for label,entries in [('before',['bin/cli.ts','src/proxy/server.ts','plugin/meridian-v2.ts']),('after',['bin/cli.ts','bin/session-bookkeeping.ts','src/proxy/server.ts','plugin/meridian-v2.ts'])]:
 target=o/('docker-entry-'+label);target.mkdir();(target/'package.json').write_bytes((r/'package.json').read_bytes());(target/'node_modules').symlink_to(r/'node_modules',target_is_directory=True)
 command=[bun,'build',*entries,'--outdir',str(target/'dist'),'--target','node','--splitting','--external','@anthropic-ai/claude-agent-sdk','--external','libsql','--external','jsonc-parser','--entry-naming','[name].js']
 with(o/('docker-entry-'+label+'-build.log')).open('w')as log:subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 with(o/('docker-entry-'+label+'-gate.log')).open('w')as log:result=subprocess.run(['node',str(o/'docker-bookkeeping-smoke.mjs'),str(target)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 log=(o/('docker-entry-'+label+'-gate.log')).read_text();expected=0 if label=='after'else 1;assert result.returncode==expected,(label,log)
 if label=='before':assert 'MODULE_NOT_FOUND'in log and 'session-bookkeeping.js'in log
 else:assert '"result":"PASS"'in log
 rows.append({'label':label,'entryExists':(target/'dist/session-bookkeeping.js').exists(),'exit':result.returncode})
(o/'docker-entrypoint-controls.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'rows':rows,'models':0,'scope':'Exact first Dockerfile bundle command under Bun1.4.3, actual Node22.22.3/Darwin; actual Linux image gate still required in CI'},indent=2)+'\n');print(json.dumps(rows))
