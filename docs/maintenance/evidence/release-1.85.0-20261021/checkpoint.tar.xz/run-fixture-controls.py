from pathlib import Path
import subprocess,os,json,hashlib
r=Path('/private/tmp/meridian-release185-20261021');o=Path('/tmp/meridian-release185-evidence-20261021');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');rows=[]
store=r/'src/proxy/sessionStore.ts';migration=r/'src/proxy/session/bookkeeping/migration.ts';test=r/'src/__tests__/bookkeeping-migration.test.ts';three=r/'src/__tests__/fixtures/bookkeeping-three-process.ts';original={p:p.read_bytes()for p in [store,migration,test,three]}
def run(name,file,pattern,expected,contains=None):
 with(o/(name+'.log')).open('w')as log:result=subprocess.run([bun,'test','--timeout','30000','--test-name-pattern',pattern,file],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(o/(name+'.log')).read_text();assert result.returncode==expected,(name,result.returncode,text)
 if contains:assert contains in text,(name,text)
 rows.append({'control':name,'exit':result.returncode});print(json.dumps(rows[-1]),flush=True)
try:
 s=original[store].decode();needle='  const deadline = performance.now() + waitMs\n';assert needle in s;s=s.replace(needle,needle+'  if (existsSync(lockPath)) sleepSync(150) // controlled loss of legacy recovery budget\n',1);store.write_text(s)
 test.write_bytes((o/'bookkeeping-migration-before.ts').read_bytes());run('missing-source-old-with-recovery-budget-loss','src/__tests__/bookkeeping-migration.test.ts','disappears after PREPARED',1,'timed out waiting for lock')
 test.write_bytes(original[test]);run('missing-source-isolated-with-same-budget-loss','src/__tests__/bookkeeping-migration.test.ts','disappears after PREPARED',0)
 store.write_bytes(original[store]);s=original[migration].decode();needle='if (journal?.sources[index]?.existed && !observed.identity.existed)';assert needle in s;migration.write_text(s.replace(needle,'if (false && journal?.sources[index]?.existed && !observed.identity.existed)',1));run('missing-source-actual-guard-removed','src/__tests__/bookkeeping-migration.test.ts','disappears after PREPARED',1);migration.write_bytes(original[migration])
 def commit_delay(text):
  text=text.replace('let nativeMs = 0,','let controlledCommitDelay=false\nlet nativeMs = 0,');text=text.replace('      db.exec(sql)','      db.exec(sql)\n      if (controlledCommitDelay && sql === "COMMIT") { controlledCommitDelay=false;Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,400) }');text=text.replace('      const before = performance.now()','      if (i===0) controlledCommitDelay=true\n      const before = performance.now()');return text
 three.write_text(commit_delay((o/'bookkeeping-three-process-before.ts').read_text()));run('admission-old-includes-commit-delay','src/__tests__/bookkeeping-transactions.test.ts','measures three competing',1,'Expected: <= 350')
 three.write_text(commit_delay(original[three].decode()));run('admission-callback-boundary-with-same-commit-delay','src/__tests__/bookkeeping-transactions.test.ts','measures three competing',0)
finally:
 for p,data in original.items():p.write_bytes(data)
 result={'controls':rows,'sourceRestored':all(p.read_bytes()==data for p,data in original.items()),'originalFailureLimitation':'Forced controls establish assertion/fixture boundaries. The original CI scheduler/lock timing and discarded local control signal are not recovered; no product-runtime fix is claimed.'};(o/'fixture-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
