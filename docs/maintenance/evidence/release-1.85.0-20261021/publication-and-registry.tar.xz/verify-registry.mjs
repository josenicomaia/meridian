import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const out='/tmp/meridian-release185-evidence-20261021'
const recovery=JSON.parse(readFileSync(out+'/publish-recovery-dispatch.json'))
async function json(url){const r=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(30000)});assert.equal(r.status,200,url+' HTTP '+r.status);return r.json()}
const pkg=await json('https://registry.npmjs.org/@rynfar%2fmeridian/1.85.0')
assert.equal(pkg.version,'1.85.0');assert.equal(pkg.gitHead,recovery.sourceCommit)
const tags=(await json('https://registry.npmjs.org/@rynfar%2fmeridian'))['dist-tags'];assert.equal(tags.latest,'1.85.0')
const tarResponse=await fetch(pkg.dist.tarball,{redirect:'error',signal:AbortSignal.timeout(60000)});assert.equal(tarResponse.status,200);const tar=Buffer.from(await tarResponse.arrayBuffer());assert(tar.length<10*1024*1024)
const sha512=createHash('sha512').update(tar).digest('hex'),integrity='sha512-'+Buffer.from(sha512,'hex').toString('base64')
assert.equal(integrity,pkg.dist.integrity);assert.equal(createHash('sha1').update(tar).digest('hex'),pkg.dist.shasum)
writeFileSync(out+'/registry-1.85.0.tgz',tar)
assert(pkg.dist.attestations?.url?.startsWith('https://registry.npmjs.org/'))
const attestations=await json(pkg.dist.attestations.url)
const statements=attestations.attestations.map(row=>JSON.parse(Buffer.from(row.bundle.dsseEnvelope.payload,'base64')))
const provenance=statements.find(row=>row.predicateType==='https://slsa.dev/provenance/v1');assert(provenance)
assert(provenance.subject.some(subject=>subject.name==='pkg:npm/%40rynfar/meridian@1.85.0'&&subject.digest.sha512===sha512))
const build=provenance.predicate.buildDefinition,workflow=build.externalParameters.workflow
assert.equal(workflow.repository,'https://github.com/rynfar/meridian');assert.equal(workflow.path,'.github/workflows/release-please.yml');assert.equal(workflow.ref,'refs/heads/main')
assert(build.resolvedDependencies.some(dep=>dep.digest.gitCommit===recovery.sourceCommit))
assert.equal(build.internalParameters.github.event_name,'workflow_dispatch')
assert(provenance.predicate.runDetails.metadata.invocationId.includes('/'+recovery.workflowRun+'/'))
writeFileSync(out+'/registry-package.json',JSON.stringify(pkg,null,2)+'\n');writeFileSync(out+'/registry-attestations.json',JSON.stringify(attestations,null,2)+'\n');writeFileSync(out+'/registry-provenance.json',JSON.stringify(provenance,null,2)+'\n')
const result={version:pkg.version,latest:tags.latest,gitHead:pkg.gitHead,tarball:pkg.dist.tarball,integrity,sha512,sha256:createHash('sha256').update(tar).digest('hex'),attestations:pkg.dist.attestations.url,workflowRun:recovery.workflowRun,sourceMatchesWorkflowRepair:pkg.gitHead===recovery.sourceCommit,cryptographicSignatureAudit:'PENDING fresh install npm audit signatures',installedActualFlow:'PENDING'}
writeFileSync(out+'/registry-verification.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result))
