import {clearSessionCache} from "./registry-install/node_modules/@rynfar/meridian/dist/proxy/server.js";
const completed:Promise<void>=clearSessionCache();
type IsAny<T>=0 extends(1&T)?true:false;const exact:IsAny<ReturnType<typeof clearSessionCache>>=false;void[completed,exact];
