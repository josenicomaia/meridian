#!/usr/bin/env bun
// OpenCode 2.0.16 -> installed Meridian V2 plugin -> real SDK/model.
import assert from 'node:assert/strict'
import { randomBytes, randomUUID } from 'node:crypto'
import { mkdtempSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const expectedClientVersion = process.env.E2E_OPENCODE_VERSION ?? '2.0.16'
assert(['2.0.16','2.0.21','2.0.31'].includes(expectedClientVersion), 'Pin a qualified stable host')
const client = process.env.E2E_OPENCODE_BIN
assert(client, 'Set E2E_OPENCODE_BIN to the exact OpenCode 2.0.16 executable')
const repo = resolve(process.env.E2E_MERIDIAN_ROOT ?? '.')
const version = JSON.parse(readFileSync(join(repo, 'package.json'), 'utf8')).version
if (process.env.E2E_EXPECT_MERIDIAN_VERSION) assert.equal(version, process.env.E2E_EXPECT_MERIDIAN_VERSION)
const model = process.env.E2E_MODEL ?? 'claude-haiku-4-5'
const root = realpathSync(mkdtempSync(join(tmpdir(), 'meridian-opencode-v2-stable-')))
const project = join(root, 'project')
const config = join(root, 'opencode')
const meridianConfig = join(root, 'meridian')
const proxyWorkdir=join(root,'proxy-workdir')
for (const path of [project, config, meridianConfig,proxyWorkdir]) mkdirSync(path)
const marker = `OC2_STABLE_${randomUUID()}`
const variantMarker = `VARIANT_${randomUUID()}`
const fileReceipt = `FILE_RECEIPT_${randomUUID()}`
const forkMarker = `FORK_ONLY_${randomUUID()}`
const generateMarker = `GENERATE_${randomUUID()}`
writeFileSync(join(project, 'fixture.txt'), fileReceipt)
const attestationKey = process.env.E2E_ATTESTATION_KEY ?? randomBytes(32).toString('base64url')
const proxyEnv = { ...process.env }
for (const key of Object.keys(proxyEnv)) if (key.startsWith('MERIDIAN_') || key.startsWith('CLAUDE_PROXY_')) delete proxyEnv[key]
Object.assign(proxyEnv, {
  E2E_PROXY_MODULE: pathToFileURL(join(repo, 'dist/server.js')).href,
  MERIDIAN_CONFIG_DIR: meridianConfig,
  MERIDIAN_SESSION_DIR: join(root, 'sessions'),
  MERIDIAN_WORKDIR: proxyWorkdir,
  MERIDIAN_TELEMETRY_PERSIST: '0',
  MERIDIAN_PASSTHROUGH: '1',
  MERIDIAN_OPENCODE_ATTESTATION_KEY: attestationKey,
  PWD: project,
  INIT_CWD: project,
})
const observed = []
let proxy
let proxyOutput
let relay
try {
  let proxyURL = process.env.E2E_PROXY_URL
  if (!proxyURL) {
    const ready = new Promise((resolveReady, rejectReady) => {
      proxy = Bun.spawn([process.execPath, '/tmp/meridian-resume-20261020/1406-live/qualified-r3/qualified-proxy-host.mjs'], {
        cwd: project, env: proxyEnv, stdout: 'pipe', stderr: 'pipe',
        ipc(message) { if (message.port) resolveReady(message.port) },
      })
      proxy.exited.then(code => rejectReady(new Error(`Meridian exited before readiness: ${code}`)))
    })
    proxyOutput = Promise.all([new Response(proxy.stdout).text(), new Response(proxy.stderr).text()])
    const proxyPort = await Promise.race([ready, Bun.sleep(30_000).then(() => { throw Error('Meridian readiness timeout') })])
    proxyURL = `http://127.0.0.1:${proxyPort}`
  }
  assert(new URL(proxyURL).protocol === 'http:', 'E2E proxy must use local HTTP')
  relay = Bun.serve({ hostname: '127.0.0.1', port: 0, async fetch(request) {
    const url = new URL(request.url)
    const body = request.method === 'GET' ? undefined : await request.arrayBuffer()
    if (url.pathname === '/v1/messages' && body) {
      let parsed
      try { parsed = JSON.parse(new TextDecoder().decode(body)) } catch { parsed = undefined }
      const messages = JSON.stringify(parsed?.messages ?? [])
      observed.push({
        path: url.pathname,
        model: parsed?.model,
        effort: parsed?.effort,
        systemBlockLengths: Array.isArray(parsed?.system) ? parsed.system.map(block => block.text?.length ?? 0) : [],
        session: request.headers.get('x-opencode-session'),
        agent: request.headers.get('x-opencode-agent-name'),
        mode: request.headers.get('x-opencode-agent-mode'),
        source: request.headers.get('x-meridian-source'),
        attested: request.headers.has('x-meridian-opencode-turn'),
        hasMarker: messages.includes(marker),
        hasVariantMarker: messages.includes(variantMarker),
        hasFileReceipt: messages.includes(fileReceipt),
        hasForkMarker: messages.includes(forkMarker),
        hasGenerateMarker: messages.includes(generateMarker),
        hasToolUse: messages.includes('"tool_use"'),
        hasToolResult: messages.includes('"tool_result"'),
      })
    }
    const upstream = await fetch(`${proxyURL}${url.pathname}${url.search}`, {
      method: request.method, headers: request.headers,
      ...(body === undefined ? {} : { body }),
    })
    return new Response(upstream.body, { status: upstream.status, headers: upstream.headers })
  } })
  const relayURL = `http://127.0.0.1:${relay.port}`
  const plugin = join(repo, 'dist', 'meridian-v2')
  writeFileSync(join(config, 'opencode.json'), JSON.stringify({
    model: `anthropic/${model}`,
    ...(process.env.E2E_SCRIPTED_FORCE_LEGACY_TITLE==='1'?(assert.equal(process.env.E2E_MODEL_OBSERVER_SCRIPTED,'1'),{small_model:'anthropic/claude-haiku-4-5'}):{}),
    providers: { anthropic: { settings: { apiKey: 'local-e2e', baseURL: `${relayURL}/v1` },
      models: { [model]: { name: model, limit: { context: 200000, output: 4096 } } } } },
    share: 'disabled',
  }, null, 2))
  const clientEnv = { ...process.env }
  for (const key of Object.keys(clientEnv)) {
    if (key.startsWith('MERIDIAN_') || key.startsWith('CLAUDE_PROXY_') || key.startsWith('ANTHROPIC_')) delete clientEnv[key]
  }
  for (const kind of ['CONFIG', 'DATA', 'CACHE', 'STATE']) clientEnv[`XDG_${kind}_HOME`] = join(root, kind.toLowerCase())
  Object.assign(clientEnv, {
    OPENCODE_CONFIG_DIR: config,
    OPENCODE_DISABLE_AUTOUPDATE: '1',
    OPENCODE_SERVER_PASSWORD: 'local-e2e',
    MERIDIAN_CONFIG_DIR: meridianConfig,
    MERIDIAN_OPENCODE_ATTESTATION_KEY: attestationKey,
    PWD: project,
    INIT_CWD: project,
  })
  const versionRun = Bun.spawnSync([client, '--version'], { env: clientEnv })
  assert.equal(versionRun.exitCode, 0)
  assert.equal(new TextDecoder().decode(versionRun.stdout).trim(), `opencode v${expectedClientVersion}`)
  const setup = Bun.spawnSync(['node', join(repo, 'dist', 'cli.js'), 'setup', '--v2', '--opencode-bin', client],
    { cwd: project, env: clientEnv })
  assert.equal(setup.exitCode, 0, `Meridian setup rejected 2.0.16: ${new TextDecoder().decode(setup.stderr)}`)
  const configured = JSON.parse(readFileSync(join(config, 'opencode.json'), 'utf8'))
  assert.deepEqual(configured.plugins.map(path => realpathSync(path)), [realpathSync(plugin)],
    'Setup did not install the packaged V2 plugin exactly once')
  async function runClient(label, flags, prompt) {
    const run = Bun.spawn([client, 'run', '--standalone', '--auto', '--format', 'json', ...flags, prompt], {
      cwd: project, env: clientEnv, stdout: 'pipe', stderr: 'pipe',
    })
    const timeout = setTimeout(() => run.kill(), 180_000)
    const [stdout, stderr, code] = await Promise.all([
      new Response(run.stdout).text(), new Response(run.stderr).text(), run.exited,
    ]).finally(() => clearTimeout(timeout))
    writeFileSync(join(root, `${label}.stdout`), stdout)
    writeFileSync(join(root, `${label}.stderr`), stderr)
    writeFileSync(join(root, 'requests.json'), JSON.stringify(observed, null, 2))
    assert.equal(code, 0, `${label}: OpenCode exit ${code}; see ${root}/${label}.stderr`)
    return stdout
  }
  const first = await runClient('first', ['--model', `anthropic/${model}`],
    `Reply with exactly ${marker}. Do not call any tools.`)
  assert(first.includes('"type":"text"'), `No model response text; see ${root}/first.stdout`)
  const primary = observed.find(row => row.hasMarker && row.session && row.agent === 'build' && row.mode === 'primary')
  assert(primary?.attested, `No attested primary request: ${JSON.stringify(observed)}`)
  assert(observed.some(row => row.hasMarker && row.agent === 'title' && row.mode === 'subagent' && !row.session),
    `Title job was not detached: ${JSON.stringify(observed)}`)

  console.log(JSON.stringify({result:'PASS_SCRIPTED_FIRST_REQUEST',root,observed}))

} finally {
  relay?.stop(true)
  if (proxy) {
    proxy.kill()
    await proxy.exited
    if (proxyOutput) {
      const [stdout, stderr] = await proxyOutput
      writeFileSync(join(root, 'meridian.stdout'), stdout)
      writeFileSync(join(root, 'meridian.stderr'), stderr)
    }
  }
}
