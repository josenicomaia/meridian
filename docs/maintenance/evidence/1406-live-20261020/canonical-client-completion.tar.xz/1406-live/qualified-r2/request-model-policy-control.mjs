import assert from 'node:assert/strict'
import {expectedRequestModel} from './request-model-policy.mjs'
const title={agent:'title',mode:'subagent',source:'subagent-title',session:null,model:'claude-haiku-4-5'}
assert.equal(expectedRequestModel(title).model,'claude-haiku-4-5')
assert.equal(expectedRequestModel({...title,model:'claude-haiku-5-5'}).model,'claude-haiku-5-5')
assert.equal(expectedRequestModel({agent:'build',mode:'primary',session:'owned',model:'claude-haiku-5-5'}).model,'claude-haiku-5-5')
for(const row of [{...title,agent:'build',mode:'primary'}, {...title,session:'owned'}, {...title,mode:'primary'}, {...title,source:'subagent-explore'}, {...title,model:'claude-opus-4-8'}, undefined])assert.throws(()=>expectedRequestModel(row))
console.log(JSON.stringify({result:'PASS',accepted:3,rejected:6,realModels:0}))
