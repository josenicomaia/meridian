// Causally corrected original-client model-role fixture; failed task receipts remain immutable.
// This does not clear personal quota, Opus mismatch/refusal or Escape holds.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {loadProfilesFromDisk} from '/private/tmp/meridian-pr1397-20261020/src/proxy/profiles.ts';
import {createPlatformCredentialStore} from '/private/tmp/meridian-pr1397-20261020/src/proxy/tokenRefresh.ts';
import {fetchOAuthUsageResult} from '/private/tmp/meridian-pr1397-20261020/src/proxy/oauthUsage.ts';
assert.equal(process.env.E2E_NEW_TASK,'1406-stable-client-request-models');
assert.equal(process.env.E2E_ALLOW_LIVE_MODEL,'1');
process.env.MERIDIAN_CREDENTIALS_READONLY='1';
const privateRoot='/tmp/meridian-resume-20261020/private';
const grantPath=privateRoot+'/1406-role-grant.json';
const observationPath=privateRoot+'/1406-role-capacity.json';
const priorObservationPath=privateRoot+'/independent-team-capacity-observation.json';
assert.equal(statSync(privateRoot).mode&0o077,0);
assert(!existsSync(grantPath),'No duplicate grant');
assert(!existsSync('/tmp/meridian-resume-20261020/1406-live/STABLE_MODEL_ROLE_ATTEMPT.json'),'An attempted actual case cannot be silently retried');
for(const path of [priorObservationPath,observationPath,privateRoot+'/1406-capacity.json'])if(existsSync(path)){const last=JSON.parse(readFileSync(path));assert(last.canInfer===true||Date.now()-Date.parse(last.at)>=3600000,'Retain hourly backoff after unavailable usage metadata; a successful observation permits a fresh later task admission')}
const profile=loadProfilesFromDisk()[1];
assert.equal(profile?.type??(profile?.claudeConfigDir?'claude-max':'other'),'claude-max');
const store=createPlatformCredentialStore({claudeConfigDir:profile.claudeConfigDir});
const oauth=(await store.read())?.claudeAiOauth;
assert(oauth?.accessToken&&oauth.expiresAt>Date.now()+300000,'No refresh or credential writes permitted');
const response=await fetch('https://api.anthropic.com/api/oauth/profile',{headers:{Authorization:'Bearer '+oauth.accessToken,'anthropic-beta':'oauth-2025-04-20',Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(10000)});
const quotaHeaders=headers=>Object.fromEntries([...headers].filter(([name])=>name.startsWith('anthropic-ratelimit-unified-')||['retry-after','x-ratelimit-limit','x-ratelimit-remaining','x-ratelimit-reset'].includes(name)));
const receipt={at:new Date().toISOString(),task:'1406-stable-client-request-models',ordinal:1,profileHTTP:response.status,profileQuotaHeaders:quotaHeaders(response.headers),refreshes:0,credentialWrites:0,modelCalls:0,grantsCreated:0,http:[]};
const save=()=>writeFileSync(observationPath,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
save();assert.equal(response.status,200);
const metadata=await response.json();
receipt.organizationPlanActive=['active','trialing'].includes(metadata.organization?.subscription_status);
receipt.profileExtraUsageEnabled=metadata.organization?.has_extra_usage_enabled;
const usage=await fetchOAuthUsageResult({store,profileId:'independent-unattempted-1406-host-isolation',force:true,refreshImpl:async()=>{receipt.refreshes++;return false},fetchImpl:async(url,init)=>{
 assert.equal(String(url),'https://api.anthropic.com/api/oauth/usage');
 const actual=new URL(String(url));actual.searchParams.set('cedar_ember','1');
 const headers=new Headers(init?.headers);headers.set('User-Agent','claude-cli/2.1.304 (external, cli)');
 const result=await fetch(actual,{...init,headers,signal:AbortSignal.timeout(10000)});
 receipt.http.push({status:result.status,retryAfter:result.headers.get('retry-after'),quotaHeaders:quotaHeaders(result.headers)});return result;
}});
receipt.windows=usage.snapshot?.windows??[];receipt.extraUsageEnabled=usage.snapshot?.extraUsage?.isEnabled??null;receipt.stale=usage.snapshot?.stale??false;receipt.error=usage.error;
receipt.canInfer=receipt.organizationPlanActive&&receipt.profileExtraUsageEnabled===false&&receipt.extraUsageEnabled===false&&!receipt.stale&&['five_hour','seven_day'].every(type=>receipt.windows.some(w=>w.type===type&&typeof w.utilization==='number'&&w.utilization<1));
receipt.accountIdentitySHA256=createHash('sha256').update(metadata.account?.uuid??'missing').digest('hex');
save();assert.equal(receipt.refreshes,0);assert(receipt.canInfer,'Included capacity and disabled paid Extra Usage must be established freshly');
writeFileSync(grantPath,JSON.stringify([{id:'owned-1406-new-task',type:'oauth-token',oauthToken:oauth.accessToken}]),{mode:0o600,flag:'wx'});
assert.equal(statSync(grantPath).mode&0o077,0);receipt.grantsCreated=1;save();
console.log(JSON.stringify({task:receipt.task,canInfer:true,freshIncludedCapacity:true,paidExtraUsageEnabled:false,refreshes:0,credentialWrites:0,modelCalls:0,grantCreated:true}));
