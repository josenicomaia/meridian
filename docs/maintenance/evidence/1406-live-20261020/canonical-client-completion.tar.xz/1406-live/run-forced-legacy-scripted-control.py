from pathlib import Path
import json,os,subprocess
r=Path('/tmp/meridian-resume-20261020');out=r/'1406-live/stable-role-scripted-r2';out.mkdir();grant=out/'fake-grant.json';grant.write_text(json.dumps([{'id':'owned-role-control','type':'oauth-token','oauthToken':'owned-fake-no-provider-credential'}]));grant.chmod(0o600)
env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','TMPDIR']};env.update(HOME=str(out/'home'),E2E_ALLOW_LIVE_MODEL='1',E2E_MODEL_OBSERVER_SCRIPTED='1',E2E_SCRIPTED_FORCE_LEGACY_TITLE='1',E2E_LIVE_PROFILE_FILE=str(grant),E2E_MODEL='claude-haiku-5-5',E2E_EXPECT_MODEL='claude-haiku-5-5',E2E_MERIDIAN_ROOT=str(r/'1406-live/installed/node_modules/@rynfar/meridian'),E2E_OPENCODE_BIN=str(r/'opencode-stable-2.0.16/node_modules/@opencode/cli-darwin-arm64/bin/opencode'),E2E_OPENCODE_VERSION='2.0.16',E2E_PROXY_REPORT_DIR=str(out/'proxy'),E2E_PLUGIN_PATH=str(r/'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_NATIVE_BIN='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302')
(out/'home').mkdir();(out/'proxy').mkdir()
try:
 with (out/'run.log').open('w') as f:p=subprocess.run(['/tmp/meridian-1399-tooling/node_modules/.bin/bun',str(r/'1406-live/qualified-r2/stable-first-request-scripted.mjs')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 models=[json.loads(x.read_text()) for x in (out/'proxy').glob('models-*.json')];workers=[json.loads(x.read_text()) for x in (out/'proxy').glob('proxy-*.json')]
 assert p.returncode==0 and len(models)==1 and len(workers)==1
 assert models[0]['scripted'] and models[0]['realForwards']==0 and models[0]['closed'] and not models[0]['stopped']
 assert {x['expectedModel'] for x in models[0]['queries']}=={'claude-haiku-4-5','claude-haiku-5-5'}
 assert workers[0]['result']=='PASS' and workers[0]['joined'] and workers[0]['providerNativeStoredCorrelated']
 (out/'summary.json').write_text(json.dumps({'result':'PASS','actualClients':True,'actualSDKNative':True,'realForwards':0,'legacyTitleAndCurrentPrimaryBothCorrelated':True,'joined':True},indent=2)+'\n');print('Forced-legacy scripted control PASS; real forwards0',flush=True)
finally:grant.unlink(missing_ok=True)
