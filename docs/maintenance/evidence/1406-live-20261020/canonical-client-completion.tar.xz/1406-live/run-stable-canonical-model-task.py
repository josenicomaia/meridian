import os,json,subprocess,hashlib,datetime
from pathlib import Path
r=Path('/tmp/meridian-resume-20261020');out=r/'1406-live';q=out/'qualified-r3';source='/private/tmp/meridian-pr1406-20261019';package=str(out/'installed/node_modules/@rynfar/meridian');head='0eab35da83ca4e6eafde168c975e6a33c2210f44';bun='/tmp/meridian-1399-tooling/node_modules/.bin/bun';grant=r/'private/1406-role-canonical-grant.json';guard=r/'private/1406-role-canonical-admission.json';attempt=out/'STABLE_CANONICAL_MODEL_ATTEMPT.json';hold=r/'LIVE_MODEL_HOLD.json';holdHash=hashlib.sha256(hold.read_bytes()).hexdigest();record={'task':'1406-stable-client-canonical-models','head':head,'cases':[],'result':'RUNNING'}
assert not attempt.exists() and not grant.exists()
prior=json.loads((out/'first-live-task.json').read_text());assert prior['result']=='FAIL' and prior['grantRemoved'] and prior['holdsUnchanged'] and prior['cases'][-1]['generations']==0
priorRole=json.loads((out/'stable-request-model-task.json').read_text());assert priorRole['result']=='FAIL' and priorRole['grantRemoved'] and priorRole['holdsUnchanged'] and priorRole['cases'][0]['generations']==2 and 'claude-haiku-4-5-20251001' in priorRole['cases'][0]['workers'][0]['failure']
control=json.loads((out/'stable-alias-scripted-r3/summary.json').read_text());assert control['result']=='PASS' and control['realForwards']==0 and control['legacyTitleAndCurrentPrimaryBothCorrelated']
subprocess.run(['node',str(q/'request-model-policy-control.mjs')],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
local=json.loads((r/'1406-post1394-final-local-exit.json').read_text());assert local['final'] and local['exit']==0 and local['head']==head
identity=json.loads((out/'pack/identity.json').read_text());assert identity['head']==head and hashlib.sha256(Path(identity['tarball']).read_bytes()).hexdigest()==identity['sha256']
seal={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in q.glob('*.mjs')}
def save():(out/'stable-canonical-model-task.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 env=dict(os.environ,E2E_NEW_TASK=record['task'],E2E_ALLOW_LIVE_MODEL='1');subprocess.run([bun,str(q/'create-role-task-grant.mjs')],cwd=source,env=env,check=True)
 attempt.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':record['task'],'reason':'Causally corrected fixture recognizes official Haiku4.5 short alias -> exact20251001 response snapshot, proven by provider response + official model-ID docs and actual-client forced-legacy scripted control. Original r1 and r2 failures retained. No client model configuration, provider forwarding body, source product, account or older failed-case hold changed.','scripts':seal},indent=2)+'\n')
 common={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL','TMPDIR']};common.update(E2E_ALLOW_LIVE_MODEL='1',E2E_NEW_TASK=record['task'],E2E_LIVE_PROFILE_FILE=str(grant),E2E_USAGE_GUARD_FILE=str(guard),E2E_MODEL='claude-haiku-5-5',E2E_EXPECT_MODEL='claude-haiku-5-5',E2E_MERIDIAN_ROOT=package,E2E_PLUGIN_PATH=str(r/'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_NATIVE_BIN='/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302')
 for version in ['2.0.16','2.0.21']:
  name='e42-stable-'+version+'-canonical-model-r3';target=out/name;target.mkdir();(target/'home').mkdir();(target/'proxy').mkdir();env=dict(common,HOME=str(target/'home'),E2E_OPENCODE_VERSION=version,E2E_OPENCODE_BIN=str(r/('opencode-stable-'+version+'/node_modules/@opencode/cli-darwin-arm64/bin/opencode')),E2E_PROXY_REPORT_DIR=str(target/'proxy'))
  row={'case':name,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};record['cases'].append(row);save()
  with (target/'run.log').open('w') as log:p=subprocess.run([bun,str(q/'stable-gate.mjs')],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
  workers=[json.loads(p.read_text()) for p in (target/'proxy').glob('proxy-*.json')];models=[json.loads(p.read_text()) for p in (target/'proxy').glob('models-*.json')]
  row.update(exit=p.returncode,workers=[{k:w.get(k) for k in ['result','failure','joined','providerNativeStoredCorrelated','observedModels']} for w in workers],generations=sum(w['generationCount'] for w in models),qualified=p.returncode==0 and len(workers)==1 and workers[0]['result']=='PASS' and workers[0]['joined'] and workers[0]['providerNativeStoredCorrelated'] and len(models)==1 and not models[0]['scripted'] and not models[0]['stopped'] and models[0]['closed'] and models[0]['realForwards']>=models[0]['generationCount']>0);save();print(json.dumps(row),flush=True)
  assert row['qualified'],'Retain actual failure; no unexplained retry'
  assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seal.items())
  assert hashlib.sha256(hold.read_bytes()).hexdigest()==holdHash
 record['result']='PASS'
finally:
 grant.unlink(missing_ok=True);record['grantRemoved']=not grant.exists();record['holdsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==holdHash
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases']),'grantRemoved':record['grantRemoved'],'holdsUnchanged':record['holdsUnchanged']}),flush=True)
