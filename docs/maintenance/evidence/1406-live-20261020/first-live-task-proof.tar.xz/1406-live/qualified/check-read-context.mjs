import {homedir} from 'node:os';
import {createHash} from 'node:crypto';
import {loadProfilesFromDisk} from '/private/tmp/meridian-pr1397-20261020/src/proxy/profiles.ts';
import {createPlatformCredentialStore} from '/private/tmp/meridian-pr1397-20261020/src/proxy/tokenRefresh.ts';
process.env.MERIDIAN_CREDENTIALS_READONLY='1';
const profile=loadProfilesFromDisk()[1];
const credentials=profile?await createPlatformCredentialStore({claudeConfigDir:profile.claudeConfigDir}).read():null;
const hash=value=>createHash('sha256').update(String(value)).digest('hex');
console.log(JSON.stringify({homeSHA256:hash(homedir()),profileConfigSHA256:hash(profile?.claudeConfigDir),profileType:profile?.type,
  hasOAuth:!!credentials?.claudeAiOauth,unexpiredForFiveMinutes:!!(credentials?.claudeAiOauth?.expiresAt>Date.now()+300000),
  modelCalls:0,httpCalls:0,refreshes:0,credentialWrites:0}));
