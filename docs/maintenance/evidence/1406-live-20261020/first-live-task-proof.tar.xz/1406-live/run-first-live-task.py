import os, json, subprocess, hashlib, shutil, socket, datetime
from pathlib import Path

r = Path('/tmp/meridian-resume-20261020')
out = r / '1406-live'
qualified = out / 'qualified'
source = '/private/tmp/meridian-pr1406-20261019'
baseline = '/private/tmp/meridian-main-1406-20261020'
package = str(out / 'installed/node_modules/@rynfar/meridian')
head = '0eab35da83ca4e6eafde168c975e6a33c2210f44'
bun = '/tmp/meridian-1399-tooling/node_modules/.bin/bun'
native = '/tmp/meridian-overnight-20261019/native-pinned/claude-2.1.302'
grant = r / 'private/1406-grant.json'
guard = r / 'private/1406-capacity.json'
attempt = out / 'REAL_MODEL_ATTEMPT.json'
hold = r / 'LIVE_MODEL_HOLD.json'
hold_hash = hashlib.sha256(hold.read_bytes()).hexdigest()
record = {'task': '1406-host-isolation-haiku55', 'head': head, 'cases': [], 'result': 'RUNNING'}

assert not attempt.exists(), 'Never silently restart an attempted real-model task'
assert not grant.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()
local = json.loads((r / '1406-post1394-final-local-exit.json').read_text())
assert local['head'] == head and local['final'] and local['exit'] == 0
identity = json.loads((out / 'pack/identity.json').read_text())
assert identity['head'] == head and identity['@anthropic-ai/claude-agent-sdk'] == '0.2.141'
assert hashlib.sha256(Path(identity['tarball']).read_bytes()).hexdigest() == identity['sha256']
common = {k: v for k, v in os.environ.items() if k in ('PATH', 'LANG', 'LC_ALL', 'TERM', 'TMPDIR')}
common.update(E2E_NEW_TASK=record['task'], E2E_ALLOW_LIVE_MODEL='1', E2E_LIVE_PROFILE_FILE=str(grant),
              E2E_USAGE_GUARD_FILE=str(guard), E2E_PLUGIN_PATH=str(r / 'scrub-tooling/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js'),
              E2E_SCRUB_VERSION='0.2.3', E2E_NATIVE_BIN=native, E2E_EXPECT_MODEL='claude-haiku-5-5', E2E_MODEL='claude-haiku-5-5')

def save():
    (out / 'first-live-task.json').write_text(json.dumps(record, indent=2) + '\n')

def run_case(name, command, env, check):
    target = out / name
    target.mkdir()
    for directory in ['home', 'native-config', 'proxy']:
        (target / directory).mkdir()
    row = {'case': name, 'started': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['cases'].append(row)
    save()
    with (target / 'run.log').open('w') as log:
        result = subprocess.run(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
    row['exit'] = result.returncode
    row.update(check(target))
    save()
    print(json.dumps(row), flush=True)
    assert hashlib.sha256(hold.read_bytes()).hexdigest() == hold_hash, 'Prior failed-case holds changed'
    assert result.returncode == 0 and row['qualified'], 'Retain failure; stop dependent cases without retry'

try:
    # Keychain access needs the established host process context. Only this
    # read-only, zero-inference grant helper inherits it; all model hosts keep
    # the explicitly isolated environment above.
    grant_env = dict(os.environ, E2E_NEW_TASK=record['task'], E2E_ALLOW_LIVE_MODEL='1')
    subprocess.run([bun, str(qualified / 'create-new-task-grant.mjs')], cwd=source, env=grant_env, check=True)
    attempt.write_text(json.dumps({'task': record['task'], 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                   'head': head, 'state': 'first real task started; no blind automatic retry'}, indent=2) + '\n')
    # These cases share one newly admitted task, not another failed PR's retry.
    for label, root, flags in [('baseline', baseline, ['--expect-baseline']), ('candidate', source, []), ('installed', package, [])]:
        name = label + '-live-r1'
        env = dict(common, E2E_MERIDIAN_ROOT=root, E2E_OPENCODE_VERSION='2.0.31',
                   E2E_OPENCODE_BIN=str(r / 'opencode-stable-2.0.31/node_modules/@opencode/cli-darwin-arm64/bin/opencode'), E2E_EVIDENCE_DIR=str(out / name))
        def affected(target, label=label):
            report = json.loads((target / 'report.json').read_text()) if (target / 'report.json').exists() else {}
            primary = [row for row in report.get('provider', []) if row.get('primary')]
            return {'result': report.get('result'), 'failure': report.get('failure'), 'generations': len(report.get('provider', [])),
                    'qualified': report.get('result') == ('EXPECTED_BASELINE_FAILURE' if label == 'baseline' else 'PASS')
                    and report.get('joined') and report.get('providerNativeStoredCorrelated') and bool(primary)}
        run_case(name, ['node', source + '/scripts/e2e-opencode-host-isolation.mjs', '--live', *flags], env, affected)

    for mode in ['chain-json', 'chain-stream', 'parallel-json', 'parallel-stream']:
        name = 'e41-' + mode + '-r1'
        target = out / name
        port_socket = socket.socket(); port_socket.bind(('127.0.0.1', 0)); port = port_socket.getsockname()[1]; port_socket.close()
        env = dict(common, HOME=str(target / 'home'), CLAUDE_CONFIG_DIR=str(target / 'native-config'),
                   MERIDIAN_CLAUDE_PATH=native, MERIDIAN_CREDENTIALS_READONLY='1', MERIDIAN_NO_UPDATE_CHECK='1',
                   E2E_MERIDIAN_ROOT=source, E2E_MODEL_WITNESS=str(target / 'model-witness.json'),
                   E2E_CLIENT_PLUGIN_PATH=source + '/dist/meridian/index.js', E2E_CLIENT_VERSION='1.84.0',
                   PROBE_MODEL='claude-haiku-5-5', PROBE_PARALLEL='1' if mode.startswith('parallel') else '0', PROBE_TURNS='6', PROBE_PORT=str(port))
        # The protocol fixture creates these paths after its output root exists.
        command = [bun, str(qualified / 'run-e41.mjs')] + (['--stream'] if mode.endswith('stream') else [])
        def e41(target):
            lines = (target / 'run.log').read_text().splitlines()
            result = next((json.loads(line) for line in reversed(lines) if line.startswith('{"root":')), None)
            if result:
                shutil.copy2(Path(result['root']) / 'qualified-e41-report.json', target / 'report.json')
            witness = json.loads((target / 'model-witness.json').read_text()) if (target / 'model-witness.json').exists() else {}
            return {'result': result, 'generations': witness.get('generationCount'),
                    'qualified': bool(result and result.get('result') == 'PASS' and result.get('joined') and not witness.get('stopped'))}
        run_case(name, command, env, e41)

    cases = [('beta', version, mode) for version in ['18314', '18866', '19271'] for mode in [True, False]]
    cases += [('stable', version, mode) for version, mode in [('2.0.31', True), ('2.0.31', False), ('2.0.16', False), ('2.0.21', False)]]
    for kind, version, source_mode in cases:
        name = 'e42-' + kind + '-' + version + ('-source-r1' if source_mode else '-installed-r1')
        target = out / name
        root = source if source_mode else package
        binary = r / (f'opencode-beta-{version}/node_modules/@opencode-ai/cli-darwin-arm64/bin/opencode2' if kind == 'beta'
                      else f'opencode-stable-{version}/node_modules/@opencode/cli-darwin-arm64/bin/opencode')
        env = dict(common, HOME=str(target / 'home'), E2E_MERIDIAN_ROOT=root, E2E_OPENCODE_BIN=str(binary),
                   E2E_PROXY_REPORT_DIR=str(target / 'proxy'), E2E_OPENCODE_VERSION=version)
        command = [bun, str(qualified / (kind + '-gate.mjs'))]
        if kind == 'beta': command += ['--live', '--extended', '--separate-proxy-cwd'] + (['--source'] if source_mode else [])
        def e42(target, kind=kind):
            workers = [json.loads(path.read_text()) for path in (target / 'proxy').glob('proxy-*.json')]
            models = [json.loads(path.read_text()) for path in (target / 'proxy').glob('models-*.json')]
            return {'workers': [{'result': row.get('result'), 'failure': row.get('failure'), 'joined': row.get('joined'),
                                  'correlated': row.get('providerNativeStoredCorrelated')} for row in workers],
                    'generations': sum(row.get('generationCount', 0) for row in models),
                    'qualified': len(workers) == (2 if kind == 'beta' else 1) and all(row.get('result') == 'PASS' and row.get('joined')
                       and row.get('providerNativeStoredCorrelated') for row in workers) and all(not row.get('stopped') for row in models)}
        run_case(name, command, env, e42)
    record['result'] = 'PASS'
finally:
    grant.unlink(missing_ok=True)
    record['grantRemoved'] = not grant.exists()
    record['holdsUnchanged'] = hashlib.sha256(hold.read_bytes()).hexdigest() == hold_hash
    if record['result'] != 'PASS': record['result'] = 'FAIL'
    save()
    print(json.dumps({'result': record['result'], 'cases': len(record['cases']), 'grantRemoved': record['grantRemoved'], 'holdsUnchanged': record['holdsUnchanged']}), flush=True)
