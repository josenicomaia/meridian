from pathlib import Path
import subprocess,os,json,hashlib,time,stat
root=Path('/private/tmp/meridian-1396-current-main-20261021');out=Path('/tmp/meridian-active-history-budget-20261021/1396-integration');tar=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz');digest='0bc7e56683ec375bf4aba02c09f2275db1e5310dcc05bf5274b528335fc2ed3d';assert hashlib.sha256(tar.read_bytes()).hexdigest()==digest;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOKKEEPING_COMPAT_TARBALL=str(tar));env['PATH']='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin:/Users/rynfar/.local/bin:'+env['PATH'];records=[]
# Same documented read-only source-page preparation as prior qualified gate.
# No source, certificate bound, guard or application timeout is changed.
names=set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().strip('\0').split('\0'));assert len(names)<=10000;count=0;total=0;h=hashlib.sha256();start=time.monotonic()
for name in sorted(names):
 p=root/name
 try:meta=p.lstat()
 except FileNotFoundError:continue
 if not stat.S_ISREG(meta.st_mode):continue
 assert meta.st_size<=64*1024*1024;total+=meta.st_size;assert total<=256*1024*1024;count+=1;h.update(name.encode()+b'\0')
 with p.open('rb')as f:
  while True:
   chunk=f.read(1024*1024)
   if not chunk:break
   h.update(chunk)
(out/'source-page-preparation.json').write_text(json.dumps({'head':head,'files':count,'bytes':total,'readSHA256':h.hexdigest(),'seconds':time.monotonic()-start,'sourceUnchanged':True,'certificateBudgetMs':2000,'scope':'Read-only page preparation retained as host qualification condition; not a root-cause or product repair claim.'},indent=2)+'\n')
for name,cmd in [('build',['npm','run','build']),('typecheck',['npm','run','typecheck']),('full',['npm','test'])]:
 print('Starting',name,'on',head,flush=True);start=time.time()
 with(out/('final-'+name+'.log')).open('w')as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'exit':r.returncode,'seconds':time.time()-start});(out/'final-local.json').write_text(json.dumps({'head':head,'publishedTarSHA256':digest,'commands':records},indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
 if r.returncode:break
