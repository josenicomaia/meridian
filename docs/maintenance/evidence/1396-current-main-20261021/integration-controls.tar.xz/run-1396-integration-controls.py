from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-1396-current-main-20261021');out=Path('/tmp/meridian-active-history-budget-20261021/1396-integration');out.mkdir(exist_ok=True);source=root/'src/proxy/server.ts';original=source.read_bytes();env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
needle=b'const recoverySdkUuidMap: Array<string | null> = Array.from({ length: replyPosition }, () => null)';assert original.count(needle)==1
try:
 source.write_bytes(original.replace(needle,b'const recoverySdkUuidMap: Array<string | null> = Array.from({ length: allMessages.length }, () => null)'))
 with(out/'wrong-request-length.log').open('w')as log:r=subprocess.run([bun,'test','src/__tests__/silent-turn-recovery.test.ts','--test-name-pattern','sizes the recovery fork'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'control':'wrong request-length resolution','exit':r.returncode});assert r.returncode!=0
finally:source.write_bytes(original)
assert source.read_bytes()==original
with(out/'correct-lineage-both-backends.log').open('w')as log:r=subprocess.run([bun,'test','src/__tests__/silent-turn-recovery.test.ts','--test-name-pattern','sizes the recovery fork'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
rows.append({'control':'correct lineage-length resolution, JSON and real SQLite','exit':r.returncode});(out/'controls.json').write_text(json.dumps({'controls':rows,'productionRestoredSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'newModelCalls':0},indent=2)+'\n');print(json.dumps(rows));assert r.returncode==0
