from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/private/tmp/meridian-1399-current-main-20261021');out=Path('/tmp/meridian-active-history-budget-20261021/1399-integration');path='src/proxy/session/bookkeeping/lifecycleDeletionSql.ts';source=root/path;fixed=source.read_bytes();before=subprocess.check_output(['git','show','075e9e4736d3457e12dda1a0108531b9b5843e96:'+path],cwd=root);assert before!=fixed;env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
try:
 source.write_bytes(before)
 with(out/'sqlite-proxy-close-before.log').open('w')as log:r=subprocess.run([bun,'test','src/__tests__/proxy-session-gc-capacity.test.ts','--test-name-pattern','lowers the remaining allowance.*sqlite'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'control':'Unchanged-main SQL deletion loop with the new actual-store embedding-close tests','exit':r.returncode});assert r.returncode!=0
finally:source.write_bytes(fixed)
with(out/'sqlite-proxy-close-after.log').open('w')as log:r=subprocess.run([bun,'test','src/__tests__/proxy-session-gc-capacity.test.ts','--test-name-pattern','lowers the remaining allowance'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
rows.append({'control':'Corrected SQL loop plus unchanged JSON loop; pauses at deletion 1 and 25','exit':r.returncode});(out/'sqlite-close-control.json').write_text(json.dumps({'results':rows,'fixedSourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'baselineSourceSHA256':hashlib.sha256(before).hexdigest(),'restoredExactly':source.read_bytes()==fixed,'modelCalls':0},indent=2)+'\n');print(json.dumps(rows));assert r.returncode==0
