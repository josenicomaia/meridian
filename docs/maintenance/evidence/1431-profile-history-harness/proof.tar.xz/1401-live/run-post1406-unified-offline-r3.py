import pathlib,subprocess,os,json,hashlib
r=pathlib.Path('/tmp/meridian-resume-20261020');out=r/'1401-live';prior=out/'post1406-packages-r1';stage=out/'post1406-unified-offline-r3';stage.mkdir()
script=pathlib.Path('/private/tmp/meridian-e85-harness-20261020/scripts/e2e-profile-history-client.mjs');sha=hashlib.sha256(script.read_bytes()).hexdigest();report={'scope':'scripted API only, actual Linux OpenCode/SDK/native; zero real generations','sourceSHA256':sha,'heads':json.loads((prior/'summary.json').read_text())['heads'],'cases':[],'result':'RUNNING'}
def save():(stage/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for flow,label in [('keyed','baseline'),('keyed','candidate'),('rewind','baseline'),('rewind','candidate'),('pi','baseline'),('pi','candidate')]:
  target=stage/(flow+'-'+label+'-case');target.mkdir();artifact=prior/(label+'-linux')
  args=['docker','run','--rm','--platform','linux/arm64','-v','/private/tmp/meridian-pr1406-20261019:/source:ro','-v',str(out)+':/probe:ro','-v',str(artifact)+':/artifact:ro','-v','/tmp/meridian-issue-r2-evidence/linux-runtime:/runtime:ro','-v',str(r/'opencode2031-tooling')+':/client:ro','-v',str(target)+':/evidence','-v','/private/tmp/meridian-e85-harness-20261020:/harness:ro','-v',str(r/'pi-linux-client')+':/pi:ro']
  settings={'E2E_MERIDIAN_ROOT':'/artifact/node_modules/@rynfar/meridian','E2E_OPENCODE_BIN':'/client/opencode','E2E_NATIVE_BIN':'/runtime/node_modules/@anthropic-ai/claude-code-linux-arm64/claude','E2E_OPENCODE_VERSION':'2.0.31','E2E_PLUGIN_PATH':'/runtime/node_modules/@rynfar/meridian-plugin-opencode-scrub/dist/index.js','E2E_SCRUB_VERSION':'0.2.3','E2E_EVIDENCE_DIR':'/evidence','E2E_EXPECT':label,'E2E_PI_PACKAGE':'/pi/node_modules/@earendil-works/pi-coding-agent'}
  for name,value in settings.items():args+=['-e',name+'='+value]
  caseFlags=['--aliases']+(['--rewind'] if flow=='rewind' else ['--pi'] if flow=='pi' else [])
  bootstrap="require('node:fs').writeFileSync('/etc/machine-id',require('node:crypto').randomBytes(16).toString('hex')+'\\n');const p=require('node:child_process').spawnSync(process.execPath,['/harness/scripts/e2e-profile-history-client.mjs',..."+json.dumps(caseFlags)+"],{env:process.env,stdio:'inherit'});if(p.error)throw p.error;process.exit(p.status??1)"
  args+=['node:24.20.0-bookworm','node','-e',bootstrap]
  with (stage/(flow+'-'+label+'-case.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  case=json.loads((target/'report.json').read_text()) if (target/'report.json').exists() else {}
  row={'flow':flow,'label':label,'exit':p.returncode,**{key:case.get(key) for key in ['result','failure','joined','profileAliasesShareGrant','foreignAnswersOnReturn','finalReplyRecalls','clientFinalReplyRecalls','providerNativeStoredCorrelated','nativeNamespaceWitness','logWitness','rewindResumeWitness','originalASource','originalChildClosure']}};report['cases'].append(row);save();print(json.dumps(row),flush=True)
  assert p.returncode==0 and case['result']==('EXPECTED_BASELINE_FAILURE' if flow!='rewind' and label=='baseline' else 'PASS') and case['joined']
  assert hashlib.sha256(script.read_bytes()).hexdigest()==sha,'Executed harness changed'
 report['result']='PASS'
finally:
 if report['result']!='PASS':report['result']='FAIL'
 save();print(json.dumps({'result':report['result'],'cases':len(report['cases'])}),flush=True)
