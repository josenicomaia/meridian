import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const source='/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-agy-pi-B3eGFu/requests.json'
const bytes=readFileSync(source), requests=JSON.parse(bytes), rows=[]
assert.equal(requests.length,1)
for(const label of ['main','candidate']){
 const mod=await import(`./${label}-protocol.ts`), request=mod.parseAgRequest(requests[0]);const original=JSON.stringify(request.messages)
 try{
  const rendered=mod.renderAgPromptWithinLimit(request);const h=JSON.parse(rendered.slice(rendered.lastIndexOf('Client conversation:\n')+'Client conversation:\n'.length))
  assert(Buffer.byteLength(rendered)<=190000);assert.deepEqual(h.slice(-2),request.messages.slice(-2));assert.equal(JSON.stringify(request.messages),original)
  rows.push({label,outcome:'RENDERED',bytes:Buffer.byteLength(rendered),latestCompletedCallResultExact:true,inputUnchanged:true})
 }catch(error){if(label!=='main')throw error;assert.equal(error.status,400);rows.push({label,outcome:'REJECTED',status:error.status,message:error.message})}
}
assert.equal(rows[0].outcome,'REJECTED');assert.equal(rows[1].outcome,'RENDERED')
const record={scope:'Exact retained original1340 actual-Pi/Meridian-extension public-fixture wire request; deterministic rendering only, no new model/native/client invocation or replay-notice acceptance',requestCount:1,originalPublicWireBytes:bytes.length,originalPublicWireSHA256:createHash('sha256').update(bytes).digest('hex'),rows}
writeFileSync(new URL('./original-1340-wire-comparison.json',import.meta.url),JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record,null,2))
