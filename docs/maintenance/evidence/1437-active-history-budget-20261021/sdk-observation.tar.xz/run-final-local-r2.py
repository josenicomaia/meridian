from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path('/private/tmp/meridian-release185-20261021');out=Path('/tmp/meridian-active-history-budget-20261021');tar=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz');digest='0bc7e56683ec375bf4aba02c09f2275db1e5310dcc05bf5274b528335fc2ed3d';assert hashlib.sha256(tar.read_bytes()).hexdigest()==digest;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOKKEEPING_COMPAT_TARBALL=str(tar));env['PATH']='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin'+os.pathsep+env['PATH'];records=[]
for name,cmd in [('typecheck',['npm','run','typecheck']),('build',['npm','run','build']),('full',['npm','test'])]:
 print('Starting',name,'on',head,flush=True);start=time.time()
 with(out/('final-r2-'+name+'.log')).open('w')as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'exit':r.returncode,'seconds':time.time()-start});(out/'final-r2-local.json').write_text(json.dumps({'head':head,'publishedTarSha256':digest,'commands':records},indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
 if r.returncode:break
