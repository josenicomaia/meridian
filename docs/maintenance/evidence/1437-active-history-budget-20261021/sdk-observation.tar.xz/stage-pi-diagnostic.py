from pathlib import Path
root=Path('/private/tmp/meridian-release185-20261021');out=Path('/tmp/meridian-active-history-budget-20261021/pi-debug-r1');out.mkdir()
s=(root/'src/__tests__/proxy-cross-process-coordination.test.ts').read_text()
s=s.replace('const testDir = dirname(fileURLToPath(import.meta.url))',f'const testDir = {str(root / "src/__tests__")!r}')
s=s.replace('"meridian-proxy-process-test-"','"meridian-proxy-process-debug-"')
s=s.replace('const { createProxyServer } = await import(process.env.SERVER_MODULE)', '''const coordinator = await import(process.env.CROSS_PROCESS_MODULE)
const originalAcquire = coordinator.CrossProcessTurnCoordinator.prototype.acquire
coordinator.CrossProcessTurnCoordinator.prototype.acquire = async function(...args) {
  event("lease-acquire-begin")
  const lease = await Reflect.apply(originalAcquire, this, args)
  event("lease-acquired", { waitedMs: lease.waitedMs })
  const originalRelease = lease.release
  lease.release = (...releaseArgs) => {
    event("lease-release-begin")
    return Promise.resolve(Reflect.apply(originalRelease, lease, releaseArgs)).then(value => {
      event("lease-release-complete"); return value
    }, error => { event("lease-release-error", { message: String(error) }); throw error })
  }
  return lease
}
const { createProxyServer } = await import(process.env.SERVER_MODULE)''')
s=s.replace('  const body = await response.text()', '  event("response-headers", { status: response.status })\n  const body = await response.text()')
s=s.replace('const children = new Set<ReturnType<typeof Bun.spawn>>()', '''const children = new Set<ReturnType<typeof Bun.spawn>>()
const debugWorkers: Array<{id:string;child:ReturnType<typeof Bun.spawn>;stderr:string;capture:Promise<void>;stderrError?:string}> = []''')
a=s.index('afterEach(async () => {');b=s.index('\nasync function makePaths',a)
s=s[:a]+'''afterEach(async () => {
  for (const child of children) child.kill()
  const settled = await Promise.race([Promise.all(debugWorkers.map(async row => { await row.child.exited; await row.capture })), Bun.sleep(5000).then(() => "UNKNOWN_JOIN_TIMEOUT")])
  const evidence = []
  for (const root of tempRoots) evidence.push({root,events: await readEvents(join(root,"events.jsonl"))})
  await writeFile("'''+str(out/'report.json')+'''", JSON.stringify({settled: settled ?? "JOINED", workers:debugWorkers.map(row=>({id:row.id,pid:row.child.pid,exitCode:row.child.exitCode,stderr:row.stderr,stderrError:row.stderrError})), evidence},null,2))
  if (settled === "UNKNOWN_JOIN_TIMEOUT") throw new Error("Diagnostic worker join remains unknown; fixture retained")
  children.clear()
  await Promise.all(tempRoots.splice(0).map(path => rm(path, { recursive: true, force: true })))
})
''' +s[b:]
s=s.replace('      SERVER_MODULE: serverModule,','      SERVER_MODULE: serverModule,\n      CROSS_PROCESS_MODULE: pathToFileURL(resolve(testDir, "../proxy/session/crossProcessTurnCoordinator.ts")).href,')
s=s.replace('  children.add(child)', '''  const row = {id, child, stderr:"", capture:Promise.resolve(), stderrError:undefined as string|undefined}
  if (child.stderr instanceof ReadableStream) {
    const stream = child.stderr
    row.capture = (async () => {
      const reader = stream.getReader(), decode = new TextDecoder()
      try { while (true) { const item = await reader.read(); if (item.done) break; row.stderr = (row.stderr + decode.decode(item.value,{stream:true})).slice(-65536) }; row.stderr += decode.decode() }
      catch(error) { row.stderrError = String(error) }
      finally { reader.releaseLock() }
    })()
  }
  debugWorkers.push(row)
  children.add(child)''')
s=s.replace('observed=${JSON.stringify(observed)}`)', 'observed=${JSON.stringify(observed)}; allEvents=${JSON.stringify(await readEvents(path))}; workers=${JSON.stringify(debugWorkers.map(row=>({id:row.id,pid:row.child.pid,exitCode:row.child.exitCode,stderr:row.stderr,stderrError:row.stderrError})))}`)')
# Existing expectSuccess must use the concurrently drained diagnostic tail.
s=s.replace('const stderr = worker.child.stderr instanceof ReadableStream\n    ? await new Response(worker.child.stderr).text()\n    : String(worker.child.stderr ?? "")','const stderr = debugWorkers.find(row => row.child === worker.child)?.stderr ?? ""')
(out/'pi-debug.test.ts').write_text(s)
print('Diagnostic fixture staged outside frozen checkout; product/runtime/timeouts unchanged')
