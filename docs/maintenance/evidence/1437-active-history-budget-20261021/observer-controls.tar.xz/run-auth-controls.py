from pathlib import Path
import subprocess,json,os
root=Path('/private/tmp/meridian-release185-20261021');out=Path('/tmp/meridian-active-history-budget-20261021/auth-close-control');out.mkdir(exist_ok=True);file=root/'src/__tests__/models-auth-status.test.ts';corrected=file.read_text();old=subprocess.check_output(['git','show','0a0d1af9:src/__tests__/models-auth-status.test.ts'],cwd=root,text=True)
def delayed(text,early=False):
 header='  it("ProxyInstance.close joins an auth check after the first HTTP wait expires", async () => {\n';a=text.index(header);b=text.index('\n  it("closing one actual HTTP instance',a);part=text[a:b];assert part.count('const closing = instance.close()')==1
 part=part.replace(header,header+'    let restorePhase: (() => void) | undefined\n')
 part=part.replace('      const closing = instance.close()', '''      const originalClosePhase = shutdownControl.closeServerWithGracePeriod
      const phase = spyOn(shutdownControl, "closeServerWithGracePeriod").mockImplementation(async (...args) => {
        await new Promise(resolve => setTimeout(resolve, 60))
        return originalClosePhase(...args)
      })
      restorePhase = () => phase.mockRestore()
'''+('      const realClosing = instance.close()\n      const closing = Promise.resolve()'if early else'      const closing = instance.close()'))
 part=part.replace('    } finally {','    } finally {\n      restorePhase?.()',1)
 text=text[:a]+part+text[b:];text=text.replace('import * as realChildProcess from "node:child_process"','import * as realChildProcess from "node:child_process"\nimport * as shutdownControl from "../proxy/shutdown"');return text
rows=[];bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib')
try:
 for label,source,only in [('old-delay',delayed(old),True),('new-delay',delayed(corrected),True),('new-early-close',delayed(corrected,True),True),('new-missing-signal',delayed(corrected).replace('signalled.resolve(signal)', 'void signal'),True),('new-standard',corrected,False)]:
  file.write_text(source);cmd=[bun,'test','src/__tests__/models-auth-status.test.ts']
  if only:cmd+=['--test-name-pattern','ProxyInstance.close joins an auth check after the first HTTP wait expires']
  p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/(label+'.log')).write_bytes(p.stdout);rows.append({'case':label,'exit':p.returncode,'tail':p.stdout.decode()[-1800:]});print(label,p.returncode,flush=True)
finally:file.write_text(corrected)
record={'scope':'Real HTTP instance, synthetic auth child and delegated shutdown phase; controlled60ms phase delay changes observation schedule only. Application deadlines/test timeout unchanged. Original full-run exact delayed phase not captured. Readiness observation is bounded1000ms inside the unchanged5000ms test; missing observation fails and releases/joins the fake child and HTTP instance.','runs':rows};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
assert [row['exit']for row in rows]==[1,0,1,1,0]
assert 'closed-before-signal'in rows[2]['tail'] or 'NOT_SETTLED'in rows[2]['tail']
