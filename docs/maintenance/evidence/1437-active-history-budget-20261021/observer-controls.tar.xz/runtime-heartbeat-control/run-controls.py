from pathlib import Path
import subprocess,os,json
out=Path('/tmp/meridian-active-history-budget-20261021/runtime-heartbeat-control');root=Path('/private/tmp/meridian-release185-20261021');env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';rows=[]
for label in ['old-coalesced','new-coalesced','blocked','new-standard']:
 p=subprocess.run([bun,'test',str(out/(label+'.test.ts')),'--test-name-pattern','async-admits real production store'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/(label+'.log')).write_bytes(p.stdout);rows.append({'case':label,'exit':p.returncode,'tail':p.stdout.decode()[-1700:]});print(label,p.returncode,flush=True)
assert [row['exit'] for row in rows] == [1,0,1,0]
assert 'toBeGreaterThanOrEqual(20)' in rows[0]['tail']
assert 'timer starved: no callbacks' in rows[2]['tail']
full=(out/'new-coalesced.log').read_text()
line=next(line for line in full.splitlines() if line.startswith('HEARTBEAT_CONTROL '))
sample=json.loads(line[len('HEARTBEAT_CONTROL '):])
assert 0 < len(sample['ticks']) < 20 and sample['maxGapMs'] <= 25 and 150 <= sample['elapsedMs'] < 200
(out/'result.json').write_text(json.dumps({'scope':'External same actual SQLite/Node-writer case; only observer cadence/measurement and the deliberate negative-control wait differ. No candidate source edit or model call. Original full-run timing trace was absent, so its exact max gap remains unknown.','runs':rows},indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
