import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'
import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
const root = '/private/tmp/meridian-release185-20261021', out = '/tmp/meridian-active-history-budget-20261021/final-gates'
const before = '3f819aaa873c9e12e91c25ec429c1e30cdf05633', after = '075e9e4736d3457e12dda1a0108531b9b5843e96'
const path = 'src/proxy/backends/antigravityProtocol.ts'
const git = args => execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()
assert.equal(git(['rev-parse', 'HEAD^{tree}']), git(['rev-parse', after + '^{tree}']))
await writeFile(out + '/1340-before-protocol.ts', execFileSync('git', ['show', before + ':' + path], { cwd: root }))
const bytes = await readFile('/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-agy-pi-B3eGFu/requests.json')
assert.equal(createHash('sha256').update(bytes).digest('hex'), 'd1783c3b159f3f5c1ab4dd40e3810aaa3de1f7e22ef360956108c2aa1517eed0')
const requests = JSON.parse(bytes), rows = []; assert.equal(requests.length, 1)
const { inspectBudgetedHistory } = await import(root + '/scripts/e2e-antigravity-active-history.mjs')
for (const [label, sha, module] of [['before', before, await import(pathToFileURL(out + '/1340-before-protocol.ts').href)], ['landed-main', after, await import(root + '/' + path)]]) {
  const request = module.parseAgRequest(requests[0]), original = JSON.stringify(request)
  let rendered
  try { rendered = module.renderAgPromptWithinLimit(request) }
  catch (error) { assert.equal(label, 'before'); assert.equal(error.status, 400); rows.push({ label, sha, status: 400, message: error.message }); continue }
  assert.equal(label, 'landed-main')
  const receipt = inspectBudgetedHistory(rendered, request)
  assert.equal(JSON.stringify(request), original)
  rows.push({ label, sha, protocolBlob: git(['rev-parse', sha + ':' + path]), ...receipt, inputUnchanged: true })
}
assert.equal(rows[0].status, 400); assert.equal(rows[1].effectiveBytes, 137959)
const result = { scope: 'Exact retained original #1340 actual-Pi public-fixture wire; deterministic before/landed-main rendering only. Zero new model/client/native calls; no reporter duplicate reproduction or notice qualification.', wireBytes: bytes.length, wireSHA256: createHash('sha256').update(bytes).digest('hex'), rows }
await writeFile(out + '/1340-current-main-comparison.json', JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
