Current assessment after #1437 merged (2026-10-21): **deferred; candidate remains unmerged** at bd5808f30aa2228998c3a665118383250c43022e.

The concrete large-history input-size blocker is now fixed on main by #1437, signed squash `075e9e4736d3457e12dda1a0108531b9b5843e96`. Rechecking the exact retained original public Pi wire request (377,317 bytes, SHA-256 `d1783c3b159f3f5c1ab4dd40e3810aaa3de1f7e22ef360956108c2aa1517eed0`) gives **256,143-byte rejection before → 137,959-byte translation on landed main**, within the unchanged 190,000-byte ceiling. The newest typed request, latest completed call/result, every tool identity and the original input remain exact. This deterministic comparison makes zero model/client/native calls; the historical 256,193-byte renderer result remains separately retained.

The actual Pi 1.1.0 / official agy 1.2.7 / Gemini 3.8 Flash Low / Darwin arm64 flow qualified by #1437 completes one exact write and correlated read across joined backend replacement without this notice feature. Its reconstructed imported fixture is distinct from the original wire comparison above. [Live path, exact original wire, controls and limitations](https://github.com/rynfar/meridian/blob/af6fbe2f09e27dbd12e316ac3c53636e0f3b35d7/docs/maintenance/evidence/1437-active-history-budget-20261021/FINAL.md).

The notice proposal still needs demonstrated benefit against corrected main and its own affected-flow live qualification. The historical duplicate-write cause is not established as fixed by the compaction change. A name/argument match cannot identify an operation: the current proposal deliberately blocks the first matching call with an error notice, then allows a fresh identical poll. That bounded behavior is covered by prior HTTP controls, but does not guarantee exactly-once execution. The existing console-logging concern and source/version evidence limits remain open. Prior exact-head local/CI results do not replace current-main integration and the missing live comparison. No new inference, source-branch mutation, merge, release, comment or closure accompanies this assessment.

<details><summary>Historical proposal, revisions and retained evidence (superseded status statements below are historical)</summary>

> **Revised 2026-10-13:** after the maintainer disposition below, the guard no longer answers from the recorded result. See "Revision after maintainer disposition" at the end; the sections above it describe the original `ab836ac7`.

## Problem

When a tool-result continuation reaches a new run, the history is replayed and the model can request the call that just completed again. The client then executes it twice. #1325 documents this as a retained limitation, and the live gate of #1317 fails on exactly this: two identical successful writes after a backend replacement. Prompt changes alone do not stop it.

A run gets a new process like this whenever the live turn is gone, for example after a backend replacement or a reclaimed process.

## Change

This is a deterministic guard in `AntigravityRun`. The pure helper is `completedToolTail` in `antigravityProtocol.ts`.

- A new run whose request ends in tool results is a history replay. The run records the **successful** calls of the batch that the tail completes, keyed by `stable({name, input})`.
- Until the run has sent any call to the client, an identical request is answered from the recorded result. It is not forwarded and does not execute again.
- Each recorded call is consumed once.
- `resume()` clears the record, so a later client turn can repeat a call on purpose.

These calls still go to the client:
- failed calls (`is_error`);
- calls with different arguments;
- identities repeated within the completed batch;
- anything after the run has forwarded a call. For example, in "run tests → edit → run tests" the second run is never intercepted.

Each interception logs `{"event":"agy_replay_duplicate","tool":…}` without arguments and increments `runtime.replayDuplicates`.

The guard only matches the same tool with the same arguments. A model that redoes the work through a different tool, such as rewriting a file with a shell command, is not intercepted.

## Validation

- **New test:** `src/__tests__/antigravity-replay-duplicate.test.ts`.
  - Pure `completedToolTail` cases: argument order, failed results, duplicate identities, and non-tail requests.
  - HTTP integration through `createAntigravityServer`, using a new fixture (`fixtures/agy-replay-repeat-cli.cjs`) that repeats the completed call on replay.
  - The identical-repeat and second-repeat cases **fail on `main`**, where the duplicate is forwarded to the client as `tool_use`. They pass with this change.
- **`npm test`:** typecheck passes. Every isolated group passes (20 groups). The first group has 3 failures, and **all 3 also fail on unmodified `main`** in this environment:
  - `fixBunExports (integration)`: local Bun 1.4.2 words the error differently;
  - `proxy-plugin-message-consumption > model fallback retains the transformed replay source` (stream true and false): this file passes 32/32 when run alone on both trees.
- **`npm run build`:** passes.

## Live evidence (qualified)

This evidence does **not** come from the Pi 1.1.0 / macOS acceptance in E2E.md. It comes from a downstream deployment of the same guard, on Linux with official agy, using Gemini 3.8 Flash.

- **Method:** a captured DeepSeek Harness (ACP) session was sent as a fresh request: long history, a `write` that had already completed, and a pure tool-result tail. The server logged every run as `recovered: true`.
- **Before the guard:** with Flash Low and a 100k write, the model never answered directly. It re-read the file 5 times out of 6 and rewrote it once through a shell command.
- **After the guard:** across 20 replays, the guard intercepted **1** identical repeat of the completed write. That repeat was answered from its recorded result, and the client did not execute it.

The Pi/macOS live gate from #1317 still has to be run against this change before it can count as acceptance. Related: #1073, #1314, #1317, #1325.



### Maintainer disposition — 2026-10-12

**Deferred; current implementation is not accepted.** Reviewed source `ab836ac7a089038bef743a6add7829cba31d69aa`, full diff, tests, live-evidence qualification and current discussion (no comments/reviews).

A negative control against the exact proposed `completedToolTail` reproduces a product-fit regression: user asks to poll until a job finishes; a successful `read({path:"/owned/status"})` returns `running`; after backend replacement, the next legitimate identical read matches the recorded tail. `AntigravityRun` returns that old `running` result without dispatching a fresh read. External state can change without an intervening client tool call, so name+arguments do not identify a duplicate operation. The same issue affects repeated file inspection and status polling. Conversely, consuming a match only once or using an alternate tool still permits repeated side effects; this is not an exactly-once guarantee.

The reproduction used the source helper with `parseAgRequest` and `stable`, an assistant `tool_use` named `read`, and its successful user `tool_result` containing `running`; `completedToolTail(...).get(stable({name:"read",input:{path:"/owned/status"}}))` returns the stale result. This is a deterministic protocol-level negative control, not an actual-provider acceptance claim.

Revisit when duplicate recovery uses evidence of operation/delivery identity while fresh identical operations remain dispatchable, and the affected Pi/macOS live gate passes. Existing #1073/#1317 acceptance holds remain; downstream Linux observations do not resolve them. No product changes or provider calls were made during this review.



### Revision after maintainer disposition — 2026-10-13

Thank you for the negative control. It is correct: name + arguments do not identify an operation, and the previous guard returned the recorded `running` for a legitimate status poll. This revision addresses that directly.

**Change (`ad0c4161`, on top of current `main`; harness `97e275e9`, evidence `c7e23c75`):**
- The guard **never returns recorded client content**. In a replayed run, before any call has been sent to the client, the first request identical to a completed tail call is not executed. Instead it gets a not-executed notice (`is_error`) that names the delivered `tool_use_id` whose result is already in the history: *"Not executed: this call is identical to `<id>`, which already completed in the client just before this turn; its result is in the conversation history. Use that result. If you need a fresh result now (for example, polling a status that may have changed), make the same call again and it will run."*
- **A fresh identical operation stays dispatchable.** Repeating the call after the notice dispatches it to the client as usual. The guard intervenes once per completed call and adds one model step in the polling case. It never substitutes an old result for a new one.
- `completedToolTail` now keeps only the delivered `tool_use_id` per identity, not the result.
- Limits are unchanged and stated plainly. This is not exactly-once: a model can still repeat through another tool, or repeat deliberately after the notice. It only prevents the accidental immediate repeat from executing silently.

**Your negative control, as a test** (`antigravity-replay-duplicate.test.ts`, "a polled status is read fresh, never answered stale"):
- History: `read({path:"/owned/status"})` returned `running`, then a replay.
- The fixture model reads the same path twice.
- Previous guard (`ab836ac7` + current main): `REPLAYED:running|done`. The stale value came back as if fresh.
- This revision: `REPLAYED:<notice>|done`. The second read reached the client as `tool_use` and returned the fresh `done`.

**Local:**
- typecheck, build: pass.
- `antigravity*/replay*` with `MERIDIAN_RESILIENCE_STRICT=1`: pass.
- First `npm test` group: 3 failures, the same 3 as unmodified `main` in this environment (`fixBunExports` wording; two plugin-transform model-fallback cases that pass when run alone).
- All 22 isolated groups pass individually.

**Live: actual Pi + Meridian Pi integration + official agy 1.2.7, macOS arm64.** Harness: `scripts/e2e-antigravity-replay-poll.mjs`, structured like your `e2e-antigravity-idle-conversation.mjs`. It covers the pinned agy hash, auto-update disabled, the plugin fixture preflight, environment scrub, original child/pipe joins, the final executable identity, and a `wx` report.

Identities:
- agy: official 1.2.7 release archive `ce9fe3f4…` and executable `8c01ef82…`, both matching #1073; unchanged after every run.
- Pi: 1.1.0, `dist/bundle/cli.js` `e79626f2…`, matching #1341.
- Model: `gemini-3.8-flash-low`, `useG1Credits false`.
- Platform: Darwin arm64, macOS 14.8.9, Node 22.23.2.

Scenario: Pi polls a status file that says `running`. While the first read's result is in flight, the file changes to `done` and the backend is replaced. The gate reads the replayed native conversation's own CLI transcript and fails if the client MCP bridge returned `running` there.

| Arm | Source | Replayed conversation received | Gate |
| --- | --- | --- | --- |
| main | `e0f9feab` (no guard) | `done` (dispatched) | PASS |
| previous | `ab836ac7` + main | **`running`**, then `done` | **FAIL** |
| candidate | this revision | notice, then `done` (dispatched) | PASS |
| installed | `npm pack` of the candidate, packaged `pi.js` | notice, then `done` (dispatched) | PASS |

The recovery gate (`E2E_AGY_RECOVERY=1 E2E_CLIENT=pi`) also passed all 12 checks on agy 1.2.7, including "no repeated completed tool".

Reports and retained failed attempts: `docs/maintenance/evidence/1340-replay-notice-20261013.md`. Two earlier attempts are not counted: one used agy 1.3.3 with a local gate edit, and one passed the wrong Pi entry point.

Not covered: Linux, Windows, OpenCode.

---
_Generated by [Claude Code](https://claude.ai/code)_



## Maintainer continuation — 2026-10-20

Current head **bd5808f30aa2228998c3a665118383250c43022e** includes a signed current-main merge (retaining the mainline prompt-limit renderer) and a separate signed test correction on this original contributor PR. No production guard behavior changed after that merge. The title is narrowed to the behavior actually proposed: a one-time not-executed replay notice. Preventing a duplicate side effect, exactly-once execution and complete #1073/#1317 recovery remain **unproven**, not implied by the title.

The three previously recorded blind spots now have HTTP controls driven by the local CLI protocol fixture: (1) a fresh call followed by a completed-tail match in one real MCP batch must dispatch both; (2) a fresh user turn reusing the same native run must dispatch an unused prior match; (3) the withheld call notice must reach native MCP with `isError: true`. Removing each respective dispatch condition, resume clear or error flag makes its named test fail. All three mutations were undone byte-for-byte. The corrected file passes **9 tests / 38 assertions**. Typecheck passes; the fresh complete local and exact-head CI gates are running.

The official agy **1.2.7** macOS arm64 release was downloaded from its official GitHub release, archive SHA-256 `ce9fe3f4d6f44a2b1c83b334fc5c8f2975079959e24dd805e10eb49ab8c76a7e`, executable `8c01ef82307dc01455418eb2e6e82f2989a3fa8b815c4b192efaaa89a55bef8d`. Fresh actual Pi **1.1.0** CLI hash `e79626f2dd6f94aa45d30f3fa63cd84319a6eefcd150b353cfaf274366926774` matches the reported client. The committed poll harness with `E2E_PREFLIGHT_ONLY=1` passes the actual Pi/Meridian integration fixture and joins every original child/pipe, with zero model calls and unchanged executable identity. This is preparation, not replay/write acceptance.

A bounded independent completed-**write** recovery comparison is now being prepared/run through that actual client/integration and the official CLI. It restarts after the successful write result, rather than after the generic harness's first successful read, and counts identical client write identities. It uses the existing official default-account/useG1Credits-disabled preflight, no API-key fallback or credential copying, no private native transcript reads, and original handle/executable custody. The historical poll gate passing on main is not sufficient to accept this feature. The original repeated-write failure, warning-then-repeat observation and remaining console logging concern above remain retained. No merge or release is claimed.


The short-history completed-write baseline on current main-equivalent `b409e105` completed **7 actual client requests**, backend replacement before request 6, exactly one successful identical write, and joined every original handle with unchanged pinned native identity. It **did not reproduce** the historical duplicate-write failure and is not acceptance of this candidate. Inspection of the retained #1317 reproduction shows a different, 384 KB imported public history (40 older completed writes, long assistant text and a 100 KB content-first completed write). The exact public fixture now passes a zero-model actual-Pi wire-import check, retaining every original tool/result ID and byte. That intentional preflight stops the request locally before model forwarding. A separate bounded current-main comparison uses that reported fixture and unchanged exact single-write/target/result/file assertions; it is not a rerun of the passing short case to obtain a desired result. The candidate remains unrun until the before-case is assessed.


### Current long-history result and local completion

The exact retained 384,665-byte imported public fixture is rejected on current main-equivalent by the existing prompt limit: **HTTP 400, translated prompt 256,193 bytes > 190,000 maximum**. An official native actor had started, but prompt rendering throws before its initial input write; no successful inference or duplicate-write reproduction is established. Every original native/client/helper process and both pipes joined, with unchanged official executable hash. The candidate was not run. Neither the protected input limit nor fixture/assertions was changed to obtain a pass. This is a separate current compatibility limitation, not proof that the old repeated-write witness is fixed.

The corrected exact-head full local gate has now passed **7,051 tests / 36 skips / 0 failures**, all 25 isolated invocations, plus standalone typecheck/build. The earlier live and product-fit holds remain. Exact-head CI test is still finishing; existing passing workflow results are not substituted for it. No source PR/issue was closed and no release was published.


Every actual final-head CI check now passes, including `test` and Windows smoke. This closes local/CI preparation only. The exact sanitized probe scripts, retained red/green mutation controls and compact actual-client/native custody receipts are escrowed below as a gzip/base64 tar, SHA-256 `a4e5cebfb575e4cf9342a56875e59dfdd7a37ad0dd7121c4b96547463101261b`. Decode into a fresh directory and verify `manifest.sha256.json`; script paths specify the independently installed pinned clients and selected package/source. The untouched retained #1317 public fixture helper is included for reproducibility and is attributed to `cd6b31a752e2f2d20240fee1e63ea46a39830dd9:scripts/e2e-antigravity-pi-history.mjs`; no old maintainer incorporation is landed through this PR. No private grants, native transcripts or customer histories are included. The candidate live gate remains open.

<details><summary>Reproducible current proof — gzip/base64 tar</summary>

```text
H4sIAAAAAAAC/+292XYbV7IoWM/8ijTbywmUE/MMFqVDU5DNUxLJS1LlU4fmoRLIBJklTIUEJLFortUv/R3dL7d73f6B+3Sf7p/0
6vPen9Ax7SETCZKSJZVdBbhKBDL3GDt2ROzYMfhXN4V5OJi+Dec3pcF0PBuFizAovJtHi7Aw8OOwOP5L/Ltf9inDp1mv01/4pP7W
Kq1WTT3j55VGpVr/nVP+3Rf4LOOFP4fuf/fP+SmVnJPQHzmDaRBNrgqL6XTk+INBOFv4k0HoXPmLsOi8isPYiZf9eDCPZotoOnH+
upwufGdxPZ8ur66d6XAYDSJoxb+6KW5F49l0vnD8OA7hz3A+HTvuZBqEXX5SihfzaLBwVblbZ/wmWITjmYdfornnEPI9j0ah58xD
P8Bvzp3d0DAuzeBXBMOymlmMZ1A9WXJqF/jLNJokX8/8xbVVYO5Pgun41auDZ8lig/nNbDG1CsYz/93E4z+nN5NBqvh1NAouYYSD
MLb7H8BsFuFpOIfNlqxxvVjMrIKwIoHfT88a4Bb6Y6vYFFcoUSR8G04WdpfQUzS8OY5OYSS4bqo0wC96C4MpAdBKYygURP6kMJtX
avVyoVquNivlarnE6x2XRlG/4E8W0dXcfxstbgqzqDCfDZAyuFuD6SQmkMA2WhzPp+9v9AR3Hf+dHy0cHk1OAFIMJ2+LvWrv8mXv
5ODZwd7h5cnR0ZnzLQwqiGJAD6pehLbzW9I6QGO2OLuOJm8AR79bBlfhIobW0w3uff/ny7MfDg7/eHD4/eV3r5593zs7dXZ3dx23
osY5GEUAoYy6+y8Oeodnzs8/O+4scrcYVXPn+MNz3OksnMAOCd2LYjQZjJZBGOe4qXxeWp5Ppws9Y8HoHGJcjvEyl/ec1xrSsFEK
X99yE3eF17oVGNZfwgE2RFWxUeiey7nQApQaRlep17Ac/BwgpvuHHqWx/I5jP+Wi3OF0FBZH06vc6735Ihr6g0Xcdb6+xWbvXqsh
jWHeozXQfnn0rPeCgHYVjqNJVKgV24XhyI+vC6PpOwX08H04WC4IoZPNaAzAto73zn6gpgA2qiYgAqHtrtOPJv78xtl94txuOY6A
PIyXI4SV3oc5LuY5526hIJXdCw/Qk9YPsKfruMvFsO06d3loh5e5GP516Y9y3FwREHmxjD2n7Dn6SRDO51h+Hi6W84ljigbT5QIH
nSxZBAo3zuW37tSqRjBIhXqIj4BVztMViB4fXH53cKhw0OmuFDg67h3uA8h1MY2XCglD2ve7SFRx2TzstavAmDMLkfdkPOrvn7iI
KTuLoMxs5C+G0/nYDEU98RwiOPq5VIMqCNOg65xfOHdbIExgifc3CMuRfyPDnPZpkwcw0HNYHdrePvKVmJ5sLWClcZmpqt5UaQqT
u3X6/uBNOIHeXIs8wYZFKHRxBWPgHRP4upgvgZtYhbqIExoc8GoECHsG3O872KFXoa6RRXnuGHmioZP7ioZYFJo1AvoVTqBkXoaM
FDpnF4Hdqgu5eY3JfhAABglNM+3J45xB1Zwq+c03zuJmFk6Huu5XiFjIW6VlhP1yjjv3NbKXbqlUqbaKZfiv0v36VmoVEVJ3r6U4
PEEY08IM/VEcEsrDuiH6Wswr58fI9GAb/JU2SV7tSz2fPqPhJHzn7OH3/elkMZ+ORlA3T+WgVpGgA8RtGoewZjluhcGKr1EMwMV5
DoQlvg6DPDdbpH+h9B23pJDF9D64Xk7eMCrtOICsshg56y2ILDCEv+albHG2jK9z9D2faGruv4N2vlsOh7Ac8GjgL7hYDJt8ekrQ
zjFFURVx/FAtjwyfd78/hx2x+6+nR4dF+k6vd5LEhwsVedfyv+6rSfh+BgQc1oOJMIx4CUu0A1thOnPzO4ITggiqCeExl1L6MgqA
5ijM8Ny9wQI6dI4jJ5osQtgOJNCBMBXD+3TTaqcWYRtdLa7/UC177nfT5SSAMfnckNA16c0ZhNGIUHBH1yXg8uhg1RLw7U8DRC4E
81MnBSEggNjRMJqEQXJRiAoTlmL9pzDlOPavwvhpEZanUMk/xaWCTbZIogXs8fhg8gPsv+n8Zhdx86U/y+VSbTw9v8gXgYct8OV4
98nefO7fFKOY/ubGqun8U/21SzWi0QKwu7/7pF/EBUGYozR9uQTszhfH0Bi8O+8Xo8DrX+TzOzIodeT6EYXeeDfZm5pp/qn6pvsZ
TQdvoC/8k+yPWZH7zTdf8csovgSeNJ1/800SAEWgZTmpL+MEVAHYTfwxtUZiuJuH2VmYnSUFnPT2j/7UO/mzkrWQOH1laAn8WjMr
fJUCgCDak3Jeb2onQZeQLusXvLGZZhIdyeX1u1838zAQ/cUsJLk1gEEPwrEWcrOZiUCP97hdx7AV+2matfBnPXOx6hoGo5YSHxT1
in4XAoEOT4R47DopgrNaj1QVYYDQPgiQyKcRiHYaojWyk1X8TgBMyb/uicYwwQqnTwND9vHOn6PkaDpSJI8Oy7LdVLuKvPHi6ZNs
zpbXhVTGcMYB8RTELCJ8DF84rWmiCzLWcgQyXDWfYkphPIMvoUbuYbgYXOdwPb5FOlyEbyjzjsPF9RTwGx/xd8+5hqMliGqIwa6Q
rwKuuIvbYDYbRQPiByUamnPnEYXtEoEGgVPTY9wcVxN/1BWezL8MahMTlGGKRO082XXqZdjXCcD/cHZ27HpOqqwnE9OPYXNPYHMX
F+F7YP12L0y9F7LLnhItZEIUTnB3BkSOdEPTN3lb3mTeBLSAdmeXZqsbK/LTy8UUMALGREy4a9oSWBIhdd8X9OEuBGlhsIjehgWq
gSsMj4iqfEBdroKVxyRpP1hVDbvAw4bzs1kPJU+FP0Dl3Aq0V5Ehu7dEIat5pbAoonbhx7BvekCA5kHSy7nEhGCp6S/uTRwTHKRB
LrzJ0cN8vjiLZiFW5obvgGcDZjvyWnMELSLK4E6RH6fm2ABUsyYPWzon4pr0taW2K58ECd9QJjhmzRKOYjp6G/JIQQYW0pwDxuBq
Yseoi+XyeetcCsX3tEjPtTNk+UQ5m/Jaj9OkN5Ou8JEexkX4tpau3CJDeBvp/W9rI1x80vfj8NUcUDybqJthCVWHbTqL/hgCfXCB
zvqjwjB6D6wdpXl4wYz1ej6dRYOCEq9c2UYwgnOQ9YE6yUEVpQ79A84aMAU6rmcxUQ9E19kSttO5iwQBT/iEme8XP0aTYPqu61Sq
7XIZVmrsvz+j3ZvdEAidtWqr2QZRs17uNLGZeIGQkPahBTjgq68Df3AdIqqbX8Rz4Cey9Qv8B7Dp4WWKw8UCBnHPQiGvAfmaTuSo
vCBK1uVDGaEcMgg1s2q53vacN2E4OwkHsBXU80alihQcxK35zWozeqwKaUFynyELfv2f//2//uf/9t8v/7///f/6vy9h3bVSNJcn
Rs7l4+lyPgiP/cW10kaJugn1Vf7wf/63AtYvDlCP56njRXZxeanKMsSzi87/539DdusvCv/v//g//vO//o/i4v3COkfzoHAOSrpe
kiBU3flpYrOdr29TEJfZ5+9QD9l14d8c1/290wJZ/afJ64xFNSDwpGczEtRPMzT3RWxwgD7Homd3Fn78xlnirEHAG904N1BdxAo3
Jq03EMogginDnrwG2TPgfknmiIvO82gOneDRF8tiM1/fWjC+Kzpn1z4IBqg6hx0V9UM454XQUTANY2cyRaVcFBNDIoGK1cKL65Da
Exrdt1s3k4XGezA0KA09yCGQOnoXwZLRTEJ6D0OFbXLtA4jVPLfT67INxdJPazvbdOfAc4f3LGuHND5sGkQw0yHqoYrOjwwdLPAe
xuSwag4JBaprsf8Itvti7tPpFAk9/IWtBK1/fWsw7s6ahAE4QjOcwHrJkKiM7xxCz0LL8QgNTdG2nfM4uFEeaP9mERaAnRfwi+Nf
+ZHRixI6QHkG8A4yN9LaiyQGmzUaxUiZ5nPUDCMGYvc8OkQM1vFzq0VnT83NAWzzcQFHZra48COoN4eHKOjGpKqdID6B+Da6UQpE
HA9gMBx3xjKPovNsStVZD0QlBOFoip5ztUR+xShEmwl28pxhtoQzayGaOHvmCCWIbOgJHChJb1ksFq0zpuccH1zuHz1Djf7e973D
s8tnByddR1FSeHn0/PmLg8NeFw+e9OCs96L3snd28md4VHaJw6MOSLQ/b8Ib1P0c9ZGgFOFXnINu8nmSKUr/kds7PPvh5Oj4YP/y
5/0Xe6+e9S5//r738uDw4HIP2v5j788/f3909P2LnvqZL4FMGi9y0BI0AlsNdzq0eA4PLkSt5s+vSBvlFgqKAeOlQoL9wu+CiIue
4oLwRMl0rreOf0EzQbQco7rYnQ6H3BAB16WjBlASIiSIuB4hjXcFq+yBGB94XKhQiPl6CH6k7hXkBTEqEmSh8GRaAE4LHAYFaKqP
DD9LMQAgOjg8631/snd2cHSoKsdvopHqGH4ypSzgfckIMMu8EJZeQPQyTwHBxupnfAMS2VhawEcWrQ0zSC09NWc3oKNniM2OVrPR
iY6IH+ydWBFHkmxBLmSu67yaRAPa+bD3mNjQHhfZuEhDmzFEYFgXoim21f9aba9E2g9AUH0H8LO+PVGYenxy9G9/vnwII5O9ARZg
d+fu/tHh84PvcfDP9s72CJh7+z/08Mvp2d5Zz73IUyuv/+3Z9yAVYMW7yx+OXvZeXySvo/ANnLhfTN+F830fVTIsaiNiYPnMu63C
9XQcyiHavqxSlUwTev48YKQHpARAgrBa6NnB6d53uFtfnR29OoaZYfd4HWhO00oYI+rzdQxC3diHvYQScAwisFqroh+VuBeW2vRx
MHGpVwI2jI9RNo7HQFIvHyolQtmlJZqfJ0kDSLfxNXAVGFQQxXymBewK50R/UUJ0SQHFKEeNZIv3k9kYyv6LD9s6eFPSsrmrhG83
QZ/lbv+ltAKlpnT3H+uTwsmLx54USm8r6w8LKKOqM8Gtc05fL2i89pFgFI0jEs2FLBgZX0noKMFLWz4wuSiMLUnenBRUcfUEqyDx
QQlpiVDWQvYDZxDgVLk1RPnWhpWi4fQdjnhdo5rwRPGgJPZ2pVNFudxz3vpzAPqCGriOrq4/sKFKs9au83kE/oMKd3mPqNslKoFZ
Qalfs85qnXa39/z50ckZX/Xm9W4pKlRLIytfYcTnDzV1obj9o1tkxPAeAC2tSPSW0UqpXVwEoaunev/pTO/4NaczNWCha5q7z5cT
ZkszPgLDN7wp9YkzCc2wmPxaimD4xh3pCvCqbbic0GnQgU5y8P896BT2hN8PR/nEzRvZnqgr8dws8hxdGrbOu6Dr6MMUiVcgJ0dT
3AzR1WTKw0YdjP4L8A7CBR51A4U1PG3qSG7AcQ17csGubsN2TAlgqFklqBmUj+QaHQizSwOC8vRjtR/UIwX+wody+IcvDKX6t7v8
7C7d9bpK2I2pZMFwgaR1glLurqg5zf2mKJ+4g1kU5OU2Sl7SZaSWhVDQyRV0WaU0za8qtqhV+lEk2YLUPr3Tk/0fQEZAUvxOzmR3
W0bLjLDDLs4iQCV7/Pgbxw70AL4CcHLqclVPLeeeHnx/1jt5iSulG8mqlKzyx4MXL3BPVMqoyoUtVq2jzZ4NPprAboZGTanUkLaS
YQqPieHDl8FKSSgFdhIv1U2x0rjBqhWHfHDRExyMQn+uJkCAwEbsh3qyWn95j67+tTHS+fqWttud4OLrvCeYp+1rPqQFmKi0IKYl
KWMUBCLZoNglxPyEuxX6IEKM2kKiNwcq4dOm3+Y9t71i7aIU7Gxfl9BlyP5USo2iXOeQ+jdxeEcqkT66u/mHujKnbaur1yg20LHx
rlut/DR5belJZfNry6tkWWshthJXvWJ/gNe4eWXLk3iYPBnSVTSIwur2JW+/FPUlvqcrAqXOVMSXiELqppiL6PtiuvgAxiHXl3bP
dFsFTaerJGiOuerlQ4S5XObpIomVQkhq6Fv+ofrq9kqBx2rEujRLtHaXQLwhKaKA/QEn52G89UdLWKT8Be7NIIcPcWviX7pa5t4R
G+hmJsVcqRjJbHmz4JZmaxW7aAR8ay0HXtfCnVTzVPjD2leQwQsQqY635Opa3ZPLXvclN0LHVVLagBTgjJekWgX+yRoTMuPwUTFj
jppuChEJSHQmo8lA03iAx794hse/fDMPBzJlppgB/BgOVGuAj19wy4kliCZQ8A1f3fHYeOhL3olCZa5DbO+DF5vGvX5RbAhTFwxh
tQvu2/h04l/i0V3prwXiRCjVGYbUazT29JVt5krH0d9CT20q+u720D7e2K1RMzRZ6Q76fhuSipH0dKjICFb7MeY0IbaXY+uXJ0xS
2LyXAIYYlblA1Buq1LgwwO+1skR7jGGGIij6/kkuvWGCJ+IDQCiqZkVkn6CXuhX3rcvw1VvwUgn1pVaReDnAsQ2XI1FbRqwoFOUx
Kx2xHIj/Dt+AFrfs+2659N8n9JKVQWxZYxVwXr7IJydqNZDBbLPxmexssjE60SA/vpeUUaXVKwerDS6XF7MHkK8Sa4LLgcpXmC/q
qwh2I6QON6mFcJWgQHBhW0y+43bVEsqqw1Iu3oXhJGHMIBppOGf4E4W/dH+Aw9iBIcgI0AZitd+7LctOg00cMi06pAyp4NZQEzTi
UKDPKU2AXgMPEKiHpLPr2LSDAW4TZ72b5KorAy6v/fQmQ7iWkOSWkG6VGGNFmTiaTmevzZUVE3ucSIH7U640RLX5IoKvpBQJV8pD
9DyILRWiei63BqTiT99WYH298W1CY23B2LXmGQ/gLLurLP5S3j16rHQzI4sbL8dhCbb4mxKpeNnMT3uDDEZ+NHZ3trLu5aVLAbuT
uGuH19YZBqqL1E4VP72lzH0taiMJ2whkTetWkcd3IHBY0yS/zWqNbLWeWlZsbEIz8m/weMg2BPRybzTan04mIekDYLPsPMZ2gZvV
pgqwVe+2yP/Ht/2/gNsXUljyCdy/HvD/Ktca9Ura/6tcbmz8v77ERzyFBrP1Dkw7ypsINVHf4V1eNOmdvuy9x6dxwv8IhIflKDQ1
+LLwByCjWf5Uupg6GqILh6e3Ff5KuX0B7YmGq6LOixdHP16+OPhTj1WLX+3uorDDJIf4RM6F0Y6iQYTXn7Av/OXiejqP/sY3rEhl
ImDEbn7HbholqP0XB4k7hEu+RNh1kanAaJTEjhpHPD7s3uve4nHB02t/10Am58bXfrXRdPPF5SxAPYsNjpxpG6SDILrCqx33OnwP
gwVQ6AZxzu1BuRIO29VauRXA13oDNlY77FfDZtiuDquddsevDf12v11pDOr9SqcaDn3fh6eNBsh17SAFslcTFI6iYQRMgPuxjF6h
e+3c8kHzyXZ6yZobNYzzCludZrU5rAZBc9ip+369EdTKQ5hKszYI2vVapeM3w3A4CIBu9GuN2mDoD6uteq3Z7FSbrVb9nnkdR8rq
Qs8HuPF0Hu+eX3ikQz2aR1fIrXYHsyI92FFfdpVSNgcCDGpb8reWDnY3UbuItpU3OTQB8aioBwPavZ1FQdeoB/HmrItvQX4FwcWs
/FNXeVjyXY4pkw3Npy4LNYXjyO2603cToOZw/JnhvTNxgqDLlxysN9nnR1/ZqlaP9U4rr+DZ3Q6DiOUnmEd+J0NLxxosUXjuPpH7
TBC84AlW8m5lJHR8tgrf5VV7PJKnqXahMahetIe+SwemHXuQ62vpWUktOStS5budTBoHTBZ9km4T7oxuca2/tJu/EwnnViNLAh3W
dsMIhPIEjE/AzGdFf/eJz2w8+OYbPzF9+a0nppqhMRx+UpKTIM4re3n/1enZ0TM8dx4fnZx5aas2Eke7rgJC0oGkxL2WGE+daxCN
R6GSkLX/IBwQJ4toweKq+LAq4gTi8oQ9VklmBc7lMQQ9hqehvl4SMh5RmjuPhLJq/lv3p4nr3Q5H/lXXfffevSNq9BU38vPPNslN
tpPX8HgfLfYBo3crImX9ej8J+W80BcH4mt1DPmEIgPvlv2qj1qqn5b9mubmR/zb+/xv//1/o/y+b+TmbWni8Agdj1reJI5huolia
CmkuVGqVlqIE7Oe/CSmwCSmwCSmwCSnw2wwpsIPVxOBsE15gE15gE15gE15gNbxAhm7xx4MTIJKHL/68y0rF20wRim5yPaEvqFKg
O4B30Tw8nofDUXR1vSBtw07SR7FeLnu3Kc/LVS/cu/yO8mBMn6jJ5lEZTdGfrjyLJm/9URToVZIyYmECh3BUCjl/C+dTNkh0cLBA
HmS0+rLIvUN9DDOpu00Uhr9XFAZoR7CrKH8PgtgIjqsNbMI2bMI2bMI2bMI2bMI2bMI2bMI2bMI2bMI2/EOHbdh9/WLvrHd6lhWv
QVZ3N6kL1kEVeO1UAAQ2RZaz7Dnqxz2hHheA40YGHcFmT0PLLu2RP1O3PG2Wy3f320y50uqKs7HqDZqbRyIi4Peb3ScpyNNToEPU
KF7fqUu81CBEHFEQIS/WrtsjC7zZsg9s1LHvwNR8WcMNC+IjE0XduIP3Yq4n5b67AQmmK8d4dPF/QVLQqvF5Yj55PUO0AI27GQI+
S1N3/yxO8rtJF/mUh7zxnRMFhu0ez77vxvWdPd/58OTZHu6PwLtVH3dycX+EhzvXHA9mrpf0dV/n6p7p6Z50dOdfIOQBXHguMFU2
B111gXefT/FQQxbCwBVROEf2FCj9SdHhcyfIi5ZBqMM0K7YMjZcTFVACA3FQ7I4V73kcAM7UcS82joobR8WNo+LGUfHTOCpunPi+
lBNftjZbQe+8fKGV2npZ0IB29wGPmd0n96orlaNGnhl0vIttJutrXw8rEq2HPP3BwuwB6C0ArcLFrlWADgdFFFKfPrUeINO9zHyK
FnBGaOT7iD3mlDwI5aWy+yR3i5acPC2PzkTGWYVH0uU/VD7viUdUV63YtW+g8s03X2V5tWgV8t2qj+I7WwnrVTwWaUfo2hHa3lck
dYAAQkMRX6yUi2Li2mXVR05mwR2in5WW0o1br7reSQwOygpo1QlBi8NyC2UdsQm6bPfI8FW+kMr1MYVL5NH4zTc2iHfROm9lZIlb
L5kq1yqxDOQmDvqiXfzmmzV6TDMMa5IB9HJiqWGViyDFWbNAzIvhKGectK8gIbtx49x98pjZ7SUuzahnCQ+GHUuPavnRx0j7y5pT
H/ldASHDRcgbUHwwnnrKJbaE3rAG3o+Y6j0OorqbVfdQdYYFOOzbXpi+dmVTEcukpPuQq/oqjD3lsZ6FvRqGDx2c7+lyZneitooO
bBWIRRfJ7xx2CuPrhYG7xr1NLMHFYAoD5y1hda2zrjIRI0tbZf+lglkV2L0buUhJQHjwDM8k7LSmThgWOSkRuLEtmiqdTij8HdZi
E1rHeCKaTeIPgZxbJxJqLOlxKFxg1clwd62L4cYBbuMA94AD3D/5Z8X/b9UG/Be7AD7k/9dstdL2341yZWP/vfH/2/j/bfz/Nv5/
n9T/j1v9PpyEbJqX2eE33yTVIFSmcgEiv3wzQrfWyuc3roWf0LXwHlesjXfhxrvwk3kXrsZ/QCyb3XxKGeMB+a/arDVT8l+13mht
5L8vKP9NYy9e9gXDPNRBjKK+h2c4D87wW/NdeVTEfZtzkz5efGrWPl6wkZGT7UJFZItvgV3soHXxLpzOc+ph/kmVdp8uVL1ARS8U
c3eA9OzOSzmXPMcShND9Flv+FpgOlizMKy6eEsl0OUTbCLeA4h0+B0qP93Dsn5TfwaCDJVe5NKnHW2g5A125lXq1Vhj7A8D+SRAh
zSqhxHnJ8mxc+pf5zWToz/WUqVua5C4GNwvpOpaHkALUY5zi3PwW0Ljd2zfdt3Sj8MZ760QTWBMkfdF8OikCWRwDAade8dW5i0Gx
Xc9FqRL+vNg7/B7/7KMsDF/ovgz+vDx+dnDiXtztIA0VYpwlMaO87BmftV3yUUvbCetC2k1rN9tHyzOSyC4Q6BwAeBZVKuWCosUJ
0Ib+PASgjwrvpvM3cYk8z8gX1b/CwuTA118ivS5BfXLi81Yka9UPkDMCrZKXSraNcN57WKT3sm/2qX1c6ZJLA7JdF3lWOHIe3Ioj
oq7M75J8jF4ydgIpwmsp0ZzoJkygc6usYHISEhSo3cCDSqKtYFiM/zriKxRdXluAXB73Tk4PTmHRy67V6UnvGWDCwd6LUxjo3jNy
gUAE0CUOFeQu93/o7f+Rjlxbshu7aNzhJvwn3AsssUVKZx4ZcBs0JoXtiD5nOfediwENHXjUne0aalTEO8JzOgG6nlnmx2gt3PyF
hzsLDQhYpNmF1kX+pK8LvmvdreHNMOzVySKH4C8Gy/Eszt26uMfdLv7rEXE6moxA/sZvqAONFm53VmQpj8RMtYY9TK4Su92shS1S
5hXYzeRY4UdAM05JTQqVFjm7ufzWF9b/rHX//Yz8v1Kplatp//96q7XR/3wp//+jGSVnIcVIwsmfnf8xlKO+PVCXBZRbRm4R5G7D
24K20HaIjoOFKz5hWnWAs8GWxsv5Id1GLSfxLBzwOVxCQM6dvf1jEdk/IpCAOYN4n9uX/xG+9+mwBuoUZAU4eExYg0dHDXgw/gG8
VdET9/rxdLRchJzwRVuq3Bsd4ZFRCfDe59XJi7MpR3jGRs6mz/lhsupyPnKVPz4cGdGRDC+KKNzmPadJKpQ6OirnbjJGgIaUaQe2
pb4bdzKxA4F391t7OE/T1hwOeiGr3uTeiwOS6iChxszAefrUyTI0yHhOpgZbpd//3jnGTYX+qKibqhQrxbITTAdxSYwUJaVAcRx0
nbc12LSTN1B0D0WllzItZS7r/L60FdLZ31jlrbEBNgbcfINqecTHYRhk52KTCKQmYiAnY7s/gVvCAiGVvW2ED9GgTpndzvyb0dQP
4MBc5FvAXLPZbEEPyO7PwvdkigdcG31wATpAyScLsgKMRo6uUlFmXwkjoFgcxemWMmlkZCxWOBu9qrlkpPkIM3NMvbHwR8rAu/zx
BuvSkpiuGwdvPftddXUrkVPn0xFlxVAFXE8VuNfY3ySSSaepEkwhYHjkzntCVv9dnQCJ7vHTrlwJiyW0d3Zxd9GvV3FI2avINdgj
o0AY6njWdSps+Jby0YQ55tCciW7KHb1XteWjZXFEasQoyO/wOpNhVLIa1dAUgsprWOXOdVYRPWognoHOlyPmxWi7vMRb7Fjnp0Hw
0lZHB4N8Vi96abDpEzaJ4BQt2M8BrD12hL8Pk50pd1fHGh16U2AWG0yL8/pU2/uMboDVTBchBreVxRGLcqG0lP0Ox3n3GsZphdUV
j4XVtUCcWzORZUx5zfT4XJQchmSPTPn/RoG2p8ejnnONcdDTUYyLziFqJFWk44jyaa0Ogwzv0KwUJPPwPWBEeUe+/sGpq+/ffps3
DedeK3NvGEjh61sqgb4wSQL12n6L9AmNH/GhDjCuXv5kR0YfLOdzdt58fchGEXJz3yVRh80o2OpApB8mdilKxwuiSO4diVkrcZ6j
CbepIasEdZWiT8MORS62D3H8yY2swEhkunk49iN01hHrbwrKPaXo4qn0hxyimKzJMBz4VF6tS6KJcXfQBeNuJbmihwPnPIpkJoJJ
E3WaSigspkoYRp3wU88Ia9AMoP6crc9xbioHojxmnqITFaKthjJ+I2MnNDzlxHCZkZMpGeEjcVvWOws1H0FM7O2qWZnQCYOw2j9B
OisQyqDlueCHx0ikonFg5snJ4gDpI+qaLacRkgeQmekhmIR/b1WUlppHfl22+1Biesghn6H8VcHYFAenR2LhgnFfLHN9mEfSJNey
uk0b3HKBCEeshBamTyb4RaWZB1kqOEVDvFzbQ28VlQuOK8g6ybykByHTCiKPnYcaKlrmW9CMAh3cnO5zblXnIj7YIoNnUMMsk53x
hJbMSDCeTj7YdZL7h0xUSCT8E2+L5HFLzmQasdmYiggtUU8/midTHroxK0o1tcgQD+8JbqH6tWVDdbLbFcE7lzSr1uXYBWU3aXWt
THgtaVwJ27jpWFqgfcdxG6xy4nGZls13LafLTNFdRnkub6x4EWulFdyq+UzndHhjO5zpthYklz6h7S1Rm1ataBEgEiZDQ7aoMcdV
K5Dpw+O8o9SUZDuHJnsOHBkXizCR9iQJaZLILPitwuEBmQ2hgK6uZur0Qg1cIXMeM3K8QKNCI5AqHMFBI1nWqoRosgCukhb/JcWD
QlLKKnKvLEnW82ZsSEx2zREiRTttE2PVm0ndYsaWNH80hoeyiEEYznq0kLaLnG5RkjlgyDBpiLyU8DR9kQ7Mk6qkjaMNbInE72Ra
YevKFhIpqpNyjIgozeeqUX4yJYg0b6D/wO5YC3800LVSWbxWlsDBkmMVWColOjyDUBXcvc7/wqGIZbGFqcb9QYZFQU6SIVkePVKx
gDVj1RR6L3gbxYjlwgSRlrJRqbIxRzmDVy0uKS8WZSUrwjjslxsWtYpbzu+dfwEO5I+dWyZomJYCxM45DEO9WE7eTKbvJucXd+ZQ
m66ksGEri9pHpIBbnEjDityrjjQ/jA0vs6k/BguK3pOnPFcoxgCxMEdR7uQJicpHw5y7zxbpUBMFDrY8IbJpFA3LITfnnv8//+v/
iS58GA4rDC5cw29QaNyFczpICBgIKpdrl52C1JRVzDslp5rIw/4XYq9nSlmjpiLlnT/sOtDKU6Po6JoiekLYcx4Yswzy23SRQsZI
4DdVWzkl4I59HoXk/uhuIw5vd7cVqm5721EAvzMJGLzEoye8JpoEPxmntillfUocT009bwswvHb71z7GFOAfehdIj1zrYHISDvyZ
LmT8LlJzQWGRahzPw7dR+E63nRiE7iRR9kyt9Up58i80gpQv+0zq4W2MitqDx13BYHJ+6RokhL/xjxFex67BwlXYaRkmb21yR26L
5OgUO7IDHVT94t0spX1X9ieiyiWVOjLuyYLyq5OeNU7scHYJlMbu5DhGBXi9YudW7Jr/gKcpOCGQ2hWG6hEn70pViQDGr37WQV/u
ntzZ2z/lp9vncGviYIDWbNy/p2b7Ek8OrESjzY9HjYU4cho3TnbqW2OCfbve01NKgQSvZua4rw7/eHj04+Hl2cHL3tGrMzyk0DTt
ODY8VZ3xG2cSwGajxPfh+wFgDIaQuctb0xA3ShPQT3YDm17JsItzzHR4LpU881jGCWcGOMIKjOQHjU70bWYWJ73Toxd/6j1Tw9dj
1rOg4em4KqnK/9rbPzOVs+ae8DDAoBCU9MryLcjyMTXofASQml3fxORKQuRkDqem8VhsoQBjl5iSa+LP4uspBu9AduUrL9uRE8zR
PRzRlDdGUEAcUJ4ViQ3StTYBlwBZkNQ8eO848meo50nsCNVtd9rXDrhqD7ydRsGTO24nk6+B+BD5o+hvYXCqRs/+WffiNE0YHq+s
OHI/f2SiVnoqu5+ngQFNIEj/heSR21su3+0DSQ/9CVrWsITenSzHfQCzPuOrB+xFHAZ76AVzCrXVC+lpdU/f4cSNUy37gN/KSLX+
zvTMSmfVLUeiTfeJT1WHNpZamgQFJLU+6cicwCqQa5FjP9DlAf3YpyhQqgoLeWKWoMb37beJfG8ShJd6kw3HIUHzaQd3GW/esDaz
iQ6Pzi5/PDk4O+sdXu49P+udXD7fO3jx6qTn6j2k8jQmQxsODFFRjsqrZJLHQniVU9NOkBtrlKbBogyPpVZNI/ICEL1EAhCHjYpu
9UB3HR1YWavhVlu/6yYfs9/o6x3pxTSWnr+yWNVV2VuY56IWXyIT07oo3iXIknD/5nIp3YlZfY+/EgoY7EisLqNznmOBL3BPpnD2
2293VMvpfZvGhL1nLxEVngkqnPb2Xhg8cJNAnctGQg6Sho1sghQ+38lsoNqauShaoVHVIh6qqg6VqFYq8VBhROYAHEOZd9diK1W0
cZQX0cb3J1YAxzWo+1UKdQ12Pn1q4ydxiE+Ln5YIix7ouoWVDY1XrKn2dSNWeLXVhaCF1EwSFeXIytiLzIVDGpBh4I6jaBgOboC/
OmhdPy86ZBstYQck7rSP+V/D8RQZkTNDeen3hj4CdySXQkLfaC5OkBiUL7aDF9IRcTrvR0FMwpU/+OsyiiP22sMGXyDlt56iFl8F
KqLabNTtCb+d6dtlSkJLNh922Ediwio+jXPL3PfOObOZ8y15RXfR7l2x5LMnbPzfzal5dc88iiEhnMsqKzLBE286IaA9XVvJMyvY
/SjB1+qVhAZvOhOvh5fxU82McRDWb8Ja8xs47ZTMYeJMWQMh+EIhQ05yFngMdc+RKSIXsfnXHbwxI0FRpFamuGcyFiWceI4MRj1A
cnRr3YiqqNfrYmF7gHcTQiQucBou8GECTRNv1EokHielm5f+7A9n3i87kDxJiC8063RQD1ue4i1iBCqzZeTuOd2DR4q75yLLcJgv
GaA9pDu7BheOu2QK8of1dSws0oUTWJuCyDoYMOL9giZUzDY8gqNL9VGiEnRAyLOyc9aM52HZUq2CCWeXWgX7jJJYgMQLBWcyv7BA
Sb8FJvSdh58SRC20+GUoaH3n6eIZgLq0YuvhBEngwfkZ3kiiiQgkBJNEcKXEmxQ/T8NMN75j7WYJQY+7gV3WuEg+n8y8jlYuu06O
jFMdOQWuiOPLmBfPKrVycrRGbS8bcXNqIcWXVTx7fJVXDIx/FrW/u2WcQoFRcahWCP4U+NhBz8z4taapBu2+vs2G4d3rvIUained
aH6l8OQEqI5Syqh3QN/+kGZMUIxc5uxdwCwV5yAteFJmV1FYC/b0BiOHqsIsb8gPW27mkhwQTxdWuQoyXyYEbHmYgDZGboNhEjnx
RJeUfwTqWvIz8vzcR6+FHWHLYjSEhTIqI5gf9w4xbKGbpRyx0NKQCUY9q12dcnz/Ohy8cfyAYnxMJXydMpaIMUX3OBrMpws/fuO8
u44G18yrORO57iCRd5yyM/DS59YoghROM5Ln8vo4wpDPWbtax1TLp05J1P46kR0GkZAW7hXZk66QFpQ8+2C8Ko9r8K/KzA8cY7PP
Agr90s0BeNI7faWIihyXklMUTaFdLrv37E4LLCs3HzSCFSnjQBVHGzL5rsMTpogn2emz7MRsieLPqFp5vZ1UOb2T1INPsxG0VWaa
z5tKib0iY83eJx+K2Bw2Iw2pfDKKnqUseQwyi5CbtxU7SuVjUBl2tB3ESlqUgp5WueNUqEFULS/Ip5MiyeCmVgrh4gftDtFupHeG
PM7YFckKKzuC9oNL0U0KVmBA3Vg+EZFRZQ/YzwK8qgjbyBp9MRs/8HJp/+jl8Yse6pGNhisVz/FxDWl99M7qfAriTs8h6BUG662e
PHvLFpGlGM7D8G+hQDC/dt87agPG1ga0qUuCoCaUV2tUTzoO/gp99oSUK/mWJVaKTiqo202SElb8rBM+ctIRHc1Olcv6ibrlYQLl
qCO/ulf4QIbiyb057iRiajmjelLtqG1l5OezFRFYxeokfcJcp8UxoRpl2akPtHvNUMpqqy5Daa1UHnYaC+kEDay0MkSfP0l8StLa
NeKL6ViNNLE8Fr6Q8TkPvkBUomDEFytBhrPCo9w9NVbOTsIkxlTeWaNymS7Uwop1TjLZhKYiZq1VGi7pz159a0lkwem0kktqGemZ
5kTqPCO7A8V09zkH+MKD9HKmRwXk9pTFIWVwCpKT5ALi2xx8oLQJy8ki4gB2Bb3OTIWv/di02A+BSOvgXM7eRN+YsmqQdVKDEBWG
aKG4uCYlmhb2JFSBot9cKUu7mY2ItvmLGuV0aHAsvx5T6A7NzReJWub0Hd0q7RsIrdRkzywzCJkgMucEZrBb/xZiMg6buNHDfOoG
Elo8JV4W5DDMptT3UOFp173Ip/LprKkvpFPH6dQpT7R2STjxKg9WIoUC/IdyycS2fRSb1HrVAvW5hlWu3jBkqXUN8id1uq9ijEHH
ERHnIQUkxBx0uHOjCd8vOAsKuuac8LGPvNVm7OkkZ2rOM4NqUcmFgdsiANTmUuhwgGnlSrwrfIp2p/W8sqHiEJnEIsTY2nOMiRck
LkFVMBDbzSpfVF5Yd2RCjd8ervOjpLq70/lBkvrcFRblMUUiHS9qTkk71s2t6sRkP0uxuzujGE9e5y4w6dhaVfCdM8DD2wx2+yJT
yypU9ERGn1NTNxloPNOzZ7Um17vqVdHihoIlD8d9NuG/eVdZ2Qu1LoYWG82YFaVI3mJRvVQEbtMaK4jMIHk9gMONp2/DHroVvqAc
JiFwIlINIevFv7YUKgKdnN6VCEa3h0qyT93S3dkT4Aida9VJRM6PJYFF0s6Fe2TrYeddOBrhXxK/l3OyJGAjSlYPSWMMr1xiU5v5
Eymwx2GGYFaW77LwEkPfqehLaeQGwMIn02UMe0tSQqFXAQ+FyKUaimmRukTj64Li5poBmEI9tcCp4bq82QqmpGvjYS/BGxT66jw6
xOcl9U4yt87KSqncl0lmJydWiT1p6W6em7skS3kjCsAMlCNFo7LEfORI8zsZC3q3laifjJqeYKjo6qDaLAjNSnJTkwbq/lYM/S2o
Kve3xMPW2UFlFtllMxOJ6q2dMQRVwZIjFQETEVFnK+Nh5HWg95WFAWn4PkLgiUdyMvMBjnC1pT4Zs0q205yhEbJQKpUTjTPPeZaE
ccq5wT45d29t0r7WXMVTsfmjjMuaO8U9kPKLuEY5Htha7yihOknZGxhTJlbHHkfksVN0lEk3819yV0cow9lMG++w9OmrAE8oa2Y6
RYgAy6PJkUM4wltpF+h2jpMLeIoWfcd+zE4dmGClXFV/2NnsezQx41pUB+P8m2cVesaL9f18upyR0tnOyUDYl8zckMzZgPeOSait
gycmVL+VO8WEARMFy1CrKqH99c+1q4yarwXhqb6qc1S0KrlO/ZkDv+JTFjVUK/yclivVAh4z9jOeIyx772eJm0GHElodAw5TDUlQ
aBfgqfUmyUcwvfQjFQAtXS79kGahr/Fie1JebA8YQ3o81bdzay24GPRWihH+Psy4SzPgVndyGtrOCpydFQirSikAq8c2fHXRNeDV
BmcautYTAW6yDIMxWSr1TCDLeb8VpOBQjc5Quw4LldoGTzDdyDh0hWLvA76dvwotWCautZJN3Sm3OnRLnrEaWA0sKQd6Ji2JgFe+
i9z1r1M6hmTdXA7SGyNe3RMZW2KauulNoBIu232muNao2JaLAz8YK3UtzKYPhOtk2bQk+yGpTVIvDPg0D1aDtbSE1t3ifExI80zZ
/iYFI2vEePS2WrfHbx5n5qLZso/C1qZIXe3aNlDa0Jy4D63IqnWytMsInaPg6AWxzNJqGZFIbilXTVeSzKhNbmkxOTwl/eI3Gdt8
1cB6/8XRaU+bWZsDNAjaJyEsi8r8hO7AtPPZbRft6cmHOJrLDDn2CXC/Ceq8KFOVYquiaNKSv9HJoCcD6mPOXaYI6CTFdMC94FRj
4udHszvH4hdK5hQnL2HRbn5FZbGGUBkcXW0zl0wGe5fg1km0uy/xUjLtEqKdhYHWFQ0tDmFlYlFJMYIb37wy66pfJvCXbw4skSG3
mslJGxQyUVVus0rnHeuMycbiMX1T8IgGBNMYWa0sUehQe1/iqNUd9Jq5lsjVeGYxdTFYQSqp0HSWYaax2iqX2LK3HSekR5Q3MXFt
XQ3l0JjhzQgMWibPpvDKzJGOk3HRul4XhnH/0qdsRjSTYfz8ZPmvLOkS9cspeplL4fW6tnF82n1mlZTlPUsctjM4kTSMRHlwvZy8
4cAZKfq8mjZREI1zVsGB/J4SmHEKSlDryu3qSUIKZ8y1Rq8GBX+tCWhFu3WVyuQBU69x+9opXQHt0cTs1mSIE5pj5Xqjxjl8EI0s
Aat8Rk06A08C6yxqhov6CxC23AvBpEQWvEQL6fNssg3CkgdayTiJE6RfC6S/vsWSrKjM3Mhopcu/qOBrY+GUkWktuw85Byn984Ot
J1rGAH6eIynM7OOVRT60jJ1i95pe7xK5sx8L6VKsYcuYTwjdKxM94FKGomcQQZkkNkoG00D71EDRBIeDWr9O0DOZVKoxy66mq6UT
LEpp0YFDj25E5simEGnQaeS5F3YWn0sCL3niYIKDdPKXg4rlkUfCSs3iMcASjU0SWAnxzNPM0Ba+2DvRyF4scx19d9o7+RPdy2v4
ast2dUUNeM4yiOWDyO7EdH0w0ElQukpHoRRKGCvFUpWCXCYO0WTQru6sUEUfxba2lKXxSeIgxLwwtiyrVMiJaIJTRK4loEtcX9w+
7s5AjHm7YuRoLgnuu1A4xj8hjDL+g8iICSXNk/PKxf1m21L8CJVGScWOdY0gDVg6ElmiNRohvKCbSbacxMmzm7T/sbmfbX6hfZnS
umUJ4JEwjNClt7SXkKkmd712cXtJYUsptNZCA19Q34m6TwPqCuXJvT6KdznKInq7lZ08lITNsuGj7vFJ7xRzER+dXP770cvvDnqX
rw7/y6u9FwfPD5Q9SlrCVPZThoTvGikRw4XRN4w8+/3J0atjjBr2Wp1lVgTEOzOJAIAxWOzjOs1DdWMuoqOPl8gqDy3FnXdL/WhS
mmEYtHO34L+fco7ZYNeb8b9X8C/mm8U4MByrGCMEYcYu7VrTFd3e2H/P0kvX1gNK7no7zgGPo4hbfxlTPk33cImh1waaxQ3CSbyM
hZG6FsXQdSn1LIccKcazUbTg0CQUvoRPx3hvMQmTZUo/xd+WuNAhqSJMLBM0g0Czrek72FG0GGrRZxxKAd+UL9hLm0eBSIIYlO1t
PDYWC4np62aBM2CEQ5h+4M/f0Q2we3aNVGo5kzAM5LRyRZEZYucZlSpMFU1OtHo1mvb9EVYvfrecPC1KrCNoslKsFSuYC9s9WYqF
KBxyB5gLeoQ0FWhaGA9w+hSwGERz5AbQiCM1rQgDQEn9q/Bkit6Q+q4tnbwgERAaNyBFjpGInLlEzMwcX+IWgcD5xeV8RFFVikU7
VsIscsxSJHN/oNkJSSXp14dHz3pcwMp4kCy2ElbbhEuBHmG5TeBQeJDHJ9RZ8g0+ondWP8kS5gVO7ZhjDXLoC7bOGI1Yl7//4sCz
Vv4QO6M8dRLe2/GvbijOXmwtCEUoRKO1zODkxlCaF4xtJyRWKycy40Cq6A6TCH4IJM4Eos+vhJhQsS4lDZo8xaMRB+tOv8c45xLE
25FwXKkia/KTJw8eFGUQDx46hJ3K+243dQ3CB3aUyAQ3hoPvRd5AAObMwRFvCYZdpzxtkc+RTBUvVkbTq5z28ItR4MbW7qxQeCpH
PeJPN4FelALJwcj13czBcbj67uogP32C+4iQCOg7B1dHQvBs72wP/+7v7f+AHsIuRVPH0xsGM3/9b8++Bx6DFe8ucQqvL5KrhW/g
hPhi+i6c7/uYws6AROgOnoOBtfjzG4+F6R4mNtdhVM4vVkyQtSe04U6qATINoqow1EJBulBs6W3X6uEeLiVuZhabajYataZOOG1T
U7HEsVnUn2RiINuOcV8GwBUo9p64MafEZeFXpiXKBQ3E0DzAA72wp6RbAwWIJsSyCK4OR6r4hkE4w0n6SxDAkqzAcAIkVmhIBoJR
PwJueGNa0GVY/DqkLSEPichRZvq8ep/xDlZpFl1wCfPaUD/P3h5IBiiFjeP2MXePcCSW4xFOJRVMCAijiklU4KBwii5BGZs07mTF
1SYCenSqTPEw2CvlC2WnK8To1SuXIDwm28Bdp/Qfb3M/Bd/mfyrKn1IR5yN5HYsGVFaoLVMf2IDIGOYh5pVynjjVKiJC5kuUO+A1
VF55XcW6u06lQ4xEBUyWhG4xM4wnu9VqsdIpllcFhMSoSSyA6rj3X+GlMZwC0fiOI7cYviTCgAr5qXq1g4uVfupXfipWfyq2fuqX
imhMZnWVz2yfYl9iKPQEb6sUq8WWJylI2WytPwWCP5xP/xZO0CaXIhvaWVHpaDI/paDZSDmu/XSKWY54au8iTmrBNSmJRd5OJzuf
LqaD6egDm4zngxJZSpYk32tsZ804lkaLi1Rv1/58Ajvivs4ekJbsoUdwzLmvKZBiDJkW791jHLSOt64kBLGsS4QzfxQki9dApe1O
4Awbh3tXciehgmXtXeFt3WzxEV1+CKRTo1HBJHcfigz++gUww9MzYIF2gFDm+xZjPU9EV75wVlIfr6SOTVSwRY+mEj3SNUQcMiHv
VChQPMHg9xtko6mATvQ8bwdslDCbmV0K+kgH9yGQDObBrLhKlmMFjRLlPGdNc5mjsl2J6CoLCbZKP6ROt5bjdvrYSwCyjnRljjiL
l9xkAitSiUcmNHR9zenPrZtv5ti7lnWC/JgBywa5hOycdAgxc8pWcXhI1bcanUdcF1aCyvyS1MiqNZ0m2iQdzoTu/b3NIhFXSFxX
TUtCw49tDm8HUs3Bo49o7v6cyxYkksmXM3u6y7q/IcMJsy6K1fBTfquEjaKJjbFrG7KhUlOXUZdnP3K0FRNQKOaCWj+GqJhPmTka
Ixll+nmEi6CsZdTDHoIyaTRPxJUMxEwvjsFqq7kdg95We3r8gwzTNKufhAWkaHUV8BU6aqVtoPaV3lLJ201LkbtrnHzs5UgdFsTf
xkCUQ+yo6yWqnDcmggmbfdTpZBjqrwugY5YmtbBsJ8t3rqb5bFNfV1UqqBj3WUb/6gRKD3Pp7I8JAtRNJGP3nMSguplD9QSmyjk3
tQSo0D9ajZqhglVIANsE4ifigqhLkTkgrbpRTYoaMAXh3pyTQWctA9o6nXNiiBj2vblTsAph3gH7WOFjaPiz6XT03TwKrkJVAzHx
TMX+gaMeH/7EwQSLWy9rHG8E/fGMkUxXuXyt951lfqKc4ymmA+kte9b6s/5YlVlhU0nl41dpDgciYpwT/pXSQRL/eko6yLUOj9Zw
oPOsUAgPOO3ykUvsSkjbZ2zbrHdHGb691uveipvvSGx7T9EWwGpTZyvuOl/Zg4epc4gATuGaYOx0ZsKvVTp+mloea/QlxIY6cLLu
NpClkJVRBjwC9hJX3KEDvg8DjyiG5ggdYKCDAIM9c0eWs2l636Q8OAUJEhcbZCyiGBqeRte4MmtvP2PAzz7faMHPYpY6HfM9X8o9
SI2CbylziTBe4n+7Dt0TrqerZvjZs1Ju5AlwrHqUP+CmnIVgWf78q5iWdrTPQLivNEzkAMMlUBv+4XEA7lkde1kKS5OOe8UMQ0GU
UQ95LCG8Jcci5ae0BYT2MO8r9asKv8hRs7u6J5yniYst2SgOmcbpOyp1yXSX/9CVMWSB6a4M/+4RiJsAjRIQNOqKesG+1zO5zDGy
9foFhLc8jBVyUWR3VnPVZi7YUFVxNBK3V8mhzM1oVR9uUddGDp4LtSa7kLl5AdMyFSjY2A1leqSpyJi06Q5dfE2TFEhdgOmTj9xy
W4HLXGv7WgIsMdl09K2te5yUE/Kqdlcmk761oE2Lp+w++1DgyKntcSptoouyapUOpsq+M+3FYeEkS3DQ4z1bMS1vsQOr3RW3sC5G
h/1WWUem/FRW3NXV1BJy1HI+ek5s1wA+uSB+AKwmjq0SCtzyxnaSlrKA2WIEoJ58ZSWCSGieX2PKvG6pVKm2imX4r9L9+lYqFZHh
kH3IXSJIsMnss+rGzo6ju4kUfehE+FeSYJNCkbmbRz96qlmQo4D2pE+bkippStLiYZIjdSRYTt7o9GTGspaHmLMKoQYGukEs4Fa0
NRtvOQ1NfvuHXaea9llxRVNlW84hpeZBSCwo/J63PH7tQCNivwePQBbjouhzrKzp+FICSA0mrYDiJNqTkiwH9S0vZ5v4ARdQ8dud
StMMsjCA/bZQQ9RlaZDYfj49QkIMkkNVVoxk7gxO0nGRDEHwldGN0IGJ23hE5jM7RUEqDQE9Wk3QYCKur6Q0yOdT0Q8YQHo4TOgf
NZ48QZDJpUSYMFp0zPQ551RQQssdpOWJkAkisEkq2TDA0wRn0NPDyUqiYk0m0ZjRPFmBT+8N0Gs2GMtzJpnKPVxoBXhyL5AlUdkB
vQFWmvWIyZkJeW2JM1b7WaTyPtpiB4pY48FsQ4TtFghiRvmWRHRxPVwFmAo+YsjPMESvV6bWOdU0akwBJ1DJToqjcHE9paxFfy3y
d06TEM4pDZ5KfVJAhHPxTDvjhBoA1BIpqtDCHvdal8MCKV5nuaEX/clN7lxZ1dkv5AIzV6lSEO+LvMUR74WW3iPKt/MN5vyQW36H
7zbxUlu95yfGIZaQs0h6ih9gsrlUQS9j5rqIQIeE/mShvJENlXSYdnlXfv9FTKD6Y9g3PRNZI46zzgleB0hIx7O4XaFqyhmCoy7r
pzL0U7FbtyHQKLPVF15iBrnEeTrBEIy0K9zv2sek7vOCGLJ9iLO1qvoob+u7vB3EmqG7xjuKBiaSHab9cLWg4Gp3rkTwKyOvcNVf
JqVkqniVlYNLNzFr1d23Omcnb79E2k58gmqUV3PYYA8LQZQa9I8h7EyX/GgKwo7ce3OG8vgoLyWeweTiiFNl6vyyaONJpgii3JAE
qOecY+pCboLeL36MJsH0XdepVNvKQkGlT62XO82Pz6BKGTnxH00x7oc6WibDgO+BOzILX+xw0fYCd6nS3iCNAwY4v8l6pUegfNmu
SKRzCwW1lK63kn8V3hIwTSpWeLK4jiZvWJJ3p8MhF6M0iS7dDviBp1Sr8MIk/9NXafB0Mi0A3AHCqJhw1aPxYKa/x2jpaV7N6L6y
oIJemReyhAW68dNPF9fh2PoJ7ADdxPg3jBk1fDK8G9h+Y2keHz2nTJdkpZeVD63ocN4XSmRh0mTyksTswENpMZcSFLKIIWDYs82k
x+OskkUaAk3ZcS+2EortK7RrOmfjjllEVwu4ZBepS4He5C1mbMWltLODoYWH8aFQJj1iK3Jut4c8xM6oKKYkmNcY8FgrFeJFEE1x
57BzNxupzszfC0XxOJveY0ye7f1g02uRoHh+opvAQvpwZU1f/ErJGlouN1Frz2nG6VhPLmp7rJkxfnJJjYx+TkoZvH04Pds7sQLZ
rQ4yMTqR2txMM6bUaC0RL2Wc76UcOVNpTVAVakcPQHtUlFwlxHpW56n7sES8Xc9WBrsnKqIYMZaSIKnmlTsPTYo9EpCH7WmrIaWz
IX8SbZr1YFOpVfNW1URbtmilr9eK2huc1fT2c/YJX32uPMMza+xzVHW1KIjmsZ6UuC2jdZNKawMb3Fb9rjlAPtl1anLvxacOAzPr
zODI0eZGdzgdgKTt5hNhgDC8jN5qAWkkV5JkUimTJdMjf4xUDnKVIi55zeSsSdBJLZoMnVspR1s6VxsfCYxWYr2kExm8zUzhqYTA
tZn/8jx60uurDIAeNyo+n/ceO3XuXVPfOhOqhhIBcEYcTJpCm1HXOrKZujiijIJ4c3TfaXpAOReDBAeW1ER8e5dujSqQexxNQ5JC
surskXWwaBZV4H5NGsI16R65GF57GdsXk1o2XUmXXpdZUiWeTWwOmgUrDtQkznncnprzRQqI7NOJ8i0PEx/mE/lBrUGi7dtE9ayz
I1LFki/O3Alqkq1XMEOwphnkUydztVOlNnF76ZIkFpOuirEx2TEsK2t0FCAeOT+hHUKxSfyQxNac95s65rbYu8BCC2tjUq+wL3FF
8ta5lbYLXoEqDCbFkXqhBogvtGrJSmu5nMQ6PbyChc5rKRWTiTgpiCBB4yIJjpXs3xkjEKTLZ66XjZYqUy4CcN/k5ybXURkfLOub
2IyZQtVm7aYVa8H0InmOVjmuGc3KYjzCru2eIcySneqdqLLXwUSvjQhLKUE5bXuQlLDYUJeVmW7aGDimFIgqS7TiOsgO2bEiI6et
ZCJ1Dp6RXC7CNRdXBTApPeMqNsVaYsJaK4u6neRU0ADb4+idyqzBvq5RNzikV0wyWVTMkWDFWewpGa8CkknEa7RakhR1N2VGmUta
WTKLzCegKXXlOuL+TKiZrRVNftSs7LurNIz7K1rJN0l7jYYWJH8ki2Xl4cwql858aUjQYu5PYl4iPk3htvFnJayhTcZVnjbaVFdz
ORs+iHem7QLJF0HIroQY+nzA/fDdlwTWxGTPjKGq45yKf4nWzGNx2+mH1/7baDrPZ+3sj7Vl9rJso9HDQylN+blgd3LrfcQAPsjy
2cs2s7ZHR7tEvf6oQaKZs5dhFG33wu5WGc3fpU1otrJsuMYcrtUy2bItslRozJ2EZVba/iaZvnJLh6KhNCyWazPNrqsiFRfUZYFo
BXUcGomZXBJVajE17vsCIq89A9PoCsnCfAULdCsvWkA6dOyNRvvaQzu2bpKTJo2sYjUnnUSAEH6MwSsSg5QA1AJgcyhcZ16QHnz2
MT7rII8GfJ/7KK8AmHWCNTEALBA94CetV8fLqIRBIV6bE7FEVsjuXMlBd/ejRDpmsY1BZoQSrDuNMLcPrRnrytcvFr3XWcbuNTm4
V+nNt2Zax51fXRrT03pTg62V+0BVR5GB1yd0aa7iNKxtm1IErr6VTIEZVz2MAha4XG/NKFJxnhIywXJylognlyBigIb3KXDYky3L
DBbx/vDfeydHYjt70jvbOzjsPVMJSXe0sR2cFpCbjv0bFSXavlCkeBQ/9Pb/eHqpUjtcwl46eL63f3b57ATavFTGhlsZRrnPJI73
ioEwZq1U5sEc+1xp0GI3KTRl2feu9mFZ+1oIlKibf8igN5lB7H7F2SMMfEXZjquNQ7LXVaWfsp9t/XLFnTEHFtqzg5nMZXBrfdFS
uJpu2+wdKw5AVjsp62a7FZ2gEzggBvDAANumMeC4GCQEZW14a5wyhKlytP4bCqeMkfx1CmnrzpwaAASiHOHQHltzKSdROhHPVWT1
KHZm03jBtFMd9UhkXOjDHlLpEtuCbq3fqq6x3EvtETflwLxyck26RVD8AkYS9s5E3T8GQGAlYcK/X14pfcC9jmlW7AzxueZoCFmh
MJKbI3mrumPcRgEwuQq0IHISI55KskAQo6XdMXGSkOEBzHEpkxH6sMh0WIS5/27z+af5VGr1cgFOTAOgfbSVJlcFMQDiK89P0Aea
aDTrdfoLn/TfSrnaUt/5eaVeblV/55S/BACWeHqA7v9J1x9J0ra4EaMBGIicAZ8Nt7vOdrtT6VSrdX9YbdaqzU5/2Gh1hp1mox7A
j0GnEfiNZrsctFqdSi30O9Ww1u745aDT7/iNYb/c3kZ73O2BH4cxNHdOAoGSEbfHywWRbuwIMHCGFHDbU2+RUMGbin6AaubgLGSu
i83RNah6C2Qd2yF0Vg0XVKsgRAdI+LdtG//McSD/GYd0gph/2rHYLT9+PETxMXrJ1acdjWk3NRb492LDAv7J6P/aDfNp+niA/ldr
1XqK/sOT2ob+f4lPH8Nfodb/LQe2cnJA7OthtV3Jb22hIvPyknIhXV7aOkwxoC0ES7bpDCnGRXERd7dutxdAgrar5WqzUCkXquWz
SrlbqXTrrWK72vz3bW+bgkVDEf/q5pLbudTtwGu8RYC3o+n0zXK2fbfVqTs/4zlykdNcIow5CkafhGa+PjdpH/mCYwgE91pdwumU
YtvppHWdBrVuXLeEF1JE44C8tlg5nMtvdZqJsjh24+eBxXM8ndz2Se/4xd6f5bD/7OD0eO9s/4dtj+X6BflwbssN1jYdTDstaZqv
RqmhG1L9XUpOluJi+l2Y21a349tQp51VR92nyU30Outvq6GkYfY5F0SeItfvfDWGsQI6HenRcWA4PTpunp+rpcLpvUGjwW2CPUzs
wnMy3sI5ox+W8fWFbSDtOP+xJVFc9YQAQmivoDszV9ZQkcWJc8PnuB/5bVRR29Dtth6Vp9Of0ZcLb6tArRRSrRSklUKqFRm9KnDH
Xy48Ypzwvafutp2C09z6Fk5lPAnH+dYpbylt38L5gz+ZTm7G02X8xMmVZvPoLaB/aTGelbTB32xO1Bm3EsjI5dJHbMdOp9vOb+Xw
DJh39kwNfQnDNZ1gGsZiGoRexCGmVdLXbnThu3gXDULnifPL96Bz3ijXi9XyOAaAOWUKP7TltB3GWIyAs1xsORU6uG45NYUNYmmy
deJP4CXRLH8wn8KZtkIH76JzXik2WtDohqt/LP/PElI///mv2SqvnP9qG/7/D8b/O8Vao/MR/L9SKRuuUywmrec8eF3Rr2/pwgeI
NHroovvgYtszHNefxO/YDQ1/I+WuVKqrdYEnzu1q289Peqc/XAJL7+2dCUs/ePai5wThKOqHksBRbJFNsnkZP3dTk27IJrdSqacY
N4scxXkIfQfC6StYsJEsOAnfLx4QCpyHP/ex2e9Cm8cqXta1xIUtxdDwdDoJLtG5a/uL8zUATbdW/rScjage5nZwlhNcCNXCmDic
un4WpsZxoCdmvUWZikbm5816o1h+JH9rfgh/q7dVw5+H/q+qBb7A+a9WazTT579GZaP/+8ei/41ysVn/KPpfRfoPfyr6HDj25284
x+hyItta71aM7Q/b2aeN/HL/WPJGAJm+JtkUnvqOZQNpGa2tHA4r1erjT4eVau0DjofIS9T11DPnpPdfXh2c9C7l3Ng7OTk6ue+4
WKnWH3le1CQaKzXuOzBmuecCv5GQedvbedUkD7L3rEvD7KKy8edt8g3F2R0S/JknLS+D6QS40qPY0ufgWllDPTS8AH1p8AKS2AD8
jTAWJ11mLqaOmYCHqbyBBajM6IZ/SG5oOeH8BS82hU9Quwj4HbrIlHtN7EOqTCcUPocORMKy2C8JUFTF8io6B0PnZrp0JiFaWQrr
kbYm03dODk1Uw/cUvQfjRI1GGOrDV36s1BSaElz7b7VJaR6d6d6EhnPR7MkxSu5dnXcRPAFULya4fQqY5MS2geYHQfOLi0nVRrdZ
+bRi0mcivs55vVMtNpqfQStQbVU/sdT0D3b+F/xR974FTJQb+aMvJf9VG7W0/Nes1jfy329S/svhxs0b4kFhBdG0/wmqf2N797PS
cDoUEq6oDWsU+zecU42tx2cYHdMKmI21/PnVkpwJpvMAqMt5q9iu4Sa/ZwRwwnsLdA6jfUrGe1FcYifErhZRGBvXA3R0EBbDozov
F+vlBzpBL9DxDEjscjJCkxusrdQDaAxOTMtylWBPZGi51sGWswXocrfaLnbajY8QoGWon0b7q0qSM/XE4vEMs9XVxOoeAdjUlQhR
OPWRdu85b9TrxfL9IOgUq63y40GAAsanBoBRf/sGTwwYmP1rPTgzxB0MoTOl4PEiS0SxZMVDGUSnIicFFRcahc55rVwtVtsWtv1q
FPjVTqtYrn7qkX06BUyt0Sm2qvehUq1chGd/59302USpar1VbH5yzImJevkc0IIosE1FSco34vt5td0uVqosznVEnCsr8a2dJb91
iBPFKwJcrVhrb4S3zyj/scU3h3pB66JPZfj3OPmvXCtXUvJftVZvbeS/L2b/h9Gd8G67HzTa5fawVvb9arXa7nTag5rfbDYqlXat
DWJ6eVAHnlQN2awPbQnIYWUbo+zgE8xbE+hfk9kYjdL0b4rMh+ZpfDW/jSQBfrXKDTFl247fRDN4UmvKbyQWWH1Lruu3o8nbKYcQ
w5rVxsZS7RPu/0H0iff9I/d/s15O2/+WW5XmZv9/0f1/Eg6Poo+gAizQ7iMdOAERdzlbNfSFIySQCjzNYfNcdDkxBq1a3NhDYpGW
1erdSuXf7cIYSSAW+9jTV/v7vdNT8xqjJEWj+NUcCcc2RjqLu6XSFZzjlv0idFSa30yG/lxr2SToRFwCuTEu1Tp1QMdmGxCw9Jdp
vwRTbrRq9U610WxuJ+xtsXV/ubiezuPryFgdbYsv6pqZlGv/nigKkCOQqIsA8/LddP5mOJq+O5S+9haLedRfkg1bptXwLwJytQYC
8ZcFMpD9ZjMB5A6g1SqQUSR8NHjrHwve/YPPANVKo1uvfGmoNmvlJFQ75doqVOPx9E34+cH6bDp4E84/B2jr3Wr9iyNsu26BtgGs
qtNeBS0JQU6u+L+QbBQX37ebl816YRRNlu+LmOoy//nhfhi9VwnrKP0qjSn+POvQaH/xdeg0UijeyaDOQRi/WUxnBVmPZR+kz2WB
w+88fgkaH7sE0v3nISvV8t8d5q1q40GYj/3BNP5gkLd/lSAn24W/L39sNSqrIH9HgVLjwhei6J+HUba6lfbflVHWK81Go9VYQ80L
GPnmcbAFRPlVcsvyPYLIHw+Oj+1xfQ70baCZbwa35Gv00fRK3yWRl8Yj0bjyi9H4n93fjc7/KuVsYTbnkEwq2/gX0v/V0vbftVpl
o//7cud/fz64jt6Gxu93EHaGYW1YD5rDet2v9iuDdq1fq9WHg8agPawCJyq3Op1GJ6zWg6BdboSVctivd/x+e9Bq+i1RDUheVq0Q
2LZukHH7kdPM9iyqVMo6IhU5vbY6zWpzWA2g+07d9+uNoFYe1oZ+szYI2vVapeM3w3A4CCqNcr/WqA2G/rDaqteazU612WrVtzdq
wQ/b/xxmQwWGmo2WVxGaH4XDUXR1vSjMK7+MGDzk/1FrpfX/jUZjY//75fY/pezCnUeBWqyVR8sE3stiIQtljk96z18cfP/D2eXx
nkhl2xS7D19ehRgCsFArttGKPL4uAM/lIhgjfjidj0lQ9+cgtvJzpD2kTJuPm3V+hDHR8dHbarUI/6vJU7rf/QEapcgEg3IlHLar
tXIrgK/1RqNeaYf9atgM21WgUO2ODwSj3W9XGoN6v9KphkPf9+Fpo9GHeoEaFKK6arPcr5cHqNmstdu1Wq3ar3X8oNEfNOtAoWq1
YTlo15rBoNYHclSrt5pBvT8MW9VqczBotcK2UD3eRccKhpY7/vY4BII4IIJ4IVDlXLD2ExF5tlWKBNMmJjSwil4t/XlAkeJifcfC
d7ph0Ju8BaFqRsSXwtpQK5LJcVVDOyPNb6tW63SMkIhRhtLBBCSi93SY8QJDeq++GPBiVuo1U5ZyuMjIjBhGY+SYoTbQ6HLi8NMu
/oZBJOi/PjxwAt6CyrgKlL+kg499PA94kP7XGin636y1Nvc/X47+k2mJTSk44KsR3EwIX04R1g8X78JwYqfOEPMRNA/yJ9qoC33k
MJj4uoi+ZF0jt70S7GsWkWlUKQyiRQkw8brEQbqBkKA59mg6Vdct22MOak2JRjg9mRjJSKh+VY4jGsfT5XwQOtiuevFqElGUSQzQ
HFuxktVzjhnN8Y4XczgU4wgm4TvcHKqNeAHDHeMLKyKybd9nRF2L3LeS1P47Mm6S8MLwuik35gInSl6TEUJHK4HwvXUUhsd40t2b
X8X7aF6TCBcjaxIGB3Tdx5b5aP3UrA77zWajVQ6DYb1fr3fa9bDe6AAFDaphtVG3OtB2RycyR+ggRckllKFNyindMN1m8VIrOiOQ
IjM5wDwVn4wCkmmLQlidKMBowZjnEHFpPg2WA0xarKy1mHoBzg3DwWJD4z8N/Zdl/CUngAfof6PaWKH/ldpG/v9y9F/vy6N5dEWB
hn07h4Ek/i1dh6NZOJcwy4pcqqTzyn6aSb04tCijTAoWPphHM/TOQMohsv9gMZ3H68RRDC1mqNabaELkSuuqgGJtJ4XVIFta3V/3
TmWUCdbIrOX7JFZvzZBb1d/YkFudRvO3NWR0h2qsDFmUGMfRr2+81Wql9RsDcbXRafzGhtzqNP+uUK588JA7lWa5/tuCMg658xsb
crXZ+a0NuVbu1H57Q/6tQble6TR/tRTjHpUYS1Wn1/6n04RaWrZP2u4skuY2lzq/3vPfaDq5UvmAzOEPtQSfRAP4YPyvetr/t9ls
bu5//w7nP8ofJbH5KfEQ5RKz0UNlukLXO5W+HsPYF8K/LuHIN4LfdAAc+qj+E9Rhqw506ZWoCezR64yicbSIMy6YLo9Pjl4en12e
9P61t68MObSacnuP8h1Ak5zZ4bx3cnK5d3raOzk7ODq8wAzRZef2J3JQ+Wm7+xNX/Gnb09+69ttoAuOOgkvRzl2a0hJljEpJAi2M
QzGdEkjQAaVZ6dQkZdITp9JB9MVU1dF4OeZ4EbbjHR59ZwtOn4YuyHGE4BrdOMF8OpuhBhEVXahn1V60JqzFT9t3dz9N8L8KJ8X5
SS7QZGG+u2ENYa1dbzYbFpv4PpyI3+aeOm5X7uUrB+MxH+ntV1r9hlZH9tUUreHxFPCEwmMKDBAklLKK0x9plCLcoCoOamjnUYA5
5liPpzCLXD8XU2fapxQRrBNE6KgoPewJNAwB+QZs7jq1PSH1KzsZb9E5mgDSCm9XeglSQDjXPrncoh52RyO1RPqRtHLspSk4IJ6o
qCvDYaEfs0RMELxmBTjmbo6lPpYjLfIPZ2fHgJ5Fh3kt97ucKZUnZ/LA8CSUPKn42bneI+j/L9YAPhT/odFI3/836xv/n396/V+t
1nj0IShN6mwS9Ws6cuCc6v9oc6o3apV/uDl1MuaUoWL8+0zow1VNtUb5Hw/xGpV6+x9tTs1qufzxc0oO4nNMSdkIJGe1fXrw/Vnv
5OX2Rnfx29JdjP1JNMTYTTGZ334WD/AH5L96eUX+wxXbyH9fzv77CiN6sc1MKW0MgNmbiuO/kGdFu14dlsvDartervn1oFHtB0HY
qLQGYbPe6gTDVhj2202/1mpW4EW9U2mFlXIbWE+/1ai3Bi0R++zu4JyVtj9QvdXatTZUrAS1PmyjsAM9lMutdlhpw6ZuDfz2sOIP
6+V2dTBolf1yux90fBheq9EJoFCtmtFb4qSzOr962e+36tBe6DfCYb81bHQalcEANn172AnC0K+3+8NWZRh0OoNBvV2rgpTQrw3K
YafZbwwrgzXzW+1VdTgAoDTrg3bZ7wTQVs0flPv1oF0rd1qVerM6DCr1Th8ITb/TqqGxab1dHrZgzmE7GJaHyuR0FaA4pxkdyOv1
dgPWp90ExhKUm/2g1e/UagO/WfcDmE2t04QZAmXs1BstH6SeoF/tDNvtar9cH+DbjB6mckooVGqVlpqXmpHf8sNmtR30681aFXAg
bJdrnWG1WfV9oJLtGixiLag2K51BCISyDtANmp32oAKdw6wGMqMH09KRPxCQ7kG5WW7VOmGzOWz7g3bL74Rov1tuhf1hveY3AAGH
wAB8mMwgBET1K1C0DRXCftPqan3KMOinE9aC2nDYgD6GgAtBs93vVGpBq+OHrVa53QY4dhpN4DXNGrCZ/qBRgVUqt/ygA1jTCstZ
/WSmA6OMa51Ks9P3YX2HjUG/4lfb/Wqt0WzVwiDo96t9QJJWtT4od6pVQJJqp9rwG+3KsDFs9f1qOXNOGcm+oKcmwAlG3R4AcjXq
DViOVstv9FutYQXWp10GlOs0On1geX673ijDcg7qdZhVGbYajsDq6Z74kYTkfrVTqdaGVb8+rIDM5ncGsLOCoNVqDSqNRqcc9Dud
fhO2VKXcqA6bYafdAuDCEvo+wNJGicxIRTSbIIBuhrDanXoZlmrQqXaQXPgANUBIoFVNYM41vwocu9bxK+0mIGen4Q+bdWDSlf5K
HxINhdpG75Y+0LKg2YT92GgFrWFt0O4MAZM7daAXwK+AYwXDhg9NQU/BoNoJ/TIg/wCEEN9qe62nFeHzEKDQx20CO6KDZA52YhNB
DzJEpV6H/6NdOiBbPQDsAnrXag7hJUy1DbUCq5/HeXQw4OrValjpNINmv9IM/RoISe1yCD9rjXYIJAN2Zq1eAwrY91vDVrPlD1uI
l0ALgRgNbOR+vBkxk75+uRYQTMsNIPBA3mBD9weDZpsQrNYfoJBVBbFqMOi3/GodpAggi+UO0N1Ks/nIjm3tFdFD2FXlWhmkwHIT
aGCzUm3Uh1VEz0ZYr/gBYDYgPmA/MhYYUgv+AxBUOkAaW8D9rG4/5NqEfEnDar8JFKJe9yuAOEBgYRrVQT0EwJYB94eDShsk1X6/
6Q/Dhl8Z1ILAHwIYmoBclUb70V2n51xutirNYaPRHoAY1vZh1tXQb5fh2F5rdioV2B0++jj4g1o9CMrACIAFAb8FngtYBiU3d2+b
z+az+Ww+m8/ms/lsPpvP5rP5bD6bz+az+Ww+m8/ms/lsPpvP5rP5bD6bz+az+Ww+m8/ms/lsPpvP5rP5bD6bz+az+Ww+v5rP/w8p
SHkkALgBAA==
```

</details>


</details>
