from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path('/private/tmp/meridian-release185-20261021');out=Path('/tmp/meridian-active-history-budget-20261021');tar=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz');digest='0bc7e56683ec375bf4aba02c09f2275db1e5310dcc05bf5274b528335fc2ed3d';assert hashlib.sha256(tar.read_bytes()).hexdigest()==digest;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOKKEEPING_COMPAT_TARBALL=str(tar));env['PATH']='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin'+os.pathsep+env['PATH'];records=[]
# Warm actual source/Git pages and immediately perform the ordinary build.
# This changes no source or certificate bound and is not a root-cause claim.
import stat
warmStart=time.monotonic();total=0;count=0;readHash=hashlib.sha256()
names=set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().strip('\0').split('\0'));assert len(names)<=10000
for name in sorted(names):
 p=root/name
 try:metadata=p.lstat()
 except FileNotFoundError:continue
 if not stat.S_ISREG(metadata.st_mode):continue
 assert metadata.st_size<=64*1024*1024;total+=metadata.st_size;assert total<=256*1024*1024;count+=1;readHash.update(name.encode()+b'\0')
 with p.open('rb')as f:
  while True:
   chunk=f.read(1024*1024)
   if not chunk:break
   readHash.update(chunk)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
(out/'source-page-warm-r4.json').write_text(json.dumps({'head':head,'files':count,'bytes':total,'seconds':time.monotonic()-warmStart,'readSHA256':readHash.hexdigest(),'sourceUnchanged':True,'certificateBudgetMs':2000,'reason':'R3source-fingerprint deadline exceeded; one controlled retry after read-only page warming; no source/guard change or root-cause claim'},indent=2)+'\n')
print('Source pages read; starting unchanged build immediately',flush=True)
for name,cmd in [('build',['npm','run','build']),('typecheck',['npm','run','typecheck']),('full',['npm','test'])]:
 print('Starting',name,'on',head,flush=True);start=time.time()
 with(out/('final-r4-'+name+'.log')).open('w')as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'exit':r.returncode,'seconds':time.time()-start});(out/'final-r4-local.json').write_text(json.dumps({'head':head,'publishedTarSha256':digest,'commands':records},indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
 if r.returncode:break
